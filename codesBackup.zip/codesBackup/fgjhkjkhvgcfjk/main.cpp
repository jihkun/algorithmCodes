#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
typedef pair<int,int> sub;
bool cmp(sub u, sub v){
    return u.first>v.first;
}
vector<sub> v;
int output_queue[1000100];
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        int sub2;
        cin>>sub2;
        v.push_back({sub2,i});
    }
    sort(v.begin(),v.end(),cmp);
    int tmp=0,mi=1000000,now_counting=1;
    for(auto i:v){
        if(i.first<mi){
            mi=i.first;
            tmp+=now_counting;
            now_counting=0;
        }
        output_queue[i.second]=tmp;
        now_counting++;
    }
    for(int i=0;i<n;i++){
        cout<<output_queue[i]<<' ';
    }
    return 0;
}
