#include <iostream>
#include <vector>
#include <queue>
using namespace std;

vector<int> v[10000];
int dat[10000];
int dist[10000];
int dp[10000];
int main()
{
    int n;
    cin>>n;
    for(int i=1;i<=n;i++){
        int sub;
        cin>>sub;
        dat[i]=sub;
        while(1){
            int sub2;
            cin>>sub2;
            if(sub2==-1) break;
            v[sub2].push_back(i);
            dist[i]++;
        }
    }
    queue<int> q;
    for(int i=1;i<=n;i++){
        if(dist[i]==0){
            q.push(i);
            dp[i]=dat[i];
        }
    }
    while(!q.empty()){
        int ti=q.front();
        q.pop();
        for(int i=0;i<v[ti].size();i++){
            int nj=v[ti][i];
            dist[nj]--;
    dp[nj]=max(dp[nj],dp[ti]+dat[nj]);
            if(dist[nj]==0){
                q.push(nj);
            }
        }
    }
    for(int i=1;i<=n;i++){
        cout<<dp[i]<<'\n';
    }
    return 0;
}
