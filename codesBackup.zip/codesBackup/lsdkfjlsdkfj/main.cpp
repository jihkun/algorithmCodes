#include <iostream>
#include <vector>
#include <algorithm>
#include <map>
using namespace std;
bool a[31900];
map<int,bool> mas;
vector<int> ans;
vector<int> na,ma;
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=1;n>=i*i;i++){
        if(n%i==0){
            na.push_back(i);
            if(n/i!=i) na.push_back(n/i);
        }
    }
    for(int i=1;m>=i*i;i++){
        if(m%i==0){
            ma.push_back(i);
            if(m/i!=i) ma.push_back(m/i);
        }
    }
    sort(na.begin(),na.end());
    sort(ma.begin(),ma.end());
    int nl=0;
    int ml=0;
    int na_si=na.size();
    int ma_si=ma.size();
    while(nl<na_si&&ml<ma_si){
        if(na[nl]>ma[ml]){
            cout<<ma[ml++]<<' ';
        }else if(na[nl]<ma[ml]){
            cout<<na[nl++]<<' ';
        }else{
            cout<<na[nl++]<<' ';
            ml++;
        }
    }
    while(nl<na_si) cout<<na[nl++]<<' ';
    while(ml<ma_si) cout<<ma[ml++]<<' ';
    return 0;
}
