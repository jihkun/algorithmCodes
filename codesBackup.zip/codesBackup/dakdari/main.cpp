#include<bits/stdc++.h>

using namespace std;
vector<int> ad;
int an;
int main()
{
    int n,mx=0;
    cin>>n;
    for(int i=0;i<n;i++){
        int sub;
        cin>>sub;
        mx=max(mx,sub);
        ad.push_back(sub);
    }
    int all;
    cin>>all;
    int left=0,right=mx;
    while(left<=right){
        int mid=(left+right)/2;
        int sum=0;
        for(int i=0;i<n;i++){
            if(ad[i]<mid) sum+=ad[i];
            else sum+=mid;
        }
        if(sum>all) right=mid-1;
        else{
            an=mid;
            left=mid+1;
        }
    }
    cout<<an;
    return 0;
}
