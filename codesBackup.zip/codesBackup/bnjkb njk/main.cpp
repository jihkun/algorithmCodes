#include <iostream>
#include <thread>
#include <conio.h>
using namespace std;
int chk=0,coun=0;
void a(int start){
    if(start<0){
        chk=1;
        return;
    }
    this_thread::sleep_for(chrono::milliseconds(1000));
    start--;
    a(start);
}
void mai(){
    if(chk==1) return;
    if(_kbhit()){
        coun++;
        cout<<coun<<' ';
        mai();
    }
}
int main()
{
    thread _t1(a,10);
    cout<<"t1 start!\n";
    thread _t2(mai);
    cout<<"t2 start!\n";
    _t1.join();
    _t2.join();
    if(_kbhit()) return 0;
}
