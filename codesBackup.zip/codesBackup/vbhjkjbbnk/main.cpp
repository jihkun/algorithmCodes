#include <iostream>

using namespace std;
int a[101][101];
int di[]={0,0,1,-1},dj[]={1,-1,0,0},n=0,dn=0,before=0,time=1;
int x,y;
int chk[101][101];
void dfs(int i,int j){
    for(int k=0;k<4;k++){
        int ni=di[k]+i;
        int nj=dj[k]+j;
        if(ni>=0&&ni<x&&nj>=0&&nj<y){
            if(a[ni][nj]==1){
                a[ni][nj]=0;
                chk[ni][nj]=time;
            }else if(a[ni][nj]==0){
                if(chk[ni][nj]<time){
                    dfs(ni,nj);
                }
            }
        }
    }

}
int main()
{
    cin>>x>>y;
    for(int i=1;i<=x;i++){
        for(int j=1;j<=y;j++){
            cin>>a[i][j];
            if(a[i][j]==1) n++;
        }
    }
    for(; ; time++){
            dfs(i,0);
            n-=dn;
            if(n!=0) before=n;
            else break;
    }
    cout<<time<<' '<<n;
    return 0;
}
