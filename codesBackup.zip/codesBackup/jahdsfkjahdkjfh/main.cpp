#include <bits/stdc++.h>
using namespace std;
int fin[1000010];
int dat[1000010];
int dp[1000010];
int a[1000010];
int finder(int i){
    if(i<=0) return 0;
    if(fin[i]==i-1){
        return finder(i-1);
    }else{
        cout<<a[fin[i]]<<' ';
        return finder(fin[i])+1;
    }
}
int main()
{
    int n;
    cin>>n;
    int k,c;
    cin>>k>>c;
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    dp[1]=a[1];

    for(int i=2;i<=n;i++){
        int in=i-k;
        if(in<0) in=0;
        if(dp[i-1]+a[i]>=dp[in]+c){
            dat[i]=dat[in]+1;
            dp[i]=dp[in]+c;
            fin[i]=in;
        }else{
            fin[i]=i-1;
            dat[i]=dat[i-1];
            dp[i]=dp[i-1]+a[i];
        }
        cout<<dp[i]<<' ';
    }
    cout<<dp[n]<<'\n'<<dat[n]<<'\n';
    finder(n);

    return 0;
}
