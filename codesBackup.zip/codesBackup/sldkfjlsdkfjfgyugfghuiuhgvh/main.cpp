#include <iostream>
#include <cstring>
using namespace std;
int d[3000001];
int main()
{
    int n;
    cin>>n;
    a[1]=true;
    for(int i=2;i<=n;i++){
        if(a[i]==true) continue;
        for(int j=i*2;j<=n;j+=i){
            a[j]=true;
        }
    }
    d[2]=1;
    d[3]=1;
    for(int i=5;i<=n;i+=2){
        if(a[i]) continue;
        int l=(i-1)/2;
        int r=l;
        while(l>=2&&r<=n){
            if(d[l]!=0&&d[r]!=0){
                d[i]=d[l]+d[r]+1;
                break;
            }
            l--; r++;
        }
    }
    cout<<d[n];
    return 0;
}
