#include <iostream>
#include <queue>
#include <math.h>
#include <algorithm>
#include <cstring>
using namespace std;
int a[100000];
struct qu{
    int f,s,i;
}q[100000];
int sz=0,cn[100000],cnt,ans[100000],bin[1000000];
bool cmp(const qu& u, const qu& v){
    if(u.f/sz==v.f/sz) return u.s<v.s;
    return u.f/sz<v.f/sz;
}
void add(int n){
    if(bin[n]) --cn[bin[n]];
    ++cn[++bin[n]];
    cnt=max(cnt,bin[n]);
}
void del(int n){
    --cn[bin[n]];
    if(bin[n]==cnt&&!cn[bin[n]]) --cnt;
    ++cn[--bin[n]];
}
int main()
{
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    int n;
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    sz=sqrt(n);
    int m;
    cin>>m;
    for(int i=0;i<m;i++){
        cin>>q[i].f>>q[i].s;
        q[i].i=i;
    }
    sort(q,q+m,cmp);
    add(a[1]);
    int s=1,e=1;
    for(int i=0;i<m;i++){
        while(q[i].f<s) add(a[--s]);
        while(q[i].f>s) del(a[s++]);
        while(q[i].s>e) add(a[++e]);
        while(q[i].s<e) del(a[e--]);
        ans[q[i].i]=cnt;
    }
    for(int i=0;i<m;i++){
        cout<<ans[i]<<'\n';
    }
    return 0;
}
