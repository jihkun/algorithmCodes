#include <iostream>
#include <queue>
#include <cstring>
using namespace std;
string a[500];
int chk[500][500];
int di[]={0,0,1,-1};
int dj[]={1,-1,0,0};
int main()
{
    fill(&chk[0][0],&chk[499][499],987654321);
    int n,m;
    cin>>n>>m;
    swap(n,m);
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    queue<pair<int,int> > q;
    q.push({0,0});
    chk[0][0]=0;
    while(!q.empty()){
        int ti=q.front().first, tj=q.front().second;
        q.pop();
        for(int i=0;i<4;i++){
            int ni=ti+di[i];
            int nj=tj+dj[i];
            if(ni>=0&&ni<n&&nj>=0&&nj<m){
                int cost=chk[ti][tj];
                if(a[ni][nj]=='1') cost++;
                if(chk[ni][nj]>cost){
                    chk[ni][nj]=cost;
                    q.push({ni,nj});
                }
            }
        }
    }
    cout<<chk[n-1][m-1];
    return 0;
}
