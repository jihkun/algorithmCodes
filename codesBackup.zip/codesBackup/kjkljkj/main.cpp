#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
using namespace std;
char a[20];
bool chk[20];
vector<char> v;
int n,m;
map<char,bool> chktable;
void f(int in,int ma,int c,int vo){
    if(in>ma&&v.size()!=4) return;
    if(v.size()==4){
        if(c<2||vo<1) return;
        for(int i=0;i<n;i++){
            cout<<v[i];
        }
        cout<<'\n';
    }
    for(int i=in+1;i<ma;i++){
        v.push_back(a[i]);
        if(chk[i]==true) f(i,ma,c,vo+1);
        else f(i,ma,c+1,vo);
        v.pop_back();
    }
}
int main()
{
    chktable['a']=true;chktable['e']=true;chktable['o']=true;chktable['i']=true;chktable['u']=true;
    cin>>n>>m;
    for(int i=0;i<m;i++){
        cin>>a[i];
    }
    sort(a,a+m);
    for(int i=0;i<m;i++){
        if(chktable[a[i]]==true){
            chk[i]=true;
        }else chk[i]=false;
    }
    f(-1,m,0,0);
    return 0;
}
