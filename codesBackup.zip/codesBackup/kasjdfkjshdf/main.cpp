#include <iostream>

using namespace std;
int k[100001];
int main()
{
    int n,sub=0,m=0,ma=0,o=0;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>k[i];
        sub+=k[i];
        ma=max(k[i],ma);
    }
    cin>>m;
    if(sub<=m){
        cout<<ma;
        return 0;
    }
    int l=0,r=ma-1;
    while(l<=r){
        int mid=(l+r)/2,cnt=0;
        for(int i=0;i<n;i++){
            if(k[i]<mid){
                cnt+=k[i];
            }else{
                cnt+=mid;
            }
        }
        if(cnt<=m){
            o=max(mid,o);
            l=mid+1;
        }else{
            r=mid-1;
        }
    }
    cout<<o;
    return 0;
}
