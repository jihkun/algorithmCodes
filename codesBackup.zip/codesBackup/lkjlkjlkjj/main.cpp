#include <iostream>

using namespace std;

int main()
{
    int n,m;
    for(int i=0;i<n*m;i++){
        int sub;
        cin>>sub;
    }
    cout<<"
    return 0;
}
