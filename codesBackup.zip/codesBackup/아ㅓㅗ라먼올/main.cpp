#include <bits/stdc++.h>

using namespace std;
string a;
int a1[100];
int sub[100];
int main()
{
    srand(time(NULL));
    cin>>a;
    int as=1;
    system("cls");
    for(int i=0;i<a.size();i++){
        sub[i]=rand()%20+3;
        a1[i]=(a[i]-' '+32)-sub[i]+as;
        as=a[i]-' '-60;
        printf("%c" ,a1[i]);

    }
    cout<<endl;
    for(int i=0;i<a.size();i++){
        cout<<sub[i]<<' ';
    }
    return 0;
}
