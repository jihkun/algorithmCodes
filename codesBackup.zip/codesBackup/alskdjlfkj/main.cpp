#include <iostream>

using namespace std;

int main()
{
    string a;
    bool is_cpp=true,is_java=true;
    cin>>a;
    if(a[0]-'a'<0){cout<<-1; return 0;}
    for(int i=1;i<a.size();i++){
        if(a[i]=='_') is_java=false;
        if(a[i]-'a'<0) is_cpp=false;
    }
    if(is_cpp==is_java){cout<<-1;return 0;}
    for(int i=0;i<a.size();i++){
        if(is_cpp=true){
            if(a[i]=='_'){
                printf("%c",a[++i]-'a'+65);
                cout<<a[++i]-'a'+65<<'\n';
            }
            else cout<<a[i];
        }else{
            if(a[i]-'a'<0){
                printf("%c",a[i]-'A'+92);
                cout<<a[i]-'A'+92<<'\n';
            }
            else cout<<a[i];
        }
    }
    return 0;
}
