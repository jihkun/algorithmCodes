#include <bits/stdc++.h>

using namespace std;
int z,o;
int fib(int n){
    if(n<=2) return 1;
    int sub=fib(n-1);
    if(sub==0) z++;
    if(sub==1) o++;
    int sub2=fib(n-2);
    if(sub==0) z++;
    if(sub==1) o++;
    return sub+sub2;
}
int main()
{
    int n;
    cin>>n;
    while(n--){
        int sub;
        cin>>sub;
        fib(sub);
        cout<<z<<' '<<o<<'\n';
    }
    return 0;
}
