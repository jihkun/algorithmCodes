#include <iostream>
#include <vector>
#include <queue>
using namespace std;
struct Lecture {
    int id;
    int start;
    int en;

    Lecture(int _start, int _end, int _id) : id(_id), start(_start), en(_end) {}

    bool operator<(const Lecture& other) const {
        return start < other.start;
    }
};
priority_queue<Lecture> q;
priority_queue<pair<int, int>> v;
vector<int> arr;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);
    int n;
    cin >> n;
    arr.resize(n + 1);

    for (int i = 0; i < n; i++) {
        int sub, sub2, nn;
        cin >> nn >> sub >> sub2;
        q.push({-sub, sub2,nn});
    }

    v.push({0, 0});

    while (!q.empty()) {
        int start = -q.top().start, en = q.top().en, id=q.top().id;
        q.pop();
        bool flag = false;
        int next = v.size();

        if (-v.top().first <= start) {
            next = v.top().second;
            v.pop();
        }

        v.push({-en, next});
        arr[next] = next;
    }

    cout << v.size() << endl;

    for (int i = 1; i <= n; i++) {
        cout << arr[i] << ' ';
    }

    return 0;
}
