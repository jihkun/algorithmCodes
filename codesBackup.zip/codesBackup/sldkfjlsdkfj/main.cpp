#include <iostream>
#include <queue>
using namespace std;
vector<int> v[100];
bool chk[10000];
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=0;i<m;i++){
        int sub,sub2;
        cin>>sub>>sub2;
        v[sub].push_back(sub2);
        v[sub2].push_back(sub);
    }
    queue<int> q;
    int cnt=0;
    for(int i=1;i<=n;i++){
        if(chk[i]!=false) continue;
        q.push(i);
        cnt++;
        while(!q.empty()){
            int ti=q.front();
            q.pop();
            for(int i=0;i<v[ti].size();i++){
                int ni=v[ti][i];
                if(chk[ni]==false){
                    q.push(ni);
                    chk[ni]=true;
                }
            }
        }
    }
    cout<<cnt;
    return 0;
}
