#include <iostream>

using namespace std;

int main()
{
    int n,m,a,b;
    cin>>n>>m>>a>>b;
    cout<<m*(a-1)+b;
    return 0;
}
