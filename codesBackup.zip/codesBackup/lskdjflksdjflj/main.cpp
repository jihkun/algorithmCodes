#include <iostream>
#include <vector>
#include <algorithm>
#include <math.h>
using namespace std;
vector<int> v[10000];
int p[10000][10000];
int d[10000];
void setup(int k,int n){
    p[0][k]=n;
    d[k]=d[n]+1;
    for(auto i:v[k]){
        if(i!=n){
            setup(i,k);
        }
    }
}
int L(int a,int b){
    if(d[a]>d[b]) swap(a,b);
    for(int i=22;i>=0;i--){
        if(pow(2,i)<=d[b]-d[a]){
            if(d[a]<=d[p[i][b]]){
                b=p[i][b];
            }
        }
    }
    for(int i=22;i>=0&&a!=b;i--){
        if(p[i][a]!=p[i][b]){
            a=p[i][a];
            b=p[i][b];
        }
    }
    if(a!=b) return p[0][a];
    else return a;
}
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n-1;i++){
        int sub,sub2;
        cin>>sub>>sub2;
        v[sub].push_back(sub2);
        v[sub2].push_back(sub);
    }
    setup(1,0);
    for(int i=1;i<=22;i++){
        for(int j=1;j<=n;j++){
            p[i][j]=p[i-1][p[i-1][j]];
        }
    }
    int k=0;
    cin>>k;
    for(int i=0;i<k;k++){
        int sub,sub2;
        cin>>sub>>sub2;
        cout<<L(sub,sub2)<<'\n';
    }
    return 0;
}
