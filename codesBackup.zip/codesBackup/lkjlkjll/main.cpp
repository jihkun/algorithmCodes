#include <iostream>
#include <map>
#include <algorithm>
using namespace std;
map<char, int> ma;
int main()
{
    int n,m;
    cin>>n>>m;
    string a;
    cin>>a;
    int d[4];
    char di[4]={'A','C','G','T'};
    for(int i=0;i<4;i++){
        cin>>d[i];
    }
    int siz=0,cnt=0,i=0, last_index=0;
    while(siz>=m){
        if(siz<m){
            siz++;
            ma[a[i]]++;
            i++;
        }
    }
    for(;i<n;i++){
        ma[a[i]]++;
        bool pass=true;
        for(int j=0;j<4;j++){
            if(ma[di[j]]<d[j]){ pass=false; break;}
        }
        if(pass) cnt++;
        ma[a[last_index]]--;
        last_index++;
    }
    cout<<cnt;
    return 0;
}
