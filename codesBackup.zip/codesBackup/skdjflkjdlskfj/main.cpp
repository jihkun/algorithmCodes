#include <iostream>
#include <queue>
#include <vector>
#include <cstring>
#include <windows.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;
int a[1000][1000];
int di[]={0,0,1,-1},dj[]={1,-1,0,0};
bool chk[1000][1000];
vector<pair<int,int> > da;
queue<pair<int,int> > q;
int main(int argc, char** argv) {
    queue<int> dat;
	int n,m;
	cin>>n>>m;
	for(int i=0;i<n;i++){
		for(int j=0;j<m;j++){
            da.push_back({i,j});
			cin>>a[i][j];
			if(a[i][j]==2){
				da.push_back({i,j});
				chk[i][j]=true;
			}
		}
	}
	for(auto x:da){
        for(auto y:da){
            for(auto l:da){
                memset(chk,true,sizeof(chk));
                chk[x.first][x.second]=true;
                chk[y.first][y.second]=true;
                chk[l.first][l.second]=true;
                while(!q.empty()){
                    int ti=q.front().first, tj=q.front().second;
                    q.pop();
                    for(int i=0;i<4;i++){
                        int ni=ti+di[i],nj=tj+dj[i];
                        if(ni>=0&&ni<n&&nj>=0&&nj<m){
                            if(chk[ni][nj]==false&&a[ni][nj]==0){
                                q.push({ni,nj});
                                chk[ni][nj]=true;
                            }
                        }
                    }
                }
            }
        }
	}
	int cnt=0;
	for(int i=0;i<n;i++){
		for(int j=0;j<m;j++){
			if(a[i][j]==0&&chk[i][j]==false){
				cnt++;
			}
		}
	}
	cout<<cnt;
	system("pause");
}
