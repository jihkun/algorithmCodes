#include <bits/stdc++.h>

using namespace std;
map<char,int> dat;
string a[11];
int b[11];
int main()
{
    int nv=9,ma_length=0;
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>a[i];
        reverse(a[i].begin(),a[i].end());
        int sub=a[i].size();
        ma_length=max(ma_length,sub);
    }
    for(int i=ma_length-1;i>=0;i--){
        for(int j=0;j<n;j++){
            if(i<a[j].size()){
                if(dat.find(a[j][i])==dat.end()){
                    dat[a[j][i]]=nv;
                    nv--;
                }
                 b[j]=b[j]*10+dat[a[j][i]];
            }
        }
    }
    int cnt=0;
    for(int i=0;i<n;i++){
        cnt+=b[i];
    }
    cout<<cnt;
    return 0;
}
