#include<bits/stdc++.h>
using namespace std;
int a[]={0,31,30,31,30,31,30,31,31,30,31,30,31};
bool prime[]={0,0,1,1,0,1,0,1,0,0,0,1,0,1,0,0,0,1,0,1,0,0,0,1,0,0,0,0,0,1,0,1};
int main(){
	long long int n,day=2,last=1,m=1,pppp=2;
    cin>>n;
    n-=1;
    while(n>=0){
        if(prime[pppp]!=1){
            n-=2*last;
            last*=2;
        }else{
            n-=3*last;
            last*=3;
        }
        day++;
        pppp++;
        if(pppp/a[m]==1){
            pppp=1;
            m++;
        }
    }
    cout<<day-1;
}
