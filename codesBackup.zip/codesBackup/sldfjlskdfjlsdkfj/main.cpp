#include <iostream>

using namespace std;

int main()
{
    int n;
    cin>>n;
    int mac=10000000;
    int s,t;
    for(int i=0;i<n/7+1;i++){
        int sub=(n-i*7)/3;
        if(sub>0) sub++;
        if(sub*220+i*480<mac){
            s=i;
            t=sub;
            mac=sub*220+i*480;
        }
    }
    cout<<mac<<'\n'<<s<<' '<<t;
    return 0;
}
