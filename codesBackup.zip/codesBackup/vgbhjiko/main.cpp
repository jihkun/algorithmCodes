#include <iostream>

using namespace std;
int n, arr[11]={1,20,1,30,3,40,5,50,1000,1,0},m=0;

void f(int idx, int sum, bool chk)
{
    if(idx==10){
        m=max(m,sum);
        return;
    }
    if(chk==true) f(idx+1, sum, false);
    else{
        f(idx+1,sum,false);
        f(idx+1,sum+arr[idx],true);
    }
}
int main()
{
    f(0,0,0);
    cout<<m;
    return 0;
}
