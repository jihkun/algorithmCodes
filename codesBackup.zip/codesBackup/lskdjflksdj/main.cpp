#include <bits/stdc++.h>
#define MAX 987654321
using namespace std;
bool v[1000][1000];
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=0;i<m;i++){
        int sub1,sub2;
        cin>>sub1>>sub2;
        v[sub1][sub2]=true;
    }
    for(int k=1;k<=n;k++){
        for(int i=1;i<=n;i++){
            for(int j=1;j<=n;j++){
                if(!v[i][j]){
                if(v[i][k]&&v[k][j]){
                    v[i][j]=true;
                }
            }
            }
        }
    }
    int cnt=0;
    for(int i=1;i<=n;i++){
        bool flag=true;
        for(int j=1;j<=n;j++){
            if(i==j) continue;
            if(!v[i][j]&&!v[j][i]){
                flag=false;
            }
        }
        if(flag) cnt++;
    }
    cout<<cnt;
    return 0;
}
