#include <iostream>
#include <vector>
using namespace std;
vector<int> L(string a){
    int l=0, i=1, siz=a.size();
    vector<int> dat(siz,0);
    while(i<siz){
        if(a[l]==a[i]){
            dat[i++]=++l;
        }else{
            if(l!=0){
                l=dat[l-1];
            }else{
                dat[i]=0;
                i++;
            }
        }
    }
    return dat;
}
//int KMP(string b, string c){
//    int i=0, l=0;
//    int bsiz=b.size(), csiz=c.size();
//    vector<int> dat=L(c);
//    while(i<bsiz){
//        if(b[i]==b[l]){
//            i++;l++;
//        }
//        if(l==csiz){
//            r=dat[r-1];
//        }else if(i<bsiz&&b[i]!=c[l]){
//            if(l!=0){
//                l=dat[l-1];
//            }else{
//                l++;
//            }
//        }
//    }
//
//}
int main()
{
    string a;
        cin>>a;
    while(a!="."){
        vector<int> dat=L(a);
        int asiz=a.size();
        cout<<asiz/(asiz-dat[asiz-1])<<'\n';
        cin>>a;
    }
    return 0;
}
