#include <bits/stdc++.h>

using namespace std;
queue<int> q;
int d[100005];
int main()
{
    int n,k;
    cin>>n>>k;
    q.push(n);
    while(!q.empty()){
        int fi=q.front();
        if(fi==k){
            cout<<d[fi];
            return 0;
        }
        q.pop();
        if(fi-1>=0&&d[fi-1]==0){
            q.push(fi-1);
            d[fi-1]=d[fi]+1;
        }
        if(fi+1<=100000&&d[fi+1]==0){
            q.push(fi+1);
            d[fi+1]=d[fi]+1;
        }
        if(fi*2<=100000&&d[fi*2]==0){
            q.push(fi*2);
            d[fi*2]=d[fi];
        }

    }
    return 0;
}
