#include <iostream>

using namespace std;

int main()
{
    bool flag=true;
    int a[1000][2];
    for(int i=0;i<3;i++){
        cin>>a[i][0]>>a[i][1];
    }
    int cnt=0,cnt2=0;
    a[3][0]=a[0][0]; a[3][1]=a[0][1];
    for(int i=0;i<3;i++){
        cnt+=a[i][0]*a[i+1][1];
    }
    for(int i=0;i<3;i++){
        cnt2+=a[i][1]*a[i+1][0];
    }
    int c=cnt-cnt2;
    cin>>a[2][0]>>a[2][1];
    cnt=0;
    cnt2=0;
    for(int i=0;i<3;i++){
        cnt+=a[i][0]*a[i+1][1];
    }
    for(int i=0;i<3;i++){
        cnt2+=a[i][1]*a[i+1][0];
    }
    int c2=cnt-cnt2;
    cout<<c<<' '<<c2<<' ';
    if((c2<0&&c<0)||(c2>0&&c>0)){
        cout<<0;
        return 0;
    }
    cout<<1;
    return 0;
    return 0;
}
