#include <bits/stdc++.h>

using namespace std;

int main() {
    int n;
    cin >> n;
    vector<vector<int>> voters(n, vector<int>(n));
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            cin >> voters[i][j];
        }
    }

    vector<vector<vector<int>>> dp(n + n, vector<vector<int>>(n, vector<int>(n, -1)));

    function<int(int, int, int)> solve = [&](int x1, int y1, int d) {
        int x2 = d - x1;
        int y2 = d - y1;

        if (x1 >= n || x2 >= n || y1 >= n || y2 >= n || x1 < 0 || x2 < 0 || y1 < 0 || y2 < 0) {
            return -999999;
        }

        if (x1 == n - 1 && y1 == n - 1) {
            return voters[x1][y1];
        }

        if (dp[d][x1][y1] != -1) {
            return dp[d][x1][y1];
        }

        int voters_count = voters[x1][y1] + (x1 != x2 || y1 != y2) * voters[x2][y2];

        int path1 = solve(x1 + 1, y1, d + 1);
        int path2 = solve(x1, y1 + 1, d + 1);
        int path3 = solve(x1 + 1, y2, d + 1);
        int path4 = solve(x1, y2 + 1, d + 1);

        return dp[d][x1][y1] = voters_count + max({path1, path2, path3, path4});
    };

    cout << solve(0, 0, 0) << endl;

    return 0;
}
