#include <bits/stdc++.h>

using namespace std;
string a,Mi="{";
priority_queue<string> q;
int main()
{
    cin>>a;
    for(int i=0;i<a.size()-2;i++){
        string tmp;
        for(int j=i+1;j<a.size()-1;j++){
            tmp=a;
            reverse(tmp.begin(),tmp.begin()+i);
            reverse(tmp.begin()+i+1,tmp.begin()+j);
            reverse(tmp.begin()+j+1,tmp.end());
            Mi=min(Mi,tmp);
        }
    }
    cout<<Mi;
    return 0;
}
