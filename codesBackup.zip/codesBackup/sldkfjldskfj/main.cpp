#include <bits/stdc++.h>

using namespace std;
map<int,int> ma;
struct dat {
    int n;
    dat(int num) : n(num){}    // ������ ����
    bool operator<(const dat s) const {
        return ma[this->n] > ma[s.n];
    }
};
priority_queue<dat> q;
int dist[100000];
vector<int> v[10000];
map<int, int> pointer;
int main()
{
    int t;
    cin>>t;
    while(t--){
        int n,m;
        cin>>n;
        int a[n+1];
        for(int i=n;i>0;i--){
            int sub;
            cin>>sub;
            a[i]=sub;
            ma[sub]=i;
            pointer[sub]=i;
        }
        cin>>m;
        for(int i=0;i<m;i++){
            int sub,sub2;
            cin>>sub>>sub2;
            v[sub].push_back(sub2);
            dist[sub2]++;
        }
        for(int i=1;i<=n;i++){
            if(dist[i]==0){
                q.push(-i);
            }
        }
        while(!q.empty()){
            int di=-1*q.top().n;
            q.pop();
            for(int i=0;i<v[di].size();i++){
                int ni=v[di][i];
                dist[ni]--;
                int sub=pointer[ni];
                int sub2=a[di];
                a[di]=a[ni];
                a[ni]=sub2;
                pointer[ni]=pointer[di];
                pointer[di]=sub;
                if(dist[ni]==0){
                    q.push(-ni);

                }
            }
        }
        for(auto x:a){
            cout<<x<<' ';
        }
    }
    return 0;
}
