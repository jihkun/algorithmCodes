import java.util.Scanner;
import java.util.ArrayList;
public class Main{
    static ArrayList v[100000];
	public static void main(String args[]){
        Scanner in=new Scanner(System.in);
        int n=in.nextInt();
        for(int i=0;i<n;i++){
            cout<<i;
        }
        return;
	}
}
