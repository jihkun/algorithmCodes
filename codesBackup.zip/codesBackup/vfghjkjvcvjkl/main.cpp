#include <bits/stdc++.h>

using namespace std;
bool chk[101][101];
int day[101][101];
int a[101][101];
int di[]={0,0,1,-1},dj[]={1,-1,0,0};
queue<pair<int,int> > q;
int cnt;
int main()
{
    long long int x,y,lasti=0,lastj=0;
    cin>>x>>y;
    for(int i=0;i<x;i++){
        for(int j=0;j<y;j++){
            cin>>a[i][j];
            if(a[i][j]==9){
                    q.push({i,j});
                    cnt++;
            }
        }
    }
    while(!q.empty()){
        int ti=q.front().first;
        int tj=q.front().second;
        q.pop();
        for(int i=0;i<4;i++){
            int ni=ti+di[i];
            int nj=tj+dj[i];
            if(ni>=0&&ni<x&&nj>=0&&nj<y){
                if(chk[ni][nj]==0&&a[ni][nj]==0){
                    q.push({ni,nj});
                    day[ni][nj]=day[ti][tj]+1;
                    cnt++;
                    lasti=ni;
                    lastj=nj;
                }
            }
        }
    }
    if(cnt==x*y) cout<<0<<'\n'<<day[lasti][lastj];
    else cout<<cnt<<'\n'<<day[lasti][lastj];
    return 0;
}
