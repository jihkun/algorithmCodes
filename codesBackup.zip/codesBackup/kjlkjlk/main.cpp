#include <bits/stdc++.h>
#define INF 987654321
using namespace std;
struct le {
    pair<long long int,int> s;
    int p;

    le(pair<long long int,int> sub2, int sub) : s(sub2), p(sub) {}

    bool operator<(const le& other) const {
       if(s==other.s){
            return s<other.s;
       }
        return p<other.p;
    }

};
vector<pair<int,int> > v[10001];
int n,m;
int l;
long long int dis(int s, int e){
    long long int dist[n+1][l+1];
    priority_queue<le> q;
    if(s==e) return 0;
    for (int i = 0; i <= 20; i++) {
		fill(dist[i], dist[i] + n,INF);
	}
    q.push({{0,s},0});
    while(!q.empty()){
        long long int pl=-q.top().s.first;
        int point=q.top().s.second;
        int cl=-q.top().p;
        q.pop();
        for(int i=0;i<v[point].size();i++){
            int next_point=v[point][i].first;
            long long int next_pl=v[point][i].second;
            if(dist[next_point][cl]>next_pl+pl){
                dist[next_point][cl]=next_pl+pl;
                q.push({{-dist[next_point][cl],next_point},-cl});
            }
            if(cl<l&&dist[next_point][cl+1]>pl){
                dist[next_point][cl+1]=pl;
                q.push({{-dist[next_point][cl+1],next_point},-(cl+1)});
            }

        }
    }
    long long int mi=10000000;
    for(int i=0;i<=l;i++){
        mi=min(mi,dist[e][i]);
    }
    return mi;
}
int main()
{
    cin>>n>>m>>l;
    for(int i=0;i<m;i++){
        int s,e,p;
        cin>>s>>e>>p;
        v[s].push_back({e,p});
        v[e].push_back({s,p});
    }
    cout<<dis(1,n);
    return 0;
}
