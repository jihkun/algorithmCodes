#include <iostream>
#include <vector>
using namespace std;

vector<int> L(string a){
    int l=0, i=1, siz=a.size();
    vector<int> dat(siz,0);
    while(i<siz){
        if(a[l]==a[i]){
            dat[i++]=++l;
        }else{
            if(l!=0){
                l=dat[l-1];
            }else{
                dat[i]=0;
                i++;
            }
        }
    }
    return dat;
}

void KMP(const vector<int>& dat, const string& a, const string& c){
    string b=c;
    int i = 0, l = 0;
    int bsiz = b.size();
    int asiz = a.size();

    while(i < bsiz){
        if(b[i] == a[l]){
            i++; l++;
        }
        if(l == asiz){
            b.erase(max(0,i-l), asiz);
            bsiz-=asiz;
            i = max(i - l-1,0);
            l = 0;

        } else if(i < bsiz && b[i] != a[l]){
            if(l != 0){
                l = dat[l - 1];
            } else {
                i++;
            }
        }
    }

    cout << b << '\n';
}

int main()
{
    int n;
    string a;
    while(true){
        cin >> n >> a;
        if(cin.eof()) break;
        cin.ignore();
        vector<int> dat = L(a);
        for(int i = 0; i < n; i++){
            string sub;
            getline(cin,sub);
            KMP(dat, a,sub);
        }
    }
    return 0;
}
