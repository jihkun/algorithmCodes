#include <bits/stdc++.h>
using namespace std;
priority_queue<pair<int,int> > q;
int main()
{
    int n;
    cin>>n;
    for(int i=1;i<=n;i++){
        string a;
        cin>>a;
        int ap,lp,pp;
        for(int i=0;i<a.size();i++){
            if(a[i]=='A') ap++;
            else if(a[i]=='L') lp++;
            else pp++;
        }
        if(pp<3){
            q.push({ap-pp-lp/2,i});
        }
    }
    while(!q.empty()){
        cout<<q.top().second<<' ';
        q.pop();
    }
    return 0;
}
