 #include <iostream>
#include <queue>
using namespace std;
int a[100000];
int chk[100000];
priority_queue<pair<int,int> > q;
int main()
{
    int n, m;
    cin>>n>>m;
    for(int i=1;i<=n;i++){
        cin>>a[i];
        a[i]=m-a[i];
    }
    if(a[1]<a[2]){ q.push({a[1],1});chk[1]=a[1];}
    if(a[1]==a[2]||a[n]==a[n-1]){ cout<<-1<<' '; return 0;}
    if(a[n]<a[n-1]){ q.push({a[n],n});chk[n]=a[n];}
    for(int i=2;i<n;i++){
        if(a[i]<a[i-1]&&a[i]<a[i+1]){ q.push({a[i],i});chk[i]=a[i];}
        if(a[i]==a[i-1]||a[i]==a[i+1]){ cout<<-1<<' '; return 0;}
    }
    int ma=0;
    while(!q.empty()){
        int ti=q.top().second;
        q.pop();
        for(int i=-1;i<=1;i++){
            if(i==0) continue;
            int ni=ti+i;
            if(chk[ni]==0&&ni>=0&&ni<=n){
                chk[ni]=chk[ti]+a[ni];
                q.push({chk[ni],ni});
                ma=max(chk[ni] ,ma);
            }
        }
    }
    cout<<ma;
    return 0;
}
