#include <bits/stdc++.h>

using namespace std;
int v[10000001];
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>v[i];
    }
    int n2;
    cin>>n2;
    for(int i=0;i<n2;i++){
        int sub;
        cin>>sub;
        int lower=lower_bound(v,v+n,sub)-v;

        if(v[lower]==sub) cout<<lower+1<<' ';
        else cout<<-1<<' ';
    }

    return 0;
}
