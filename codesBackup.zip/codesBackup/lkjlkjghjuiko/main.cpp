#include <iostream>
using namespace std;

bool visited[500][500];
bool red_visited[500][500];
int di[] = {0, 0, -1, 1};
int dj[] = {1, -1, 0, 0};
string arr[500];
int n;

void dfs(int i, int j, char chk, char second) {
    if (second == 'N') visited[i][j] = true;
    else red_visited[i][j] = true;

    for (int k = 0; k < 4; k++) {
        int ni = di[k] + i;
        int nj = dj[k] + j;  // ����: nj = dj[k] + j;
        if (ni >= 0 && ni < n && nj >= 0 && nj < n) {
            if (second == 'N') {
                if (!visited[ni][nj] && arr[ni][nj] == chk) {
                    dfs(ni, nj, chk, second);
                }
            } else {
                if (!red_visited[ni][nj] && (arr[ni][nj] == chk || arr[ni][nj] == second)) {
                    dfs(ni, nj, chk, second);
                }
            }
        }
    }
}

int main() {
    cin >> n;
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    int rcnt = 0, cnt = 0;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (!visited[i][j]) {
                rcnt++;
                dfs(i, j, arr[i][j], 'N');
            } else if (!red_visited[i][j]) {
                cnt++;
                if (arr[i][j] == 'R' || arr[i][j] == 'G') {
                    dfs(i, j, 'R', 'G');
                } else {
                    dfs(i, j, 'B', 'B');
                }
            }
        }
    }

    cout << rcnt << ' ' << cnt;
    return 0;
}
