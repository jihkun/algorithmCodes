#include<bits/stdc++.h>
using namespace std;
#define sup "sdofjaosdljfhlaksdhfkjhdaslkfjhasdkfjhlkajdsfh.txt"
int main(){
    time_t now=time(NULL);
    FILE* f=fopen(sup,"a+");
    fprintf(f,"\n do not read this.\n to read this can make problem.\n if you find bug, call me.\n");
    fprintf(f,"\nlog on at time : %lld\n",now);
    fclose(f);
    return 0;
}
