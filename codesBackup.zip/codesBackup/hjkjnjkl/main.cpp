#include<bits/stdc++.h>
using namespace std;
int main(){
    for(int i=0;i<=10;i++){
  	int a,b,c,l;
  	cin>>a>>b>>c;
  	for(int i=c;i<=a;i+=b){
    	cout<<i<<' ';
    }
    }
	return 0;
}
