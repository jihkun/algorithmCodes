#include <iostream>
#include <vector>
using namespace std;
int arr[10001];
int dp[10001];
vector<int> v[10001];
int main() {
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    dp[0]=arr[0];
    v[0].push_back(arr[0]);
    dp[1]=arr[0]+arr[1];
    v[1].push_back(arr[0]);
    v[1].push_back(arr[1]);
    for(int i=2;i<n;i++){
        dp[i]=max(dp[i-2]+arr[i],max(dp[i-1],dp[i-3]+arr[i]+arr[i-1]));
        if(dp[i]==dp[i-2]+arr[i]){
            v[i]=v[i-2];
            v[i].push_back(arr[i]);
        }
        if(dp[i]==dp[i-1]) v[i]=v[i-1];
        if(dp[i]==dp[i-3]+arr[i-1]+arr[i]){
            v[i]=v[i-3];
            v[i].push_back(arr[i]);
            v[i].push_back(arr[i-1]);
        }
    }
    cout<<dp[n-1]<<'\n';
    for(auto i:v[n-1]){
        cout<<i<<' ';
    }
    return 0;
}
