#include <iostream>
#include <queue>
using namespace std;
int a[10000][10000];
int chk[10000][10000];
int touch[10000][10000];

int di[]={0,0,1,-1},dj[]={1,-1,0,0};
queue<pair<int,int> > q;
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            cin>>a[i][j];
            if(a[i][j]==0) q.push({i,j});
        }
    }
    int ma=0;
    cout<<endl;
    while(!q.empty()){
        int ti=q.front().first;
        int tj=q.front().second;
        q.pop();
        for(int i=0;i<4;i++){
            int ni=ti+di[i];
            int nj=tj+dj[i];
            if(ni>=0&&ni<n&&nj>=0&&nj<m){
                if(a[ni][nj]==1) touch[ni][nj]++;
                if(a[ni][nj]==1&&chk[ni][nj]==0&&touch[ni][nj]>=2){
                    chk[ni][nj]=chk[ti][tj]+1;
                    q.push({ni,nj});
                    ma=max(chk[ni][nj],ma);
                }
            }
        }
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            cout<<chk[i][j]<<' ';
        }
        cout<<'\n';
    }
    cout<<ma;
    return 0;
}
