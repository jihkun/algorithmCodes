#include <iostream>
#include <fstream>
#include <vector>
#include <windows.h>
#include <map>
#include <string>
using namespace std;
int ar[100][100];
map<int,pair<int,int> > m;
pair<vector<int>,pair<int,int> > rc(vector<int> a){
    int sub=rand()%a.size();
    int dat=a[sub];
    a.erase(a.begin()+sub);
    pair<int,int> sub2=m[dat];
    ar[sub2.first][sub2.second]=dat;
    return make_pair(a,sub2);
}
int main()
{
    int x=0,y=0,rp=0;
    ifstream setting("setting.obt");
    if(setting.is_open()){
        vector<string> buffer;
        string sub;
        while(getline(setting,sub)){
            buffer.push_back(sub);
        }
        ifstream dat(buffer[0]);
        if(!dat.is_open()) return 1;
        int i=0,j=0;
        while(getline(dat,sub)){
            int point=0,bp=0;;
            while(sub.size()>point){
                bp=point;
                for(;sub[point]!=' '&&point<sub.size();point++);
                int a=stoi(sub.substr(bp,point-bp));
                ar[i][j]=a;
                if(a!=0&&a!=-1) rp++;
                m[a]=make_pair(i,j);
                i++;
            }
            j++;
        }
        x=stoi(buffer[1]);
        y=stoi(buffer[2]);
    }
    srand(time(NULL));
    vector<int> random_array;
    for(int i=1;i<=rp;i++){
        random_array.push_back(i);
    }
    for(int i=0;i<rp;i++){
        pair<vector<int>,pair<int,int> > sub=rc(random_array);
        random_array=sub.first;
        cout<<sub.second.first<<' '<<sub.second.second<<'\n';
        for(int i=0;i<x;i++){
            for(int j=0;j<y;j++){
                cout<<ar[i][j]<<' ';
            }
            cout<<'\n';
        }
    }
    return 0;
}
