#include <bits/stdc++.h>
using namespace std;
int main(){
    int n,m,c,k;
    cin>>n>>m>>c>>k;
    int sub=n*60+m-c-k;
    cout<<sub/60<<' '<<sub%60;
}
