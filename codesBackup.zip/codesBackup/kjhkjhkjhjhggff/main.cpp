#include <iostream>
#include <queue>
using namespace std;
string a[100][100];
int chk[100][100][100];
int di[]={0,0,1,-1,0,0};
int dj[]={1,-1,0,0,0,0};
int dx[]={0,0,0,0,1,-1};
struct dat{
    int x,y,z;
    bool pass;
    bool operator<(const dat &d) const{
        if(x<d.x) return true;
        else if(d.x==x){
            if(y<d.y) return true;
            else if(y==d.y) return z<d.z;
            else return false;
        }else return false;
    }
};
int main()
{
    priority_queue<dat> q;
    queue<dat> ba;
    int n,m,c;
    cin>>n>>m>>c;
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            cin>>a[i][j];
            for(int k=0;k<c;k++){
                if(a[i][j][k]=='9'){
                    q.push({i,j,k,false});
                    chk[i][j][k]=1;
                }
                if(a[i][j][k]=='2'){
                    ba.push({i,j,k,false});
                    chk[i][j][k]=-1;
                }
            }
        }
    }
    int turn_now=1;
    while(!q.empty()){
        dat sub=q.top();
        q.pop();
        int ti=sub.x,tj=sub.y,tz=sub.z;
        if(turn_now<chk[ti][tj][tz]){
            queue<dat> tmpqueue;
            while(!q.empty()){
                dat sub2=ba.front();
                ba.pop();
                int ti2=sub2.x;
                int tj2=sub2.y;
                int tz2=sub2.z;
                int range=0;
                if(sub2.pass) range=6;
                else range=4;
                a[ti2][tj2][tz2]='0';
                for(int i=0;i<range;i++){
                    int ni=ti2+di[i];
                    int nj=tj2+dj[i];
                    int nz=tz2+dx[i];
                    if(a[ni][nj][nz]!='9'){
                        if(a[ni][nj][nz]=='7') tmpqueue.push({ni,nj,nz,true});
                        else tmpqueue.push({ni,nj,nz,false});
                    }
                }
            }
            ba=tmpqueue;
            turn_now=chk[ti][tj][tz];
        }
        bool pass=sub.pass;
        int range;
        if(a[ti][tj][tz]=='7') range=6;
        else range=4;
        for(int i=0;i<range;i++){
            int ni=ti+di[i];
            int nj=tj+dj[i];
            int nz=tz+dx[i];
            if(ni>=0&&ni<n&&nj>=0&&nj<m&&nz>=0&&nz<c){
                if(chk[ni][nj][nz]==0&&a[ni][nj][nz]=='0'){
                    q.push({ni,nj,nz,false});
                    if(pass) chk[ni][nj][nz]=chk[ti][tj][tz];
                    else chk[ni][nj][nz]=chk[ti][tj][tz]+1;
                }else if(chk[ni][nj][nz]==0&&a[ni][nj][nz]=='1'){
                    q.push({ni,nj,nz,true});
                    chk[ni][nj][nz]=chk[ti][tj][tz]+1;
                }
            }
        }
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            for(int l=0;l<c;l++){
                cout<<chk[i][j][l];
            }
            cout<<'\n';
        }
        cout<<"\n\n\n\n";
    }
    return 0;
}
