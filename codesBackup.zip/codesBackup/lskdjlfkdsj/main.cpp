#include <bits/stdc++.h>
#define MAX 987654321
using namespace std;
int dp[10001][3]={MAX};
int arr[10001];
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    for(int i=0;i<n;i++){

    }
    cout<<
    return 0;
}
