#include <bits/stdc++.h>
using namespace std;
vector<int> v[100000];
int dist[100000];
queue<int> s;
queue<int> q;
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=0;i<m;i++){
        int sub,sub2;
        cin>>sub>>sub2;
        dist[sub2]++;
        v[sub].push_back(sub2);
    }
    for(int i=1;i<=n;i++){
        if(dist[i]==0){
            q.push(i);
        }
    }
    while(!q.empty()){
        int di=q.front();
        q.pop();
        for(int i=0;i<v[di].size();i++){
            int ni=v[di][i];
            if(dist[ni]!=-1){
                dist[ni]--;
                if(dist[ni]==0){
                    q.push(ni);
                }
            }
        }
        s.push(di);
    }
    while(!s.empty()){
        cout<<s.front()<<' ';
        s.pop();
    }
    return 0;
}
