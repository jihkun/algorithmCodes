#include <iostream>

using namespace std;

int main()
{
    int n,cnt=0;
    cin>>n;
    for(int i=1;i<=n;i++){
        int is=i, sub=is%10;
        is/=10;
        int dis=is%10-sub;
        sub=is%10;
        while(is){
            is/=10;
            if(is%10-sub==dis){
                sub=is%10;
            }else{
                break;
            }
        }
        if(is==0) cnt++;
    }
    cout<<cnt;
    return 0;
}
