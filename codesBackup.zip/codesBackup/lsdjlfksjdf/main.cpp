#include <bits/stdc++.h>

using namespace std;
map<string,int> a;
int main()
{
    int mx,n;
    cin>>n;
    for(int i=0;i<n;i++){
        string s;
        cin>>s;
        a[s]++;
        mx=max(a[s],mx);
    }
    for(auto x:a){
        if(x.second==mx){
            cout<<x.first;
            return 0;
        }
    }
    return 0;
}
