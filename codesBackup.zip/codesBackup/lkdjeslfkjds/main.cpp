#include <iostream>

using namespace std;

int main()
{
    string a;
    cin>>a;
    for(int i=0;i<a.size()-1;i++){
        cout<<a[i]<<" to the ";
    }
    cout<<a[a.size()-1];
    return 0;
}
