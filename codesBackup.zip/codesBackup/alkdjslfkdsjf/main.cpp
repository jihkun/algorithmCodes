#include <bits/stdc++.h>

using namespace std;
string a,b;
int arr[1001][1001];
stack<char> s;
void dfs(int i, int j){
    if(i-1<0||j-1<0) return;
    if(a[i-1]!=b[j-1]){
        if(arr[i-1][j]>arr[i][j-1]){
            dfs(i-1,j);
        }else{
            dfs(i,j-1);
        }
    }else{
        s.push(a[i-1]);
        if(i-1>=1&&j-1>=1) dfs(i-1,j-1);
    }
}
int main()
{
    cin>>a>>b;
    for(int i=0;i<a.size();i++){
        for(int j=0;j<b.size();j++){
            if(a[i]==b[j]){
                arr[i+1][j+1]=arr[i][j]+1;
            }else{
                arr[i+1][j+1]=max(arr[i][j+1],arr[i+1][j]);
            }
        }
    }
    cout<<arr[a.size()][b.size()]<<'\n';
    dfs(a.size(),b.size());
    while(!s.empty()){
        cout<<s.top();
        s.pop();
    }
    return 0;
}
