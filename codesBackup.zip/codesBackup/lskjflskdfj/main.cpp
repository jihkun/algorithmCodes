#include <iostream>
#include <queue>
using namespace std;
int a[1002][1002];
int n,m;
queue<pair<int,int> > q;
int di[]={-1,1,0,0},dj[]={0,0,-1,1};
int main()
{
    int ma=0;
    cin>>m>>n;
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            cin>>a[i][j];
            if(a[i][j]==1){
                q.push({i,j});
                ma++;
            }
        }
    }
    if(m*n==ma){
        cout<<0;
        return 0;
    }
    ma=0;
    while(!q.empty()){
        int i=q.front().first,j=q.front().second;
        q.pop();
        for(int k=0;k<4;k++){
            int ni=i+di[k],nj=j+dj[k];
            if(ni>=0&&ni<n&&nj>=0&&nj<m){
                if(a[ni][nj]==0){
                    q.push({ni,nj});
                    a[ni][nj]=a[i][j]+1;
                    ma=max(ma,a[ni][nj]);
                }
            }
        }
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            if(a[i][j]==0){
                cout<<-1;
                return 0;
            }
        }
    }
    cout<<ma;
    return 0;
}
