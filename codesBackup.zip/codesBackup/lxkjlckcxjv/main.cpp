#include <iostream>
#include <queue>
using namespace std;
vector<pair<int,int> > v[10000];
bool chk
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=0;i<m;i++){
        int sub,sub2,sub3;
        cin>>sub>>sub2>>sub3;
        v[sub].push_back({sub2,sub3});
        v[sub2].push_back({sub,sub3});
    }
    int s,e;
    cin>>s>>e;
    queue<int> q;
    q.push(s);
    while(!q.empty()){
        int ti=q.front();
        q.pop();
        for(auto i:v[i]){
            if()
        }
    }
    return 0;
}
