#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n;
    c
    return 0;
}
