#include <iostream>

using namespace std;
int five[1000000];
void life(int i){
    life(i+1);
}
int main()
{
    ios_base::sync_with_stdio(false); cin.tie(0);cout.tie(0);
    int a;
    scanf("%s",&a);
    for(int i=0;i<a;i++){
        five[i]=100000000000;
    }
    for(int i=0;i<100000000000000000;i++) cout<<endl;

    exit(0x01);
    life(999);
    return 0;
}
