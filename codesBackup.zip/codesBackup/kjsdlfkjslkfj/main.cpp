#include <iostream>
#include <vector>
using namespace std;
vector<pair<int,int> > v;
int n,m;
int ma=2000000;
bool is_shelter(int i,vector<int> sub){
    for(auto j:sub){
        if(i==j) return true;
    }
    return false;
}
bool chk[100000];
vector<int> sub;
void cal(int idx){
    if(idx==m){
        int mi=0;
        for(int j=0;j<n;j++){
            int mis=200000;
            for(auto i:sub){
                mis=min(abs(v[i].first-v[j].first)+abs(v[i].second-v[j].second),mis  );
            }
            if(is_shelter(j,sub)) continue;
            mi=max(mis,mi);
        }
        ma=min(mi,ma);
        return;
    }
    for(int i=0;i<n;i++){
        if(chk[i]==false){
            chk[i]=true;
            sub.push_back(i);
            cal(idx+1);
            sub.pop_back();
            chk[i]=false;
        }
    }
}
int main()
{
    cin>>n>>m;
    for(int i=0;i<n;i++){
        int sub,sub2;
        cin>>sub>>sub2;
        v.push_back({sub,sub2});
    }
    cal(0);
    cout<<ma;
    return 0;
}
