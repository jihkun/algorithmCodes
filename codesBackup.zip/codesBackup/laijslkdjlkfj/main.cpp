#include <bits/stdc++.h>
#define inf 1000000000
using namespace std;

int main()
{
    int stp,n,m;
    cin>>n>>m>>stp;
    vector<pair<int,int> > v[n+1];
    for(int i=1;i<=m;i++){
        int f,t,va;
        cin>>f>>t>>va;
        v[f].push_back({t,va});
    }
    int dist[n+1];
    fill(dist,dist+n+1,inf);
    dist[stp]=0;
    priority_queue<pair<int,int> > q;
    q.push({0,stp});
    while(!q.empty()){
        int now=q.top().second;
        q.pop();
        for(int i=0;i<v[now].size();i++){
            int tom=v[now][i].first;
            int toV=v[now][i].second;
            if(dist[tom]>dist[now]+toV){
                dist[tom]=dist[now]+toV;
                q.push({-dist[tom],tom});
            }
        }
    }
    for(int i=1;i<=n;i++){
        if(dist[i]==inf){
            cout<<"INF"<<'\n';
        }else{
            cout<<dist[i]<<'\n';
        }
    }
    return 0;
}
