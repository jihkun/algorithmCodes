#include <iostream>
#include <vector>
using namespace std;
int arr[20][20];
int n;
vector<pair<int,int> > v;
int mi=10000000;
int dp[100][2<<16];
int finder(int l, int a){
    if(a==(1<<n)-1){
        if(arr[l][0]==0) return 987654321;
        return arr[l][0];
    }
    int &ans=dp[l][a];
    if(ans!=0) return ans;
    ans=987654321;
    for(int i=0;i<n;i++){
        if(arr[l][i]==0) continue;
        if((1<<i)&a) continue;
        ans=min(ans,arr[l][i]+finder(i,a|(1<<i)));
    }
    return ans;
}
int main()
{
    cin>>n;
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            cin>>arr[i][j];
        }
    }
    cout<<finder(0,1);
    return 0;
}
