#include <bits/stdc++.h>
using namespace std;
int main(){
	int a,b,c,d;
  	cin>>a>>b>>c>>d;
  	cout<<((a*60+b)-(c+d))/60<<' '<<((a*60+b)-(c+d))%60;
   return 0;
}
