#include <bits/stdc++.h>
using namespace std;
int a[1000];
int main()
{
    int n,cnt=0,h;
    cin>>n;
    for(int i=0;i<n;i++){
        cnt=0;
        for(int j=0;j<4;j++){
            int sub;
            cin>>sub;
            cnt+=sub;
        }
        a[i]=cnt;
        if(i==0) h=cnt;
    }
    sort(a,a+n);
    for(int i=0;i<n;i++){
        if(h==a[i]){ cout<<i+1;return 0;}
    }
    return 0;
}
