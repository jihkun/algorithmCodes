#include <deque>

using namespace std;
int main()
{
    int n,m;
    cin>>n>>m;
    cout<<m*2-n;
    return 0;
}
