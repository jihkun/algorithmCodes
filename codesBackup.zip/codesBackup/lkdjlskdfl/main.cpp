#include <iostream>
using namespace std;

int main()
{
    cout<<"special characters\n";
    cout<<"[\\n,\\\",\\\\] is very important.";
    return 0;
}
