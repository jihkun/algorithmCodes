#include <iostream>

using namespace std;

int main()
{
    int n;
    cin>>n;
    for(int i=1;i<=n;i++){
        int st=i%10,et=0,sum=0;
        i/=10;
        et=i%10; i/=10;
        sum=et-st;
        while(n>=10){
            et=st;
            st=i%10;
            if(et-st=sum-1)
        }
    }
    return 0;
}
