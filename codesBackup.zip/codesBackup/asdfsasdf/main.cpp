#include <iostream>

using namespace std;

int main()
{
    int i,m,cnt=0,mi=99999;
    cin>>i>>m;
    for(;i<=m;i++){
        int fcnt=0;
        for(int j=1;j<=i/2;j++){
            if(i%j==0){
                fcnt++;
            }
        }
    if(fcnt<=1){
        cnt+=i;
        mi=min(mi,i);
    }
    }
    cout<<cnt<<'\n'<<mi;
    return 0;
}
