#include <bits/stdc++.h>
using namespace std;
int datasor[100002];
int main()
{
    int n,all=0;
    cin>>n;
    for(int i=0;i<n;i++){
        int sub;
        cin>>sub;
        datasor[sub]++;
    }
    for(int i=0;i<=100002;i++){
        if(all>n) break;
        if(datasor[i]>0) for(int j=0;j<datasor[i];j++) cout<<i<<' ';
        all+=datasor[i];
    }
    return 0;
}
