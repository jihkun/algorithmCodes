#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    std::ifstream readFile;           
    readFile.open("words.txt");   


    cout << "Hello world!" << endl;

    return 0;
}
