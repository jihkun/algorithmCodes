#include <bits/stdc++.h>
using namespace std;
int a[11][11];
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<10;i++){
        for(int j=0;j<10;j++){
            cin>>a[i][j];
        }
    }
    for(int i=9;i>=0;i--){
        int cnt=0;
        for(int j=0;j<10;j++){
            if(a[i][j]==1) cnt=0;
            else cnt++;
            if(cnt==n){
                cout<<i+1;
                return 0;
            }
        }
    }
    cout<<-1;
    return 0;
}
