#include <iostream>
#include <cstring>
#include <vector>
#include <stack>
#include <algorithm>
using namespace std;
int a[10001],d[10001],id;
bool chk[10001];
int dat[100000];
vector<vector<int> > scc;
vector<int> v[10001];
stack<int> s;
int dfs(int visited){
    d[visited]=++id;
    s.push(visited);
    int p=d[visited];
    for(int i=0;i<v[visited].size();i++){
        int ni=v[visited][i];
        if(d[ni]==0) p=min(p,dfs(ni));
        else if(!chk[ni]) p=min(p,d[ni]);d
    }
    if(p==d[visited]){
        vector<int> sub;
        while(true){
            int sub2=s.top();
            sub.push_back(sub2);
            chk[sub2]=true;
            s.pop();
            if(sub2==visited) break;
        }
        sort(sub.begin(),sub.end());
        scc.push_back(sub);
    }
    return p;
}
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        int sub,sub2;
        cin>>sub>>sub2;
        v[sub].push_back(sub2);
    }
    for(int i=1;i<=n;i++){
        if(chk[i]==false){
            dfs(i);
        }
    }
    if(scc.size()<=1) cout<<"Yes";
    else cout<<"No";
    return 0;
}
