#include <bits/stdc++.h>

using namespace std;
int ne[101];
bool chk[101];
int main()
{
    int n,cnt=0,use=0;
    cin>>use>>n;
    for(int i=0;i<n;i++){
        cin>>ne[i];
        if(chk[ne[i]]!=true){
            chk[ne[i]]=true;
            cnt++;
        }
    }
    cout<<cnt-use;
    return 0;
}
