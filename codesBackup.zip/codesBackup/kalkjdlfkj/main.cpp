#include <bits/stdc++.h>

using namespace std;
vector<int> v[1000000];
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=0;i<=n;i++) v[i].push_back(i);
    for(int i=0;i<m;i++){
        int sub2,sub3,sub;
        cin>>sub>>sub2>>sub3;
        if(sub==1){
            int j;
            for(j=0;j<v[sub2].size();j++){
                if(v[sub2][i]==sub3){ cout<<"YES"<<'\n'; sub=9;}
            }
        if(sub!=9) cout<<"NO\n";
        continue;
        }
        int ma=max(v[sub2].size(),v[sub3].size());
        for(int i=0;i<ma;i++){
            if(v[sub2].size()>i){
                v[sub3].push_back(v[sub2][i]);
            }
            if(v[sub3].size()>i){
                v[sub2].push_back(v[sub3][i]);
            }
            cout<<max(v[sub2].size(),v[sub3].size())<<'\n';
        }

    }
    return 0;
}
