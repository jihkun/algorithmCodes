#include <iostream>
#include <algorithm>
using namespace std;
int a[100001];
int main()
{
    string a,tmp;
    cin>>a;
    tmp=a;
    sort(a.begin(),a.end());
    cout<<a<<'\n';
    if(tmp==a) cout<<1;
    else cout<<0;
    return 0;
}
