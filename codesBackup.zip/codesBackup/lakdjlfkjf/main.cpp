#include <bits/stdc++.h>
using namespace std;
stack<char> s;
stack<pair<char,int> >ps;
int order[34];
int main()
{
    string dat;
    cin>>dat;
    int cnt=0;
    for(int i=0;i<dat.size();i++){
        if(dat[i]=='('||dat[i]=='['){s.push(dat[i]);order[i]=s.size()-1;
        }else if(dat[i]==')'){
            if(s.top()=='('){order[i]=s.size()-1;s.pop();
            }else{cout<<0;return 0;}
        }else{
            if(s.top()=='['){order[i]=s.size()-1;s.pop();
            }else{cout<<0;return 0;}
        }
    }
    for(int i=0;i<dat.size();i++){
        if(dat[i]=='('||dat[i]=='[') s.push({dat[i],order[i]});
        else if(dat[i]==')'){

        }
        order[i]=0;
    }
    return 0;
}
