#include <iostream>
#include <map>
using namespace std;
long long int a[100000];
map<long long int,bool> m;
int main(){
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>a[i];
        m[a[i]]=true;
    }
    sort(a,a+n);
    int l=0,r=n-1,cnt=0;
    while(l<=r){
        long long int sub = a[l]+a[r];
        if(m[sub]==true){
            cnt++;
            l++;
        }else if(sub)
    }
    return 0;
}
