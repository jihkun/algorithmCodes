#include <iostream>
#include <algorithm>
#include <vector>
#include <queue>
using namespace std;
queue<int> buff;
int cnt=0;
vector<int> LPS(string t) {
    int m = t.size();
    vector<int> dat(m, 0);
    int l = 0, i = 1;
    while (i < m) {
        if (t[i] == t[l]) {
            dat[i++] = ++l;
        } else {
            if (l != 0) {
                l = dat[l-1];
            } else {
                dat[i] = 0;
                i++;
            }
        }
    }
    return dat;
}

void KMP(string t, string t2) {
    int n = t.size(), m = t2.size();
    vector<int> ts = LPS(t2);
    int l = 1, r = 0;
    while (l < n) {
        if (t[l] == t2[r]) {
            l++;
            r++;
        }
        if (r == m) {
            cnt++;
            buff.push(l-r+1);
            r = ts[r - 1];
        } else if (l < n && t2[r] != t[l]) {
            if (r != 0) {
                r = ts[r - 1];
            } else {
                l++;
            }
        }
    }
}

int main() {
    string a, b;
    cin>>a>>b;
    KMP(a+a, b);
    cout<<cnt<<'\n';
    return 0;
}
