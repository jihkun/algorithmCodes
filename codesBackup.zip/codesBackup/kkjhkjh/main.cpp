#include <bits/stdc++.h>

using namespace std;
string make_hash(){
    string sub;
    for(int i=0;i<24;i++){
        sub+=rand()%25+1;
    }
    return sub;
}
class crom{
private:
    string hash_rom=make_hash();
    bool irom=false,srom=false;
    string ird;
    string srd;
public:
    string soutput(){
        int integ=0;
        string sub;
        for(int i=0;i<srd.size();i++){
            sub+=to_string((int)srd[i]-(int)hash_rom[integ++%25]);
        }
        return sub;
    }
    void input(string dat){
        int integ=0;
        int dat_i[dat.size()];
        for(int i=0;i<dat.size();i++){
            dat_i[i]=(int)dat[i];
        }
        srd='\n';
        for(int i=0;i<dat.size();i++){
            srd+=dat_i[i]+(int)hash_rom[integ++%25]+'\n';
        }
        cout<<srd<<endl;
    }
//    void input(int dat){
//        int integ=0;
//        ird=0;
//        for(int i=0;i<)
//    }
};

int main()
{
    crom base;
    string ti;\
    cin>>ti;
    base.input(ti);
    cout<<base.soutput();
    return 0;
}
