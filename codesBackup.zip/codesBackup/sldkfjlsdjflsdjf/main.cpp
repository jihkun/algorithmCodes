#include <iostream>

using namespace std;
int xor_find(int a){
    if(a%4==3) return 0;
    if(a%4==1) return 1;
    if(a%4==0) return a;
    else return a+1;
}
int main()
{
    int n;
    cin>>n;
    while(n--){
        int sub,sub2;
        cin>>sub>>sub2;
        cout<<(xor_find(sub2)^xor_find(sub-1))<<'\n';
    }
    return 0;
}
