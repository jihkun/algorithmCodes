#include <iostream>
#include <deque>
#include <vector>
#include <cstring>
using namespace std;
int tmp[100000];
int main()
{
    int t;
    cin>>t;
    while(t--){
        memset(tmp,0,sizeof(tmp));
        deque<int> d;
        string a;
        cin>>a;
        int n;
        cin>>n;
        cin.ignore();
        scanf("[%d",&tmp[0]);
        for(int i=1;i<n;i++) scanf(",%d",&tmp[i]);
        scanf("]");
        for(int i=0;i<n;i++){
            d.push_back(tmp[i]);
        }
        bool flag=false,s=false;
        for(auto i:a){
            if(i=='R'){
                flag=!flag;
            }else{
                if(flag){
                    if(!d.empty()) d.pop_back();
                    else{
                        cout<<"error\n";
                        s=true;
                        break;
                    }
                }else{
                    if(!d.empty()) d.pop_front();
                    else{
                        cout<<"error\n";
                        s=true;
                        break;
                    }
                }
            }
        }
        if(s) continue;
        if(!flag){ cout<<'['<<d.front();
        d.pop_front();}
        else{ cout<<'['<<d.back();
        d.pop_back();}
        while(!d.empty()){
            if(!flag){
                cout<<','<<d.front();
                d.pop_front();
            }else{
                cout<<','<<d.back();
                d.pop_back();
            }
        }
        cout<<"]\n";
    }
    return 0;
}
