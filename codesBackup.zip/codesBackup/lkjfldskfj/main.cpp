#include <iostream>
#include <queue>
using namespace std;
vector<pair<int,int> > v;
vector<pair<int,int> > dat;
int n,m,ma;

int f(int s,int il,int pl){
    if(s==n){
        int cnt=0;
        for(int i=0;i<m;i++){
            cnt+=v[i].first;
        }
        ma=max(ma,cnt);
        return 0;
    }
    for(int i=il;i<=n;i++){
        if(pl+dat[i].second){
            v.push_back(dat[i]);
            f(s+1,il+1,pl+dat[i].second);
            v.pop_back();
        }
    }

}
int main()
{
    cin>>n>>m;
    for(int i=0;i<n;i++){
        int sub,sub2;
        cin>>sub>>sub2;
        v.push_back({sub,sub2});
    }
    cout<<ma;
    return 0;
}
