#include <iostream>
#include <cstring>
#include <queue>
using namespace std;
struct tri{
    int f,s,t;
};
int a[101][101][101];
int chk[101][101][101];
int di[]={1,-1,0,0,0,0};
int dj[]={0,0,1,-1,0,0};
int dk[]={0,0,0,0,1,-1};
int main()
{
    memset(chk,-1,sizeof(chk));
    queue<tri> q;
    int n,m,c;
    cin>>m>>n>>c;
    for(int i=0;i<c;i++){
        for(int j=0;j<n;j++){
            for(int k=0;k<m;k++){
                cin>>a[i][j][k];
                if(a[i][j][k]==1){
                    q.push({i,j,k});
                    chk[i][j][k]=0;
                }
                if(a[i][j][k]==-1){
                    chk[i][j][k]=-3;
                }
            }
        }
    }
    int ma=0;
    while(!q.empty()){
        int ti=q.front().f;
        int tj=q.front().s;
        int tk=q.front().t;
        q.pop();
        for(int i=0;i<6;i++){
            int ni=ti+di[i];
            int nj=tj+dj[i];
            int nk=tk+dk[i];
            if(ni>=0&&ni<c&&nj>=0&&nj<n&&nk>=0&&nk<m){
                if(a[ni][nj][nk]==0&&chk[ni][nj][nk]==-1){
                    q.push({ni,nj,nk});
                    chk[ni][nj][nk]=chk[ti][tj][tk]+1;
                    ma=max(ma,chk[ni][nj][nk]);
                }
            }
        }
    }
    for(int i=0;i<c;i++){
        for(int j=0;j<n;j++){
            for(int k=0;k<m;k++){
                if(chk[i][j][k]==-1){
                    cout<<"-1";
                    return 0;
                }
            }
        }
    }
    cout<<ma;
    return 0;
}
