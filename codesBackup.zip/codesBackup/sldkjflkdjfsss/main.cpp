#include <bits/stdc++.h>
#define INF 987654321
using namespace std;
int dist[1010];
vector<int> va[1010];
int main()
{
    int n,m;
    cin>>n>>m;
    vector<pair<int,int> > v[n+1];
    for(int i=0;i<m;i++){
        int sub,sub2,pl;
        cin>>sub>>sub2>>pl;
        v[sub].push_back({pl,sub2});
    }
    for(int i=1;i<=n;i++) sort(v[i].begin(),v[i].end());
    priority_queue<pair<int,int> > q;
    for(int i=0;i<=n;i++){
        dist[i]=INF;
    }
    int st,en;
    cin>>st>>en;
    dist[st]=0;
    q.push({0,st});
    while(!q.empty()){
        int pl=-q.top().first;
        int point=q.top().second;
        q.pop();
        for(int i=0;i<v[point].size();i++){
            int next_pl=v[point][i].first;
            int next_point=v[point][i].second;
            if(dist[next_point]>next_pl+pl){
                dist[next_point]=next_pl+pl;
                q.push({-dist[next_point],next_point});
                va[next_point]=va[point];
                va[next_point].push_back(point);
            }
        }
    }
    cout<<dist[en]<<'\n'<<va[en].size()+1<<'\n';
    for(int i=0;i<va[en].size();i++){
        cout<<va[en][i]<<' ';
    }
    cout<<en;
    return 0;
}
