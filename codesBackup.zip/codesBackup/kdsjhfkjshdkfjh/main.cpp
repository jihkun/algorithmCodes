#include <iostream>
#include <vector>
#include <cstring>
#include <queue>
using namespace std;
vector<pair<int,int> > v[10000];
int chk[10000];
int n;
pair<int,int> bfs(int da){
    memset(chk,-1,sizeof(chk));
    queue<int> q;
    q.push(da);
    chk[da]=0;
    int ma=0,mi=0;
    while(!q.empty()){
        int ti=q.front();
        q.pop();
        for(auto i:v[ti]){
            int ni=i.first;
            int nd=i.second;
            if(chk[ni]==-1){
                chk[ni]=chk[ti]+nd;
                if(ma<chk[ni]){
                    ma=chk[ni];
                    mi=ni;
                }
                q.push(ni);
            }
        }
    }
    return make_pair(ma,mi);
}
int main()
{
    cin>>n;
    for(int i=0;i<n;i++){
        int sub;
        cin>>sub;
        int sub2,sub3;
        cin>>sub2;
        while(sub2!=-1){
            cin>>sub3;
            v[sub].push_back({sub2,sub3});
            cin>>sub2;
        }
    }
    cout<<bfs(bfs(1).second).first;
    return 0;
}
