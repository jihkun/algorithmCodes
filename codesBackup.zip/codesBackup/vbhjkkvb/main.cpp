#include <iostream>

using namespace std;
int data_memory[100][100];
bool chk[100][100];
int di[]={0,0,1,-1};
int dj[]={1,-1,0,0};
int cnt=0;
int dfs(int i,int j){
    chk[i][j]=true;
    for(int k=0;k<4;k++){
        int ni=i+di[k];
        int nj=j+dj[k];
        if(ni>=0&&ni<5&&nj>=0&&nj<5){
            if(data_memory[ni][nj]==1&&chk[ni][nj]==0){
                dfs(ni,nj);
            }
        }
    }
}
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
        int sub;
        cin>>sub;
        if(sub > n) data_memory[i][j]=1;
        else data_memory[i][j]=0;
        }
    }
    for(int i=0;i<5;i++){
        for(int j=0;j<5;j++){
            if(data_memory[i][j]==1&&chk[i][j]==0){
                dfs(i,j);
                cnt++;
            }
        }
    }
    cout<<cnt;
    return 0;
}
