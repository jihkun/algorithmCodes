#include <iostream>
#include <queue>
#include <algorithm>
#include <set>
using namespace std;

priority_queue<pair<int,int>> q;
multiset<int> s;

int main() {
    int n, m, mi = 1000000000;
    cin >> n >> m;
    for (int i = 0; i < n; i++) {
        int sub, sub2;
        cin >> sub >> sub2;
        q.push({sub2, -sub});
        mi = min(mi, sub);
    }
    for (int i = 0; i < m; i++) {
        int sub;
        cin >> sub;
        s.insert(sub);
    }
    long long int cnt = 0;

    while (!q.empty() && !s.empty()) {
        auto it = s.lower_bound(-q.top().second);

        if (it != s.end() && *it >= -q.top().second) {
            cnt += q.top().first;
            s.erase(it);
        }

        q.pop();
    }

    cout << cnt;
    return 0;
}
