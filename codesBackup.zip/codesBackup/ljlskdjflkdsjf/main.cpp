#include <iostream>
#include <vector>
#include <algorithm>
#include <cstring>
using namespace std;
int trie[1100000][10];
bool chk[1000010];
int num=2;
bool ins(string sub){
    int cur=1;
    for(char i:sub){
        if(chk[trie[cur][i-'0']]) return false;
        if(trie[cur][i-'0']==-1){
            trie[cur][i-'0']=num++;
        }
        cur=trie[cur][i-'0'];
    }
    return chk[cur]=true;
}

int main()
{
    int t;
    cin>>t;
    while(t--){
        memset(trie,-1,sizeof(trie));
        memset(chk,false,sizeof(chk));
        int n;
        cin>>n;
        vector<string> v;
        bool flag=true;
        for(int i=0;i<n;i++){
            string sub;
            cin>>sub;
            v.push_back(sub);
        }
        sort(v.begin(),v.end());
        for(int i=0;i<n;i++){
            if(!ins(v[i])){
                cout<<"NO\n";
                flag=false;
                break;
            }
        }
        if(flag) cout<<"YES\n";
    }
    return 0;
}
