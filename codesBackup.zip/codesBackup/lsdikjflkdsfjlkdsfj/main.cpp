#include <iostream>
#include <cstring>
using namespace std;
int dp[100001];
int a[10001];
int main()
{
    fill(dp,dp+100000,987654321);
    int n,m;
    cin>>n>>m;
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    dp[0]=0;
    for(int i=1;i<=m;i++){
        for(int j=0;j<n;j++){
            if(i-a[j]>=0) dp[i]=min(dp[i],dp[i-a[j]]+1);
        }
    }
    if(dp[m]!=987654321) cout<<dp[m]<<' ';
    else cout<<"-1";
    return 0;
}
