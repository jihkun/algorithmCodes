#include <bits/stdc++.h>
#include <cstring>
#include <math.h>
#define MN 1000000007
using namespace std;
vector<int> v[100001];
int p[100001][20];
int d[100001];
void setup(int a, int b){
    p[a][0]=b;
    d[a]=d[b]+1;
    for(auto i:v[a]){
        if(i!=b){
            setup(i,a);
        }
    }
}
int L(int a,int b){
    if(d[a]<d[b]) swap(a,b);
    for(int i=22;i>=0;i--){
        if(pow(2,i)<=d[a]-d[b]){
            if(d[b]<=d[p[a][i]]){
                a=p[a][i];
            }
        }
    }
    for(int i=17;i>=0&&a!=b;i--){
        if(p[a][i]!=p[b][i]){
            a=p[a][i];
            b=p[b][i];
        }
    }
    if(a!=b) return p[a][0];
    else return a;
}
int main()
{
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        for(int i=0;i<n-1;i++){
            int sub,sub2;
            cin>>sub>>sub2;
            v[sub].push_back(sub2);
            v[sub2].push_back(sub);
        }
        int root=0;
        for(int i=1;i<=n;i++){
            if(p[i][0]==0){
                root=i;
                break;
            }
        }
        setup(root,0);
        for(int i=1;i<=17;i++){
            for(int j=1;j<=n;j++){
                p[j][i]=p[p[j][i-1]][i-1];
            }
        }
        int s1,s2;
        cin>>s1>>s2;
        cout<<L(s1,s2)<<'\n';
        memset(p,0,sizeof(p));
        memset(d,0,sizeof(d));
        for(int i=0;i<100001;i++){
            v[i].clear();
        }
    }
    return 0;
}
