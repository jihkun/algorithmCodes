#include <iostream>
#include <climits>
#define ll long long
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
pair<ll,ll> mi[4100000];
ll a[1000001];
pair<ll,ll> setup(ll n,ll s,ll e){
    if(s==e) return mi[n]={a[s],s};
    ll mid=(s+e)/2;
    return mi[n]=min(setup(n*2,s,mid),setup(n*2+1,mid+1,e));
}
pair<ll,ll> qu(ll n,ll s,ll e,ll l,ll r){
    if(l>e||r<s) return {LONG_MAX,0};
    if(s>=l&&e<=r){
        return mi[n];
    }
    ll mid = (s + e) / 2;
    pair<ll,ll> o,p;
    o=qu(n * 2, s, mid, l, r); p=qu(n * 2 + 1, mid + 1, e, l, r);
    return min(o,p);
}
pair<ll,ll> update(ll n, ll s,ll e, ll i, ll d){
    if(s<i||e>i) return mi[n];
    if(s==e) return mi[n]={d,s};
    ll mid=(s+e)/2;
    return mi[n]=min(update(n*2,s,mid,i,d),update(n*2+1,mid+1,e,i,d));
}
int main(int argc, char** argv) {
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	ll n;
	cin>>n;
	for(ll i=1;i<=n;i++){
		cin>>a[i];
	}
	ll m;
	cin>>m;
	setup(1,1,n);
	for(ll i=0;i<m;i++){
        long long  sub,sub2,sub3;
        cin>>sub>>sub2>>sub3;
        if(sub==2){
            pair<ll,ll> dat=qu(1,1,n,sub2,sub3);
            cout<<dat.second<<'\n';
        }else{
            update(1,1,n,sub2,sub3);
        }
	}
	return 0;
}
