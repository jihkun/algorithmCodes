#include <bits/stdc++.h>
#define ll long long
#define INF 9876543212345
#define NMAX 1005
using namespace std;
ll n,m,s,t,chk_s[NMAX],chk_t[NMAX],ans;
vector<ll> v[NMAX];
map<pair<ll,ll>,bool> u;
void bfs_s()
{
    queue<ll> q;
    q.push(s);
    chk_s[s]=0;
    while(!q.empty())
    {
        ll x=q.front();
        q.pop();
        for(int i=0;i<v[x].size();i++)
        {
            ll nx=v[x][i];
            if(chk_s[nx]==INF)
            {
                chk_s[nx]=chk_s[x]+1;
                q.push(nx);
            }
        }
    }
}
void bfs_t()
{
    queue<ll> q;
    q.push(t);
    chk_t[t]=0;
    while(!q.empty())
    {
        ll x=q.front();
        q.pop();
        for(int i=0;i<v[x].size();i++)
        {
            ll nx=v[x][i];
            if(chk_t[nx]==INF)
            {
                chk_t[nx]=chk_t[x]+1;
                q.push(nx);
            }
        }
    }
}
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);
    cin>>n>>m>>s>>t;
    for(int i=1;i<=n;i++)chk_s[i]=chk_t[i]=INF;
    for(int i=0;i<m;i++)
    {
        ll a,b;
        cin>>a>>b;
        v[a].push_back(b);
        v[b].push_back(a);
        u[{a,b}]=u[{b,a}]=1;
    }
    bfs_s();
    bfs_t();
    for(int i=0;i<n;i++){
        if(chk_s[i]!=chk_t[i]) cout<<"1 ";
        else cout<<"0 ";
    }
    //chk_s[i]+chk_t[j]+(���� ������ �ƴϸ� )+1>=chk_s[t] ans++;
    for(int i=1;i<=n;i++)
    {
        //cout<<chk_s[i]<<' ';
        for(int j=i+1;j<=n;j++)
        {
            ll dist=min(chk_s[i]+chk_t[j],chk_s[j]+chk_t[i])+1;

            if(u[{i,j}]==0)
            {
                if(dist>=chk_s[t])ans++;
                //cout<<dist<<'\n';
                //cout<<chk_s[i]+chk_t[j]+1<<' '<<chk_s[j]+chk_t[i]+1<<'\n';
                //cout<<i<<' '<<j<<'\n';
            }

        }
    }
    cout<<ans;
    return 0;
}
