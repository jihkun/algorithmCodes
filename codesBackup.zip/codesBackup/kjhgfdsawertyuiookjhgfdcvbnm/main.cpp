#include <iostream>
#include <stack>
#include <deque>
using namespace std;
deque<pair<int,int> > d;
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        int sub;
        cin>>sub;
        d.push_back({sub,i+1});
    }
    cout<<"1 ";
    int mov=d.front().first;
    d.pop_front();
    while(!d.empty()){
        if(mov<0){
            while(mov++){
                d.push_front(d.back());
                d.pop_back();
            }
            cout<<d.front().second<<' ';
            mov=d.front().first;
            d.pop_front();
        }else{

            while(mov--){
                d.push_back(d.front());
                d.pop_front();
            }
            cout<<d.back().second<<' ';
            mov=d.back().first;
            d.pop_back();
        }
    }
    return 0;
}
