#include <iostream>

using namespace std;
int dp[12910],a[10001];
int main()
{
    int n;
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    dp[1]=a[1];
    dp[2]=a[1]+a[2];
    for(int i=3;i<=n;i++){
        dp[i]=max(dp[i-1],dp[i-2]+a[i]);
    }
    cout<<dp[n];
    return 0;
}
