#include<bits/stdc++.h>
using namespace std;
struct spec{
	int cp,ram,hdd,mo,ord;
};
spec v[101];
bool cmp(const spec &u,const spec &v){
    return u.mo<v.mo;
}
int main(){
  int n;
  cin>>n;
  for(int i=0;i<n;i++){
    int cp,ram,hdd,mo;
    cin>>cp>>ram>>hdd>>mo;
    v[i].cp=cp; v[i].ram=ram;v[i].hdd=hdd;v[i].mo=mo;v[i].ord=i+1;
  }
  for(int i=0;i<n;i++){
    for(int j=0;j<n;j++){
        if(v[i].cp<v[j].cp&&v[i].ram<v[j].ram&&v[i].hdd<v[j].hdd&&v[i].mo<v[j].mo){
            v[i].mo=1001;
            break;
        }
    }
  }
  sort(v,v+n,cmp);
    cout<<v[0].ord;

    return 0;
}
