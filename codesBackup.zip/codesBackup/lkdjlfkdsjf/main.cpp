#include <bits/stdc++.h>

using namespace std;
priority_queue<pair<int,bool> > q;
int main()
{
    ios_base::sync_with_stdio(false); cin.tie(0);cout.tie(0);
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        long long int sub;
        cin>>sub;
        if(sub!=0){
            if(sub>0){
                q.push({-sub,0});
            }else{
                q.push({sub,1});
            }
        }else if(sub==0&&!q.empty()){
            if(q.top().second==false) cout<<-q.top().first<<'\n';
            else cout<<q.top().first<<'\n';
            q.pop();
        }else{
            cout<<sub<<'\n';
        }
    }
    return 0;
}



