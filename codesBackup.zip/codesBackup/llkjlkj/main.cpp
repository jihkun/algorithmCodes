#include <iostream>

using namespace std;
int arr[100001];
int main()
{
    int n,m,cnt=0;
    cin>>n>>m;
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    int sum=0,supersum=0;
    while(1){
        sum++;
        supersum+=sum;
        if(supersum>=m){
            supersum-=sum;
            int idx=m-supersum;
            if(idx==0) cout<<arr[sum-1];
            else cout<<arr[idx-1];
            return 0;
        }
    }
    return 0;
}
