#include <iostream>
#include <vector>
using namespace std;
int a[100000],d[100000],id=0,rs=0;
bool r[100000];
vector<int> v[100000];
int dfs(int i, bool root){
    d[i]=++id;
    int n=d[i],child=0;
    for(int k=0;k<v[i].size();k++){
        int ni=v[i][k];
        if(!d[ni]){
            child++;
            int sub=dfs(ni,false);
            n=min(sub,n);
            if(!root&&sub>=d[i]&&!r[i]){
                rs++;
                r[i]=true;
            }
        }else{
            n=min(d[ni],n);
        }
    }
    if(root&&child>1){
        rs++;
        r[i]=true;
    }
    return n;
}
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=0;i<m;i++){
        int sub,sub2;
        cin>>sub>>sub2;
        v[sub].push_back(sub2);
        v[sub2].push_back(sub);
    }
    for(int i=1;i<=n;i++){
        if(d[i]==0) dfs(i,1);
    }
    cout<<rs<<'\n';qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq22222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq
    for(int i=1;i<=n;i++){
        if(r[i]) cout<<i<<' ';
    }
    return 0;
}
