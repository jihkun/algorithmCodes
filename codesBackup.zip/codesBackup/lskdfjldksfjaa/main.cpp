#include <iostream>
#include <map>
#include <queue>
#include <vector>
using namespace std;

struct Element {
    string first;
    int second;
    int third;
};

struct compare {
    bool operator()(const Element& a, const Element& b) const {
        if (a.third == b.third) {
            if (a.first == b.first) return a.second > b.second; // ������ ������������ ����
            return a.first > b.first; // ���ڿ��� ������ ������������ ����
        }
        return a.third > b.third;
    }
};

vector<int> v[10001];
int dist[10001];
map<string, int> na;
map<int, string> nas;

int main() {
    int n, cnt = 1;
    cin >> n;
    for (int i = 0; i < n; i++) {
        string a, b;
        cin >> a >> b;
        if (na.find(a) == na.end()) { na[a] = cnt; nas[cnt++] = a; }
        if (na.find(b) == na.end()) { na[b] = cnt; nas[cnt++] = b; }
        v[na[a]].push_back(na[b]);
        dist[na[b]]++;
    }

    priority_queue<Element, vector<Element>, compare> q;
    for (int i = 1; i < cnt; i++) {
        if (dist[i] == 0) q.push({nas[i], i, 0});
    }
    if (q.empty()) {
        cout << "-1";
        return 0;
    }
    queue<string> output;
    while (!q.empty()) {
        Element top = q.top();
        q.pop();
        output.push(top.first);
        for (auto i : v[top.second]) {
            dist[i]--;
            if (dist[i] == 0) {
                q.push({nas[i], i, top.third + 1});
            }
        }
    }

    if (!q.empty()) {
        cout << "-1";
    } else {
        while (!output.empty()) {
            cout << output.front() << '\n';
            output.pop();
        }
    }
    return 0;
}
