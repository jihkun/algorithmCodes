#include <iostream>
#include <vector>
#define ll long long int
using namespace std;
vector<int> v,lazy;
ll a[100001];
ll setup(int n,int s,int e){
    if(s==e) return v[n]=a[s];
    int mid=(s+e)/2;
    return v[n]=setup(n*2,s,mid)^setup(n*2+1,mid+1,e);
}
void upla(int n,int s,int e){
    if(lazy[n]%2){
        v[n]=(e-s+1)-lazy[n];
        if(s!=e){
            lazy[n*2]+=lazy[n];
            lazy[n*2+1]+=lazy[n];
        }
        lazy[n]=0;
    }
}
void update(int n,int s,int e,int l,int r,int diff){
    upla(n,s,e);
    if(l>e||r<s) return;
    if(l<=s&&r>=e){
        v[n]=diff*(e-s+1);
        if(s!=e){
            lazy[n*2]++;
            lazy[n*2+1]++;
        }
        return;
    }
    int mid=(s+e)/2;
    update(n*2,s,mid,l,r,diff);
    update(n*2+1,mid+1,e,l,r,diff);
    v[n]=v[n*2]+v[n*2+1];
}
ll qu(int n,int s,int e,int l,int r){
    upla(n,s,e);
    if(s>r||e<l) return 0;
    if(l<=s&&r>=e) return v[n];
    int mid=(s+e)/2;
    return qu(n*2,s,mid,l,r)+qu(n*2+1,mid+1,e,l,r);
}
int main()
{

    return 0;
}
