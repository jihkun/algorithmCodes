#include <bits/stdc++.h>
using namespace std;
vector<pair<int,int> > v;
bool cmp(const pair<int,int> &u,const pair<int,int> &v){
    if(u.first<v.first){
        return true;
    }else if(u.first==v.first){
        return u.second>v.second;
    }else if(u.first>v.first){
        return false;
    }
}
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        int sub,sub2;
        cin>>sub>>sub2;
        v.push_back({sub,sub2});
    }
    sort(v.begin(),v.end(),cmp);
    for(int i=0;i<n;i++){
        int chk=v[i].first;
        for(int j=0;chk!=v[j].first;j++){
            v[j].
        }
    }
    return 0;
}
