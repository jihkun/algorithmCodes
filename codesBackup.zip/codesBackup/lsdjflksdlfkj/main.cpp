#include <iostream>
#include <vector>
#define ll long long int
using namespace std;
ll ccw(pair<ll,ll> a, pair<ll,ll> b, pair<ll,ll> c){
    ll t=a.first*b.second+b.first*c.second+c.first*a.second;
    ll t2=a.second*b.first+b.second*c.first+c.second*a.first;
    if(t-t2<0) return 1;
    else return -1;
}
ll main()
{
    pair<ll,ll> a[5];
    for(ll i=0;i<4;i++){
        cin>>a[i].first>>a[i].second;
    }
    ll abc=ccw(a[0],a[1],a[2]);
    ll abd=ccw(a[0],a[1],a[3]);
    ll cda=ccw(a[2],a[3],a[0]);
    ll cdb=ccw(a[2],a[3],a[1]);
    if(abc*abd<=0&&cda*cdb<=0) cout<<1;
    else cout<<0;
    return 0;
}
