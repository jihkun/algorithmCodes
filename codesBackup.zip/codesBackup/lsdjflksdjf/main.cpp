#include <iostream>
#include <map>
#include <stack>
#include <algorithm>
#include <queue>
using namespace std;
int a[5000001];
int s[5000001];
map<int,int> ma;
int main()
{
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>a[i];
        s[i]=a[i];
        ma[a[i]]=i;
    }
    sort(a,a+n);
    int mas=-999999,ind=0;
    for(int i=0;i<n;i++){
        if(mas<ma[a[i]]-i){
            mas=ma[a[i]]-i;
        }
    }
    cout<<mas+1;
    return 0;
}
