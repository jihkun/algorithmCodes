#include <bits/stdc++.h>

using namespace std;
int s[100];
string a[10000];
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>a[i];
        int num=1;
        for(int j=a[i].size()-1;j>=0;j--){
            s[a[i][j]-'A']+=num;
            num*=10;
        }
    }
    sort(s,s+26,greater<int>());
    int cnt=0;
    int su=9;
    for(int i=0;i<9;i++){
        cnt+=s[i]*(su-i);
    }
    cout<<cnt;
    return 0;
}
