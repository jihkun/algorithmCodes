#include <bits/stdc++.h>
#define INF 987654321
using namespace std;
stack<int> s,def;
map<int,int> sizeof_dat{
    {0,20},{1,40},{2,60},{3,80},{4,100}
};
int main()
{
    int n;
    cin>>n;
    int si=0;
    bool over_sewer=false;
    for(int i=0;i<n;i++){
        int sub;
        cin>>sub;
        if(sub.size()>9){
            while(!s.empty())
        }
        if(over_sewer){
            s.push(sub);
            continue;
        }
        if(sub>100){
            if(si!=0){
                while(5-si){
                    si++;
                    s.push(-1);
                }
            }
            s.push(sub);
            over_sewer=true;
            continue;
        }
        if(si>0||sub>19){
            while(sizeof_dat[si]<sub){
                if(s.size()==0) si++;
                else{ s.push(-1);si++;}
            }
            if(sub>100) over_sewer=true;
            si++;
            s.push(sub);
        }
    }
    if(s.size()==0){
        cout<<'0';
        return 0;
    }
    bool did_print=false;
    while(!s.empty()){
        cout<<s.top()<<' ';
        s.pop();
    }
    return 0;
}
