#include <tchar.h>
#include <iostream>
#include <ctime>


using namespace std;
int running(){
    int a=0;
    for(int i=0;i<20000*10000;i++){
        a++;
    }
    return a;
}
int main()
{
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    int cnt=0,st=0,et=0;
    for(int i=0;i<10;i++){
        st=clock();
        cout<<running()<<" ";
        et=clock();
        cout<<", "<<et-st<<"sec\n";
        cnt+=et-st;
    }
    cout<<cnt/10;
    return 0;
}
