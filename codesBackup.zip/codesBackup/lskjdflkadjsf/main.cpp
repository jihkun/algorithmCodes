#include <bits/stdc++.h>
using namespace std;
vector<int> v[10000];
int chk[10000];
int main()
{
    int n,m,k,x;
    cin>>n>>m>>k>>x;
    for(int i=0;i<m;i++){
        int sub,sub2;
        cin>>sub>>sub2;
        v[sub].push_back(sub2);
        v[sub2].push_back(sub);
    }
    for(int i=1;i<=n;i++){
        chk[i]=98765321;
    }
    queue<int> q;
    q.push(x);
    chk[x]=0;
    while(!q.empty()){
        int ti=q.front();
        q.pop();
        for(auto i:v[ti]){
            if(chk[i]>chk[ti]+1){
                chk[i]=chk[ti]+1;
                q.push(i);
            }
        }
    }
    bool flag=false;
    for(int i=1;i<=n;i++){
        if(chk[i]==k){
            flag=true;
            cout<<i<<'\n';
        }
    }
    if(flag) return 0;
    cout<<"-1";
    return 0;
}
