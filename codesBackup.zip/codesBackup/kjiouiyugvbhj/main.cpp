#include <iostream>

using namespace std;
int a[1000000];
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    int t=0;
    cin>>t;
    for(int i=n;i>0;i++){
        for(int j=0;j<i;j++){
            if(a[j]<a[j+1]){
                int tmp=a[j];
                a[j]=a[j+1];
                a[j+1]=tmp;
                t--;
            }
            if(t<=0) break;
        }
        if(t<=0) break;
    }
    for(int i=0;i<n;i++){
        cout<<a[i]<<' ';
    }
    return 0;
}
