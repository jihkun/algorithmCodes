#include <iostream>
#include <algorithm>
#include <string>
using namespace std;
bool sort_string(const string &u,const string &v){
    if(u.size()>v.size()){
        return false;
    }else if(u.size()==v.size()){
        return u<v;
    }else if(u.size()<v.size()){
        return true;
    }
}
int main() {
  int a;
  cin>>a;
  string arr[a];
  for (int i=0;i<a;i++){
    cin>>arr[i];
   }
  sort(arr,arr+a,sort_string);
  for (int i=0; i<a;i++){
    if(arr[i]!=arr[i-1]) cout<<arr[i]<<'\n';
  }


}
