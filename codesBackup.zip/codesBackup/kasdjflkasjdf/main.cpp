#include <bits/stdc++.h>
using namespace std;
struct studat{
    int co,nu,po;
};
studat dat[1001];
int cmedal[1001];
bool ds(const studat &u, const studat &v){
    return u.po>v.po;
}
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        int csub,nsub,psub;
        cin>>csub>>nsub>>psub;
        dat[i].co=csub;
        dat[i].nu=nsub;
        dat[i].po=psub;
    }
    sort(dat,dat+n,ds);
    int cnt=0;
    for(int i=0;i<n;i++){
        if(cnt>2) break;
        if(cmedal[dat[i].co]>1){
            continue;
        }else{
            cmedal[dat[i].co]++;
            cout<<dat[i].co<<' '<<dat[i].nu<<'\n';
            cnt++;
        }
    }
    return 0;
}
