#include <iostream>
#include <vector>
using namespace std;

vector<pair<int,int>> v[40001];
int p[40001][16], d[40001], l[40001];

void setup(int k, int n, int dist) {
    p[k][0] = n;
    d[k] = d[n] + 1;
    l[k] = l[n] + dist;
    for (auto i : v[k]) {
        if (i.first != n) {
            setup(i.first, k, i.second);
        }
    }
}

int LCA(int a, int b) {
    if (d[a] < d[b]) swap(a, b);
    for (int i = 15; i >= 0; i--) {
        if (d[a] - d[b] >= (1 << i)) {
            a = p[a][i];
        }
    }
    if (a == b) return a;
    for (int i = 15; i >= 0; i--) {
        if (p[a][i] != p[b][i]) {
            a = p[a][i];
            b = p[b][i];
        }
    }
    return p[a][0];
}

int main() {
    int n;
    cin >> n;
    for (int i = 0; i < n - 1; i++) {
        int a, b, dist;
        cin >> a >> b >> dist;
        v[a].push_back({b, dist});
        v[b].push_back({a, dist});
    }
    setup(1, 0, 0);
    for (int i = 1; i <= 15; i++) {
        for (int j = 1; j <= n; j++) {
            p[j][i] = p[p[j][i-1]][i-1];
        }
    }
    int m;
    cin >> m;
    for (int i = 0; i < m; i++) {
        int a, b;
        cin >> a >> b;
        int lca = LCA(a, b);
        cout << l[a] + l[b] - 2 * l[lca] << '\n';
    }
    return 0;
}
