#include <iostream>

using namespace std;
bool a[10000][10000];
int main()
{
    int t;
    cin>>t;
    while(t--){
        int n,m;
        cin>>n>>m;
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                char sub;
                cin>>sub;
                if(sub=='D'){
                   a[i][j]=true;
                }
            }
        }
        bool flag=false;
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                int ic=0,jc=0;
                for(int k=1;i+k<=m||j+k<=n;k++){
                    if(a[i+k][j]==true) ic++;
                    if(a[i][k+j]==true) jc++;
                }
                if(jc!=0&&ic!=0){ cout<<"X\n"; flag=true; break;}
            }
            if(flag) break;
        }
        if(!flag) cout<<"O\n";
    }
    return 0;
}
