#include <bits/stdc++.h>

using namespace std;
struct dat{
    int f,s;
};
priority_queue<int > q;
dat a[200000];
bool cmp(const dat &u,const dat &v){
    return u.s<v.s;
}
int main()
{
    int n,cnt=0;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>a[i].f>>a[i].s;
    }
    sort(a,a+n,cmp);
    q.push(-a[0].s);
    for(int i=1;i<n;i++){
        if(-q.top()<=a[i].f){
            q.pop();
            q.push(-a[i].s);
        }else{
            q.push(-a[i].s);
        }
    }
    cout<<q.size();
    return 0;
}
