#include <iostream>
#include <queue>
#include <algorithm>
using namespace std;

int main()
{
    int n,m,middle=0;
    cin>>n>>m;
    int l=0,r=m;
    while(l<r){
        int mid=(l+r)/2;
        int sub=0;
        for(int i=1;i<=n;i++){
            sub+=min(n,mid/i);
        }
        if(sub<m){
            l=mid+1;
        }else{
            r=mid-1;
            middle=mid;
        }
    }
    cout<<middle;
    return 0;
}
