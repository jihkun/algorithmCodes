#include <iostream>
#include <queue>
#include <vector>
#include <algorithm>
using namespace std;
priority_queue<pair<int,int> > q;
priority_queue<int> a;
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        int sub,sub2,sub3;
        cin>>sub>>sub2>>sub3;
        q.push({-sub2,-sub3});
    }
    a.push(q.top().second);
    q.pop();
    while(!q.empty()){
        int s=-q.top().first;
        int f=-q.top().second;
        q.pop();
        if(-a.top()>=s){
            a.push(-f);
        }else{
            a.pop();
            a.push(-f);
        }
    }
    cout<<a.size();
}
