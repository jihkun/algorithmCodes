#include <bits/stdc++.h>

using namespace std;
int ans=0;
priority_queue<int> q;
pair<int, int> p[10283];

int main()
{
    int n,k;
    cin>>n>>k;
    for(int i=0;i<n;i++){
        int sub,sub2;
        cin>>sub>>sub2;
        p[i]={sub2,sub};
    }
    sort(p,p+n);
    int ma_h=0,sum_wide=0;
    for(int i=0;i<k;i++){
        q.push(p[i].second);
        sum_wide+=p[i].second;
        ma_h=p[i].first;
    }
    int neol=sum_wide*ma_h;

    for(int i=k;i<=n-1;i++){
        int tmp_wide=q.top();
        int new_neol=(sum_wide-tmp_wide+p[i].second)*p[i].first;
        if(new_neol<neol){
            q.pop();
            q.push(p[i].second);
            ma_h=p[i].first;
            neol=new_neol;
        }
    }
    cout<<neol;
    return 0;
}
