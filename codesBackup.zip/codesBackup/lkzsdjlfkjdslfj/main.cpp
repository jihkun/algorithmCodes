#include <bits/stdc++.h>
#define am 1000001
using namespace std;
bool dp[am];
int main()
{
    dp[1]=true;
    for(int i=2;i<=am;i++){
        if(dp[i]==true) continue;
        for(int j=i*2;j<=am;j+=i){
            dp[j]=true;
        }
    }
    int s,e;
    cin>>s>>e;
    for(int i=s;i<=e;i++){
        if(dp[i]==false){
            cout<<i<<'\n';
        }
    }
    return 0;
}
