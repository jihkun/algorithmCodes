#include <iostream>
#include <map>

using namespace std;
int p[10000];
int f(int i){
    if(p[i]==i) return i;
    else return p[i]=f(p[i]);
}
void uni(int i,int j){
    i=f(i);
    j=f(j);
    if(i>j) p[i]=j;
    else p[j]=i;
}
int main()
{
    int n;
    cin>>n;
    for (int i = 1; i <= n; i++) {
    p[i] = i;
}

    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            int sub;
            cin>>sub;
            if(sub==0) continue;
            uni(i,j);
        }
    }
    for(int i=1;i<=n;i++){
        f(i);
    }
    int ancestor=0;
    int sub;
    cin>>sub;
    ancestor=p[sub];
    for(int i=1;i<m;i++){
        cin>>sub;
        if(p[sub]!=ancestor){
            cout<<"NO";
            return 0;
        }
    }
    cout<<"YES";
    return 0;
}
