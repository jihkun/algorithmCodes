#include <iostream>
using namespace std;
int a[200020][20];
int main() {
    int n,m;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>a[i][0];
    }
    for(int i=1;i<=19;i++){
        for(int j=0;j<n;j++){
            a[j][i]=a[a[j][i-1]][i-1];
        }
    }
    cin>>m;
    for(int i=0;i<m;i++){
        int ac,b;
        cin>>ac>>b;
        for(int k=19;k>=0;k--){
            if(1<<k<=ac){
                ac-=1<<k;
                b=a[b][k];
            }
        }
        cout<<b<<'\n';
    }

    return 0;
}
