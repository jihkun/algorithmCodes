#include <iostream>
#include <queue>
using namespace std;
int chk[10001];
int di[]={1,-1,10};
int main()
{
    int n,m;
    cin>>n>>m;
    queue<int> q;
    q.push(n);
    while(!q.empty()){
        int d=q.front();
        if(d==m){
            cout<<chk[d];
            return 0;
        }
        q.pop();
        for(int k=0;k<3;k++){
            int dk=d+di[k];
            if(dk>=0&&dk<=10000){
                if(chk[dk]==0){
                    chk[dk]=chk[d]+1;
                    q.push(dk);
                }
            }
        }
        if(d*5<=10000){
            if(chk[d*5]==0){
                chk[d*5]=chk[d]+1;
                q.push(d*5);
            }
        }
    }

    return 0;
}
