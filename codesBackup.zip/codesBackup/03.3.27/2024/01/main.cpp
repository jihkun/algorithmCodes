#include<bits/stdc++.h>
#define INF 987654321
#define ll long long int
using namespace std;

vector<ll> v, sum, lazy;
int h = 0;

ll setup(ll n, ll hi, ll a) {
    if (hi == a) return sum[n] = v[hi];
    ll mid = (hi + a) / 2;
    ll la = setup(n * 2, hi, mid);
    ll ra = setup(n * 2 + 1, mid + 1, a);
    sum[n] = la ^ ra;
    return sum[n];
}

void upla(ll n, ll s, ll e) {
    if (lazy[n] != 0) {
        sum[n] ^= ((e - s + 1) % 2) * lazy[n];
        if (s != e) {
            lazy[n * 2] ^= lazy[n];
            lazy[n * 2 + 1] ^= lazy[n];
        }
        lazy[n] = 0; // ���� ������Ʈ �� lazy ���� �ʱ�ȭ
    }
}

void update(ll n, ll s, ll e, ll l, ll r, ll diff) {
    upla(n, s, e);
    if (l > e || r < s) return;
    if (l <= s && e <= r) {
        sum[n] ^= ((e - s + 1) % 2) * diff;
        if (s != e) {
            lazy[n * 2] ^= diff;
            lazy[n * 2 + 1] ^= diff;
        }
        return;
    }
    ll mid = (s + e) / 2;
    update(n * 2, s, mid, l, r, diff);
    update(n * 2 + 1, mid + 1, e, l, r, diff);
    sum[n] = sum[n * 2] ^ sum[n * 2 + 1];
}

ll query(ll n, ll s, ll e, ll i) {
    upla(n, s, e);
    if (s == e) return sum[n];
    ll mid = (s + e) / 2;
    if (i <= mid) return query(n * 2, s, mid, i);
    else return query(n * 2 + 1, mid + 1, e, i);
}

int main() {
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    ll n, m;
    cin >> n;
    v = vector<ll>(1000010, 0);
    sum = vector<ll>(4000001, 0);
    lazy = vector<ll>(4000001, 0);
    for (int i = 1; i <= n; i++) {
        cin >> v[i];
    }
    setup(1, 1, n);
    cin >> m;
    for (int i = 0; i < m; i++) {
        ll sub, sub2, sub3, sub4;
        cin >> sub >> sub2;
        if (sub == 1) {
            cin >> sub3 >> sub4;
            update(1, 1, n, sub2 + 1, sub3 + 1, sub4);
        } else {
            cout << query(1, 1, n, sub2 + 1) << '\n';
        }
    }
    return 0;
}
