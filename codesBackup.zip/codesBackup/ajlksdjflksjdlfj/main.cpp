#include <bits/stdc++.h>

using namespace std;
string name_table[21];
queue<pair<int,int> > q;
int main()
{
    int t=0;
    while(1){
        t++;
        int n;
        cin>>n;
        if(!n) break;
        int p=0;
        for(int i=0;i<n;i++){
            cin>>name_table[i];
            for(int j=n-1;j>=0;j--){
                if(j==i) continue;
                char sub;
                cin>>sub;
                if(sub=='P') p++;
                else q.push({j,i});
            }
        }
        cout<<"Group "<<t<<'\n';
        if(p==n*(n-1)){ cout<<"Nobody was nasty\n\n"; continue;}
        while(!q.empty()){
            cout<<name_table[q.front().first]<<" was nasty about "<<name_table[q.front().second]<<'\n';
            q.pop();
        }
        cout<<'\n';

    }
    return 0;
}
