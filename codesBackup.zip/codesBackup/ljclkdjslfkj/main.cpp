#include <iostream>
#include <map>
using namespace std;
long long int a[200001],dp[200001];
map<long long int, int> m;
int main()
{
    int n,k,cnt=0;
    cin>>n>>k;
    for(int i=1;i<=n;i++){
        cin>>a[i];
        dp[i]=dp[i-1]+a[i];
        m[dp[i]]++;
    }
    for(int i=1;i<=n;i++){
        cnt+=m[dp[i]-k];
    }
    cout<<cnt;
    return 0;
}
