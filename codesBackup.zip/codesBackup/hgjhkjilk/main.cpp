#include <iostream>
#include <algorithm>
#define MAX 101
using namespace std;
string a[MAX];
bool chk[MAX][MAX];
int n,m;
int dj[]={1,-1,0,0},di[]={0,0,1,-1};
int cntlist[MAX*MAX/2],cnt=-1;
void dfs(int i,int j){
    if(chk[i][j]==false) cntlist[cnt]++;
    chk[i][j]=true;
    for(int k=0;k<4;k++){
        int nj=j+dj[k],ni=i+di[k];
        if(nj>=0&&nj<m&&ni>=0&&ni<n){
            if(chk[ni][nj]==false&&a[ni][nj]=='1'){
                dfs(ni,nj);
            }
        }
    }
}
int main()
{
    cin>>n>>m;
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            if(chk[i][j]==false&&a[i][j]=='1'){
                cnt++;
                dfs(i,j);
            }
        }
    }
    sort(cntlist,cntlist+cnt+1);
    cout<<cnt+1<<'\n';
    for(int i=0;i<=cnt;i++){
        cout<<cntlist[i]<<' ';
    }
    return 0;
}
