#include <iostream>
#include <vector>
using namespace std;
vector<int> st;
int n,m,k;
bool com(int index){
    bool chk=false;
    if(index>0){
        if(st[index-1]==k-1) return false;
        if(st[index-1]==m-1) chk=true;
    }
    if(index<n){
        if(st[index+1]==k-1) return false;
        if(st[index+1]==m-1) chk=true;
    }
    return chk;
}
int stcnt;
void fin(int bit, int seq){
    if(seq==n){
        for(int i=0;i<st.size();i++){
            if(st[i]==0){
                if(com(i)){
                    stcnt++;
                }
            }
        }
        return;
    }
    for(int i=0;i<n;i++){
        if(bit&(1<<i)) continue;
        st.push_back(i);
        fin(bit|(1<<i),seq+1);
        st.pop_back();
    }
}
int main()
{
    cin>>n>>m>>k;
    fin(0,0);
    cout<<stcnt;
    return 0;
}
