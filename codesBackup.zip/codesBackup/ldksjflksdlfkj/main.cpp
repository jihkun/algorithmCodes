#include <iostream>
#define MAX 10000*500+5
#define INF (1<<31)-1
using namespace std;
int trie[MAX][26];
bool chk[MAX];
int num=2;
void ins(string sub){
    int cur=1;
    for(char i:sub){
        if(trie[cur][i-'A']==-1){
            trie[cur][i-'A']=num++;
        }
        cur=trie[cur][i-'A'];
    }
    chk[cur]=true;
}
bool fin(string sub){
    int cur=1;
    for(char i:sub){
        if(trie[cur][i-'A']==-1){
            return false;
        }
        cur=trie[cur][i-'A'];
    }
    return chk[cur];
}
int main()
{
    fill(&trie[0][0],&trie[MAX-1][25],-1);
    int n,m;
    cin>>n>>m;
    for(int i=0;i<n;i++){
        string sub;
        cin>>sub;
        ins(sub);
    }
    int cnt=0;
    for(int i=0;i<m;i++){
        string sub;
        cin>>sub;
        if(fin(sub)) cnt++;
    }
    cout<<cnt;
    return 0;
}
