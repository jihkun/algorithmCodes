#include <bits/stdc++.h>

using namespace std;
struct dat{
    int f,s;
};
dat a[101];
bool cmp(const dat &u,const dat &v){
    return u.f<v.f;
}
int main()
{
    int tn;
    cin>>tn;
    for(int i=0;i<tn;i++){
        int cnt=0,ma=100001;
        int n;
        cin>>n;
        for(int i=0;i<n;i++){
            cin>>a[i].f>>a[i].s;
        }
        sort(a,a+n,cmp);
        for(int i=0;i<n;i++){
            if(ma>a[i].s){
                ma=a[i].s;
                cnt++;
            }
        }
        cout<<cnt<<'\n';
    }
    return 0;
}
