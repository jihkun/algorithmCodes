#include <bits/stdc++.h>

using namespace std;
string paper[101];
void chk(int s,int g){
    for(int i=s;i<s+10;i++){
        for(int j=g;j<g+10;j++){
            paper[i][j]=true;
        }
    }
}
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        int sub,sub2;
        cin>>sub>>sub2;
        chk(sub,sub2);
    }
    int ch=0;
    for(int i=1;i<=100;i++){
        for(int j=1;j<=100;j++){
            if(paper[i][j]==true){
                ch++;
            }
        }
    }
    cout<<ch;
    return 0;
}
