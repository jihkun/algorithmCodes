#include <iostream>
#include <deque>
using namespace std;
deque<int> d;
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        int sub;
        cin>>sub;
        d.push_back(sub);
    }
    int now_require=1;
    int maxLine=d.size();
    while(maxLine!=0){
        while(now_require!=d.front()&&maxLine!=0){
            d.push_back(d.front());
            d.pop_front();
            maxLine--;
        }
        if(d.front()==now_require){ d.pop_front();maxLine--;}
        else if(d.back()==now_require++){d.pop_back(); maxLine--;}
        else{
            cout<<"Sad";
            return 0;
        }
    }
    while(d.empty()){
        if(d.back()==now_require++){
            d.pop_back();
        }else{
            cout<<"Sad";
            return 0;
        }
    }
    cout<<"Nice";
    return 0;
}
