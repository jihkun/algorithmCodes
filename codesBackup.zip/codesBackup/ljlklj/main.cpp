#include <bits/stdc++.h>

using namespace std;
map<int,string> dat;

int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        string sub;
        cin>>sub;
        int j=0;
        for(j=0;j<dat.size();j++){
            if(dat[j].size()!=sub.size()) continue;
            for(int k=0;k<sub.size();k++){
                bool chk=false;
                for(int l=k;l<sub.size();l++){
                    if(l>=sub.size()){
                        l=0;
                        chk=true;
                    }
                    if(chk==true&&l>k){
                        break;
                    }
                    if(dat[j][l]!=sub[l]){
                        dat.insert(sub);
                        break;
                    }
                }
            }
        }
    }
    cout<<dat.size();
    return 0;
}
