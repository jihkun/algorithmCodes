#include <iostream>
#include <vector>
using namespace std;
int e[100000];
int p[100000];
vector<pair<int,int> > v;
vector<string> ans;
int f(int n){
    if(p[n]==n) return n;
    else return p[n]=f(p[n]);
}
int main()
{
    int n,m;
    cin>>n>>m;
    p[1]=e[1]=1;
    for(int i=2;i<=n;i++){
        cin>>e[i];
        p[i]=i;
    }
    for(int i=0;i<n-1+m;i++){
        int sub,sub2,sub3;
        cin>>sub>>sub2;
        if(sub==0){
            v.push_back({sub2,0});
        }else{
            cin>>sub3;
            v.push_back({sub2,sub3});
        }
    }
    while(!v.empty()){
        pair<int,int> tmp=v.back();
        v.pop_back();
        if(tmp.second==0){
            p[tmp.first]=e[tmp.first];
        }else{
            if(f(tmp.first)==f(tmp.second)) ans.push_back("YES\n");
            else ans.push_back("NO\n");
        }
    }
    while(!ans.empty()){
        cout<<ans.back();
        ans.pop_back();
    }
    return 0;
}
