#include <bits/stdc++.h>
#define INF 1e9
using namespace std;
int dis(int s, int l){

}
int main()
{
    int v,e;
    cin>>v>>e;
    vector<pair<int,int> >arr[v+1];
    for(int i=0; i<e; i++){
        int from,to,val;
        cin>>from>>to>>val;
        arr[from].push_back({,val});
        //arr[to].push_back({from,val}); �� �� �߰��ϸ� ����� �׷����� ��
    }
    int st,en;
    cin>>st>>en;
    int dist[v+1];
    fill(dist,dist+v+1,INF);
    priority_queue<pair<int,int> >q;
    q.push({0,st});
    dist[st]=0;
    while(!q.empty()){
        int cost=-q.top().first;
        int here=q.top().second;
        q.pop();
        for(int i=0; i<arr[here].size(); i++){
            int next=arr[here][i].first;
            int nextcost=arr[here][i].second;
            if(dist[next]>dist[here]+nextcost){
                dist[next]=dist[here]+nextcost;
                q.push({-dist[next],next});
            }
        }
    }
    cout<<dist[en];
    return 0;
}
