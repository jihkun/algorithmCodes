#include <bits/stdc++.h>
using namespace std;
bool dat[1000001];
int main()
{
    dat[1]=true;
    for(int i=2;i<=sqrt(1000000);i++){
        if(dat[i]==true) continue;
        for(int j=i*i;j<=1000000;j+=i){
            dat[j]=true;
        }
    }
    int n;
    cin>>n;
    for(int i=n;i<=1000000;i++){
        if(dat[i]==false){
            string sub=to_string(i);
            reverse(sub.begin(),sub.end());
            int is=stoi(sub);
            if(is==i){
                cout<<i;
                return 0;
            }
        }
    }
    return 0;
}
