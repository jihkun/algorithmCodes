#include <iostream>
#include <string>
#include <vector>
#include <cstring>
using namespace std;
//making_trie
int chk[1000000];
int tri[1000000][26];
int num=2;
void ins(string a){
  int sub=0;
  for(auto i:a){
    if(tri[sub][i-'a']==-1){
      tri[sub][i-'a']=num++;
      chk[sub]++;
    }
    sub=tri[sub][i-'a'];
  }
  chk[sub]=-1;
}
int fin(string a){
  int sub=0,cou=1;
  for(int j=0;j<a.size();j++){
    int i=a[j];
    if(tri[sub][i-'a']==-1){
      return cou+j-1;
    }
    sub=tri[sub][i-'a'];
    if(chk[sub]>1) cou++;
  }
  return cou;
}
int main() {
  int n;
  while(cin>>n){
    memset(tri,-1,sizeof(tri));
    memset(chk,0,sizeof(chk));
    vector<string> tc;
    for(int i=0;i<n;i++){
      string sub;
      cin>>sub;
      tc.push_back(sub);
      ins(sub);
    }
    int ans=0;
    for(auto i:tc){
      ans+=fin(i);
    }
    cout<<(float)ans/tc.size()<<'\n';
  }
}
