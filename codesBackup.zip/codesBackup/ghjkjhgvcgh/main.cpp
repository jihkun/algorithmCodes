#include<bits/stdc++.h>
using namespace std;
string d[]={"c=","c-","dz=","d-","lj","nj","s=","z="};
int main(){
    string a;
    cin>>a;
    int cnt=0;
    for(int i=0;i<a.size()-1;i++){
        for(int j=0;j<8;j++){
            for(int k=0;k<d[j].size();k++){
                if(a[i+k]==d[j][k]){
                    if(k==d[j].size()-1){
                        cnt++;
                        break;
                    }else{
                        break;
                    }
                }
            }
        }
    }
    cout<<cnt;
    return 0;
}
