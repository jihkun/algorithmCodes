#include <iostream>

using namespace std;
int parent[1000100];
int fin(int x){
    if(parent[x]==x){
        return x;
    }
    return parent[x]=fin(parent[x]);
}
void mer(int a,int b){
    int sub=fin(a);
    int sub2=fin(b);
    if(sub==sub2){
        return;
    }
     parent[sub2] = sub;
}
int main()
{
    ios_base :: sync_with_stdio(false);

cin.tie(NULL);

cout.tie(NULL);
    int n,m;
    cin>>n>>m;
    for(int i=0;i<=n;i++){
        parent[i]=i;
    }
    for(int i=0;i<m;i++){
        bool sub;
        int a,b;
        cin>>sub>>a>>b;
        if(!sub){
            mer(a,b);
        }else{
            int sub=fin(a);
            int sub2=fin(b);
            if(sub!=sub2) cout<<"NO\n";
            else cout<<"YES\n";
        }
    }
    return 0;
}
