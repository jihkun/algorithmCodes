#include <bits/stdc++.h>

using namespace std;
int a[51];
vector<int> v;
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    for(int i=0;i<n;i++){
        int sub;
        cin>>sub;
        v.push_back(sub);
    }
    sort(v.begin(),v.end());
    sort(a,a+n);
    int cnt=0;
    for(int i=0;i<n;i++){
        cnt+=a[i]*v.back();
        v.pop_back();
    }
    cout<<cnt;
    return 0;
}
