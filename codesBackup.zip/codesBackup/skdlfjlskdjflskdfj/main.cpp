#include <iostream>
#include <queue>
#include <cstring>
using namespace std;
int a[10000][10000];
int chk[10000][10000];
int di[]={0,0,-1,1};
int dj[]={1,-1,0,0};
int main()
{
    memset(chk,-1,sizeof(chk));
    queue<pair<int,int> > q;
    int n,m,limit_cou=0,cou=0;
    cin>>n>>m;
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            cin>>a[i][j];
            if(a[i][j]==-1){
                q.push({i,j});
                chk[i][j]=0;
            }
            if(a[i][j]==1){
                limit_cou++;
            }
        }
    }
    int ma=0;
    while(!q.empty()){
        int ti=q.front().first;
        int tj=q.front().second;
        q.pop();
        for(int k=0;k<4;k++){
            int ni=ti+di[k];
            int nj=tj+dj[k];
            if(ni>=0&&ni<n&&nj>=0&&nj<m){
                if(a[ni][nj]==1&&chk[ni][nj]==-1){
                    chk[ni][nj]=chk[ti][tj]+1;
                    q.push({ni,nj});
                    cou++;
                    ma=max(ma,chk[ni][nj]);
                }
            }
        }
    }
    if(cou!=limit_cou){
        cout<<"-1";
    }else{
        cout<<ma;
    }
    return 0;
}
