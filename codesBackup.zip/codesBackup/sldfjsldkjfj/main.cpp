#include <iostream>
#include <map>
#define ll long long
using namespace std;
ll a[200001];
vector<map<int,int> > v[800008];
ll update(ll n,ll s,ll e, ll i, ll v){
    if(i<s||i>e) return sum[n];
    if(s==e) return sum[n]=v;
    ll mid=(s+e)/2;
    return sum[n]=update(n*2,s,mid,i,v)+update(n*2+1,mid+1,e,i,v);
}
ll qu(ll n,ll s,ll e,ll l,ll r){
    if(l>e||r<s) return 0;
    if (l<=s&&e<=r) return sum[n];
    ll mid=(s+e)/2;
    return qu(n*2,s,mid,l,r)+qu(n*2+1,mid+1,e,l,r);
}
int main()
{
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    ll n,m;
    cin>>n>>m;
    for(ll i=0;i<m;i++){
        ll sub,sub2,sub3;
        cin>>sub>>sub2>>sub3;
        if(sub==0){
            cout<<qu(1,1,n,min(sub2,sub3),max(sub2,sub3))<<'\n';
        }else{
            update(1,1,n,min(sub2,sub3),max(sub2,sub3));
        }
    }
    return 0;
}
