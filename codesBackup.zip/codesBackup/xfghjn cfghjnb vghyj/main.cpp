#include <iostream>
#include <math.h>
#include <cmath>
#include <vector>
#include <cstring>
using namespace std;
vector<int> v[10000];
bool chk[10000];
int a[10000];
int k;
bool dfs(int i){
    for(int k=0;k<v[i].size();k++){
        int di=v[i][k];
        if(chk[di]) continue;
        else chk[di]=true;
        if(a[di]==0||dfs(a[di])){
            a[di]=i;
            return true;
        }
    }
    return false;
}
int main()
{
    int n,m;
    cin>>n>>m>>k;
    for(int i=1;i<=n;i++){
        int sub;
        cin>>sub;
        while(sub--){
            int sub2;
            cin>>sub2;
            v[i].push_back(sub2);
        }
    }
    int cnt=0;
    for(int i=1;i<=n;i++){
            memset(chk, 0, sizeof(chk));
            if(dfs(i)) cnt++;
    }
    for(int i=1;i<=n;i++){
        memset(chk, 0, sizeof(chk));
        if(k>0) if(dfs(i)){ cnt++; k--;}
    }
    cout<<cnt;
    return 0;
}
