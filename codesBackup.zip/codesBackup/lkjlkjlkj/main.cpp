#include <iostream>

using namespace std;
stack<int> s;
int main()
{
    int n;
    cin>>n;

    return 0;
}
