#include <iostream>
#include <algorithm>
using namespace std;
int a[1000000];
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    sort(a,a+n);
    int m;
    cin>>m;
    for(int i=0;i<m;i++){
        int sub;
        cin>>sub;
        cout<<upper_bound(a,a+n,sub)-lower_bound(a,a+n,sub)<<' ';
    }
    return 0;
}
