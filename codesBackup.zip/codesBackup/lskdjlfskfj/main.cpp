#include <iostream>
#include <vector>
#include <cstring>
using namespace std;
vector<int> v[1000], ve[1000];
int d[1000];
bool chk[1000];
bool fin(int t){
    for(int i=0;i<v[t].size();i++){
        int di=v[t][i];
        if(chk[di]) continue;
        else chk[di]=true;
        if(d[di]==0||fin(d[di])){
            d[di]=t;
            return true;
        }
    }
    return false;
}
bool fine(int t){
    for(int i=0;i<ve[t].size();i++){
        int di=ve[t][i];
        if(chk[di]) continue;
        else chk[di]=true;
        if(d[di]==0||fine(d[di])){
            d[di]=t;
            return true;
        }
    }
    return false;
}
int main()
{
    int n,m,k1,k2;
    cin>>n>>m>>k1>>k2;
    for(int i=0;i<k1;i++){
        int sub,sub2;
        cin>>sub>>sub2;
        v[sub].push_back(sub2);
    }
    for(int i=0;i<k2;i++){
        int sub,sub2;
        cin>>sub>>sub2;
        ve[sub].push_back(sub2);
    }
    int cnt=0,cnt2=0;
    for(int i=1;i<=n;i++){
        memset(chk, 0, sizeof(chk));
        if(fin(i)) cnt++;
    }
    memset(d,0,sizeof(d));
    for(int i=1;i<=n;i++){
        memset(chk, 0, sizeof(chk));
        if(fine(i)) cnt2++;
    }
    if(cnt>=cnt2) cout<<"�׸� �˾ƺ���";
    else cout<<"�� ���� ������";
    return 0;
}
