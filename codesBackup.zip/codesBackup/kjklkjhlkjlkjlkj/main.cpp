#include <iostream>
#include <queue>
using namespace std;
int a[11][11];
bool chk[11][11];
int di[]={1,-1,0,0},dj[]={0,0,1,-1};
void dfs(int i,int j){
    chk[i][j]=true;
    for(int k=0;k<4;k++){
        int ni=i+di[k],nj=j+dj[k];
        if(ni>=0&&ni<10&&nj>=0&&nj<10){
            if(a[ni][nj]==1||a[ni][nj]==2){
                if(chk[ni][nj]==false){
                    dfs(ni,nj);
                }
            }else if(a[ni][nj]==0){
                a[ni][nj]=9;
                chk[ni][nj]=1;
            }
        }
    }
}
queue<pair<int,int> > q;
int main()
{
    for(int i=0;i<10;i++){
        for(int j=0;j<10;j++){
            cin>>a[i][j];
            if(a[i][j]==1) q.push({i,j});
        }
    }
    while(!q.empty()){
        dfs(q.front().first,q.front().second);
        q.pop();
    }
    cout<<"\n\n\n\n\n\n\n\n\n";

    for(int i=0;i<10;i++){
        for(int j=0;j<10;j++){
            cout<<a[i][j]<<' ';
        }
        cout<<'\n';
    }
    return 0;
}
