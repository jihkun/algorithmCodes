#include <bits/stdc++.h>
using namespace std;
bool cmp(string u, string v){
    return u.size()>v.size();
}
string a[10000];
map<char,int> m;
int main()
{
    int n, malen=0;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>a[i];
        reverse(a[i].begin(),a[i].end());
        malen=max(malen,(int)a[i].size());
    }
    sort(a,a+n,cmp);
    int
    return 0;
}
