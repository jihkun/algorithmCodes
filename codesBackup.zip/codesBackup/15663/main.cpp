#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;
int a[10000];
void fin(int bit,vector<int> q,int e,int n){
    if(e==q.size()){
        for(auto i:q) cout<<i<<' ';
        cout<<'\n';
        return;
    }
    bool number_used[10010]={false};
    for(int i=0;i<n;i++){
        if(bit&(1<<i)) continue;
        if(number_used[a[i]]) continue;
        number_used[a[i]]=true;
        q.push_back(a[i]);
        fin(bit|(1<<i),q,e,n);
        q.pop_back();
    }
}
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    sort(a,a+n);
    fin(0,vector<int>(),m,n);
    return 0;
}
