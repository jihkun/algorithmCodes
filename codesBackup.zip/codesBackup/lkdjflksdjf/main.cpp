#include <iostream>
#include <map>
using namespace std;

int main()
{
    int a,b,c,cnt=0;
    cin>>a>>b>>c;
    if(a>=10) cnt+=a*500*0.9;
    else cnt+=a*500;
    if(b>=15) cnt+=b*800*0.85;
    else cnt+=b*800;
    cnt+=c*1000;
    cout<<cnt;
    return 0;
}
