#include <iostream>
#include <vector>
#include <cstdarg>
#include <thread>
#include <mutex>
#include <queue>
#include <utility>
#include <filesystem>
#include <map>
namespace fs = std::filesystem;
struct texture;
std::map<std::string,
std::vector<std::pair<std::string, std::thread> > q;
std::mutex me;
class engine;
void render(engine *dat){

}
struct index{
    std::string te, hi;
};
struct coord_2d {
    int x, y;
    coord_2d(int a, int b) : x(a), y(b) {}
};
class hitbox {
private:
    int design;
    int x, y;
    int hi, wi;

public:
    std::vector<std::vector<int>> v;

    void set_design(int des, ...) {
        if (des < 4) {
            va_list args;
            va_start(args, des);
            x = va_arg(args, int);
            y = va_arg(args, int);
            va_end(args);
            design = des;
        }
    }

    // load_from_file
};

class object2d {
private:
    coord_2d coord;
    int shape, texture;
    hitbox hit;
    std::string name;
    int hi, wi;
public:
    void set_hit(hitbox in) {
        hit = in;
    }

    void se(coord_2d c, int h, int w, std::string na, int sh) {
        coord = c;
        point = *po;
        hi = h;
        wi = w;
        // 'degree'�� ��𿡼� ���ǵǴ��� �� �� ��� �������� ���߽��ϴ�.
        // degree = de;
        name = na;
        shape = sh;
    }

    int en() {
        point = INF;
    }

    auto return_object(int type) {
        if (type == 1) {
            return hit;
        } else if (type == 0) {
            object2d sub;
            sub.coord = coord;
            sub.point = point;
            sub.hit = hit;
            sub.name = name;
            return sub;
        }
    }
};

class engine {
private:
    std::vector<object2d> v;
    std::vector<object2d> dv;
    GLFWwindow* window;
public:
    void starting(int x, int y, string enginename){

        //GLFW window start
        glfwInit()
        glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
        glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
        glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
        window = glfwCreateWindow(x, y, enginename, NULL, NULL);
        if (!window) {
            glfwTerminate();
            return -1;
        }
        glfwMakeContextCurrent(window);
        std::thread ren(render, this);
        q.push({"render", ren});

        //find default textures
        fs::path cp = fs::current_path();

        std::string relativeFilePath = "default";
        cp/=relativeFilePath;
        for (const auto& x : fs::directory_iterator(cp)) {
            if (fs::is_regular_file(x)) {
                std::string read_path = x.path();
                std::ifstream refi(read_path);
                if (refi.is_open()) {
                    std::string line;
                    while (std::getline(refi, line)) {
                        int i=0;
                        int s[10]={};
                        for(int k=0;k<5;k++){
                            while(line[i]!=' '){
                                s[k]*=10;
                                s[k]+=line[i]-'0';
                            }
                        }
                        std::string sl;
                        while(line[i]!=' '){
                            sl+=line[i];
                        }
                        object2d sub.se(coord_2d(s[0],s[1]), s[3], s[4], sl, s[2]);
                        this->dv.push_back(sub);
                    }
                    refi.close();
                }
            }
        }
    }
    void turn_off(){
        while(!q.empty()){
            std::thread sub = q.back().second;
            sub.join();
            q.pop_back();
        }
        glfwTerminate();
        exit(0);
    }
    // ������ ���� ���� �ڵ�� ����
};
