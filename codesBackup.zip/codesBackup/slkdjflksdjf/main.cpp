#include <iostream>
#define imsub '_'
#include <vector>
using namespace std;
vector<int> L(string a){
    int l=0, i=1, siz=a.size();
    vector<int> dat(siz,0);
    while(i<siz){
        if(a[l]==a[i]){
            dat[i++]=++l;
        }else{
            if(l!=0){
                l=dat[l-1];
            }else{
                dat[i]=0;
                i++;
            }
        }
    }
    return dat;
}
int main()
{
    int n;
    cin>>n;
    string a;
    cin>>a;
    vector<int> dat=L(a);
    cout<<a.size()-dat[a.size()-1];
    return 0;
}
