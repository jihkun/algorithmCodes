#include <iostream>
#include <cstring>
#include <map>
#define ll long long int
using namespace std;
ll ps[1000000];
ll ar[1000000];
map<ll,int> ma;
int main()
{
    ll n,m,cnt=0;
    cin>>n>>m;
    for(int i=0;i<n;i++){
        cin>>ar[i];
        ps[i]=ps[i-1]+ar[i];
        if(ps[i]==m){
            cnt++;
        }
    }
    for(int i=0;i<n;i++){
        cnt+=ma[ps[i]-m];
        ma[ps[i]]++;
    }
    cout<<cnt;
    return 0;
}
