#include <bits/stdc++.h>
#include <windows.h>
using namespace std;
stack<int> s;
stack<pair<int,int> > re;
int main()
{
    int n;
    cin<<n;
    for(int i=0;i<n;i++){
        int sub;
        cin>>sub;
        s.push(sub);
        re.push({0,0});
        thread
    }
    return 0;
}
