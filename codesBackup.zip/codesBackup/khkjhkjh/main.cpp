#include <bits/stdc++.h>

using namespace std;

int k,mi,ma;
char c[1001];
bool chk[1001];
vector<int> v;
vector<string> ans;

bool check(){
    for(int i=0;i<k;i++){
        if(c[i]=='>') if(v[i]<v[i+1]) return 0;
        else if(v[i]>v[i+1]) return 0;
    }
    return 1;
}
void dfs(int a){
    if(a==k+1){
            if(check()){
                string s="";
                for(int i=0;i<v.size();i++){
                    s+=to_string(v[i]);
                }
                ans.push_back(s);
            }
        }
        return;
    for(int i=0; i<10; i++){
        if(chk[i])
            continue;
        v.push_back(i);
        chk[i] = true;
        dfs(a+1);
        v.pop_back();
        chk[i] = false;
    }
}
int main()
{
    cin>>k;
    for(int i=0;i<k;i++){
        cin>>c[i];
    }
    dfs(0);
    sort(ans.begin(),ans.end());
    cout<<ans[ans.size()-1]<<'\n'<<ans[0];
    return 0;
}
