#include <iostream>
#include <vector>
#define INF 1e10
using namespace std;
struct edge{
    long long int f,s,t;
};
//vector<edge> v;
long long int dist[1010];
int main()
{
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);)
    fill(&dist[0],&dist[1000],INF);
    int n,m;
    cin>>n>>m;
    vector<edge> v;
    for(int i=0;i<m;i++){
        int sub,sub2,sub3;
        cin>>sub>>sub2>>sub3;
        v.push_back({sub,sub2,sub3});
    }
    dist[1]=0;
    bool change_flag=false;
    for(long long int i=0;i<n;i++){
        change_flag=false;
        for(auto j:v){
            if(dist[j.f]==INF) continue;
            if(dist[j.s]>dist[j.f]+j.t){
                if(i!=n-1) dist[j.s]=dist[j.f]+j.t;
                else{
                    cout<<"-1";
                    return 0;
                }
            }
        }
    }
    for(int i=2;i<=n;i++){
        if(dist[i]!=INF) cout<<dist[i]<<'\n';
        else cout<<"-1\n";
    }

    return 0;
}
