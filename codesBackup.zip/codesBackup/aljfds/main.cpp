#include <iostream>

using namespace std;
zero(int a){exit(!a);}
int main()
{
    int a;
    cin>>a;
    cout<<zero(a);
    return 0;
}
