#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
long long int p[202020];
struct edge{
    long long int d, n1,n2;
};
bool cmp(const edge &u, const edge &v){ return u.d<v.d; }
vector<edge> v;
int fin(long long int f){
    if(p[f]==f) return f;
    return p[f]=fin(p[f]);
}
void uni(long long int x, long long int y){
    int i=fin(x);
    int j=fin(y);
      if(i>j) p[j]=i;
    else p[i]=j;
}
int tree(){
    int cnt=0;
    for(int i=0;i<v.size();i++){
        int il=fin(v[i].n1);
        int jl=fin(v[i].n2);
        if(il==jl){
            continue;
        }
        cnt+=v[i].d;
        uni(v[i].n1,v[i].n2);
    }
    return cnt;
}
int main()
{
    while(1){
        long long int n,m,cnt=0,sum=0;
        cin>>n>>m;
        if(n==m&&m==0) return 0;
        for(int i=0;i<=n;i++){
            p[i]=i;
        }
        for(int i=0;i<m;i++){
            int sub,sub2;
            cin>>sub>>sub2;
            int sub3;
            cin>>sub3;
            sum+=sub3;
            v.push_back({sub3,sub,sub2});
        }

        sort(v.begin(),v.end(),cmp);
        cout<<sum-tree()<<'\n';
        while(!v.empty()){
            v.pop_back();
        }
    }
    return 0;
}
