#include <bits/stdc++.h>
using namespace std;
#include "header01.h"
#include "specchk.h"
#include "headerverchk.h"
#include "var.h"

user user_data[51];

int game_board[25][25];
int people;
FILE* ld = fopen("log.dev","a+");
void setup(string vFILE){
	blunchchk();
	fprintf(ld,"start spec chk. time : %d\n",time(NULL));
	s_b(0);
	fprintf(ld,"end spec chk. time : %d\n",time(NULL));
}
void selec(int pointer){
	if(!pointer) select_();
	else if(!(pointer-1)) blunchchk();
	else exit(0);
}
