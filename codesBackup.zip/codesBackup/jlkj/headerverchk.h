int blunchchk(){
    if(head01chk(0)<2){
        cout<<"error : can't find header\nstop program with code 1;";
        exit(1);
    }else{
        return 0;
    }
}
