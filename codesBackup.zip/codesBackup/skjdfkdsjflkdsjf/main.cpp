#include <iostream>
#include <queue>
#include <cstring>
using namespace std;
vector<int> v[100000];
int p[100000],d[100000];
int L(int a, int b){
    if(d[a]<d[b]) swap(a,b);
    while(d[a]!=d[b]){
        a=p[a];
    }
    while(a!=b){
        a=p[a];
        b=p[b];
    }
    return a;
}
void setup(int n){
    for(int i=0;i<v[n].size();i++){
        if(sub==0){
            int sub=v[n][i];
            p[n]=ps;
            d[n]=d[ps]+1;
            setup(sub);
        }
    }
}
int main()
{
    int t=0;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        for(int i=0;i<n-1;i++){
            int sub,sub2;
            cin>>sub>>sub2;
            v[sub].push_back(sub2);
            v[sub2].push_back(sub);
        }
        setup(1,0);
        int sub,sub2;
        cin>>sub>>sub2;
        cout<<L(sub,sub2)<<'\n';
        memset(d,0,sizeof(d));
        memset(p,0,sizeof(p));
        for(int i=0;i<=n;i++) v[i]=vector<int>();
    }
    return 0;
}
