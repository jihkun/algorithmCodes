#include <bits/stdc++.h>

using namespace std;

priority_queue<string> q;
int main()
{
    int a,b;
    int c;
    cin>>a>>b>>c;
    int sub=a;
    while(--c){
        if(sub/b==0) sub*=10;
        cout<<sub;
        sub=sub%b;
        cout<<sub;
    }
    cout<<sub;
    return 0;
}
