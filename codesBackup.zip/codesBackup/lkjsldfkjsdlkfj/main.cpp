#include <iostream>
#define int long long
using namespace std;
int a[1000000];
int32_t main()
{
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    int n,b,c;
    int full_cnt=0;
    cin>>n>>b>>c;
    for(int i=0;i<n;i++){
        cin>>a[i];
        full_cnt+=a[i];
    }
    if(b<c){
        cout<<full_cnt*b;
        return 0;
    }
    int cnt=0;
    for(int i=0;i<n;i++){
        if(a[i+1]>a[i+2]){
            int sub=min(a[i],a[i+1]-a[i+2]);
            cnt+=sub*(b+c);
            a[i]-=sub;
            a[i+1]-=sub;
            sub=min(a[i],min(a[i+1],a[i+2]));
            cnt+=sub*(b+c*2);
            a[i]-=sub;
            a[i+1]-=sub;
            a[i+2]-=sub;
        }else{
            int sub=min(a[i],min(a[i+1],a[i+2]));
            cnt+=sub*(b+c*2);
            a[i]-=sub;
            a[i+1]-=sub;
            a[i+2]-=sub;
            sub=min(a[i],a[i+1]);
            cnt+=sub*(b+c);
            a[i]-=sub;
            a[i+1]-=sub;
        }
        cnt+=a[i]*b;
    }
    cout<<cnt;
    return 0;
}
