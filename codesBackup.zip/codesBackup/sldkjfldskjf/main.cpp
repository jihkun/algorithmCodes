#include <iostream>
#include <queue>
using namespace std;

int main()
{
    queue<int> q;
    int n,m;
    cin>>n>>m;

    return 0;
}
