#include <iostream>

using namespace std;

int main()
{
    int n;
    cin>>n;
    while(n--){
        int x,y,d,x2,y2,d2;
        cin>>x>>y>>d>>x2>>y2>>d2;
        if(x==y&&x2==y2&&d==d2){ cout<<-1<<'\n'; continue;}
        else if(x==y&&x2==y2){cout<<0<<'\n'; continue;}
        int xp=abs(x-x2)*abs(x-x2),yp=abs(y-y2)*abs(y-y2);
        int dis=(d-d2)*(d-d2);
        if(xp>dis) cout<<0<<'\n';
        else if(xp<dis) cout<<2<<'\n';
        else if(xp==dis) cout<<1<<'\n';

    }
    return 0;
}
