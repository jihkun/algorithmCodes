#include <bits/stdc++.h>
using namespace std;
int main(){
  	long long int n,m;
  	cin>>n>>m;
  	for(int l=1;l<=n;l++){
    	long long int sub;
      	cin>>sub;
      	long long int cnt=0;
      	for(int i=1;sub>=i*i;i++){
        	if(sub%i==0){
                    cnt++;
                    if(i*i!=sub) cnt++;
        	}
        }
      	for(int i=sub*2;i<=m;i+=sub) cnt++;
      	cout<<cnt<<'\n';
    }
}
