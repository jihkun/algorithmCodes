#include <iostream>
#include <queue>
using namespace std;
string a[1000];
int di[]={1,-1,0,0},dj[]={0,0,-1,1};
int main()
{
    int n,m,cnt=0;
    cin>>n>>m;
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    for(int i=0;i<n;i++){
      for(int j=0;j<m;j++){
      	if(a[i][j]=='W'){
        	for(int k=0;k<4;k++){
            	if(a[di[k]+i][dj[k]+j]=='P'){
                	cnt++;
                  	a[di[k]+i][dj[k]+j]='.';
                  	break;
                }
            }
        }
      }
    }
    cout<<cnt;
    return 0;
}
