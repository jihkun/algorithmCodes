#include <iostream>
#include <stack>
#include <algorithm>
#include <windows.h>
#define MAX 10000000
using namespace std;
struct fs{
    int i,j,k,arr;
};
int n,m;
string a[101];
stack<fs> fs;
bool chk[101][101];
int ca[101*101],cnt;
int di[]={0,0,-1,1},dj[]={1,-1,0,0};

int main()
{
    cin>>n>>m;
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            if(a[i][j]!='0'&&chk[i][j]==0){
                fs.push({i,j,0});
                while(!fs.empty()){
                    int i=fs.top().i,j=fs.top().j,k=fs.top().k;
                    fs.pop();
                    if(chk[i][j]==0){
                        chk[i][j]=true;
                        ca[cnt]++;
                    }
                    for(;k<4;k++){
                        int ni=i+di[k];
                        int nj=j+dj[k];
                        if(ni>=0&&ni<n&&nj>=0&&nj<m){
                            if(chk[ni][nj]==0&&a[ni][nj]=='1'){
                                fs.push({i,j,k});
                                fs.push({ni,nj,0});
                                break;
                            }
                        }
                    }
                }
                cnt++;
            }
        }
    }
    cout<<cnt<<'\n';
    sort(ca,ca+cnt);
    for(int i=0;i<cnt;i++){
        cout<<ca[i]<<' ';
    }
    return 0;
}
