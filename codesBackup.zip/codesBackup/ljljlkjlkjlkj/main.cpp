#include <bits/stdc++.h>
#define MAX 1e10+1
#define MIN -1e10+1
using namespace std;
int v[100001],n2,ma=MIN,mi=MAX,a2,b2,c2,d2;
void f(int n,int m,int a,int b,int c,int d){
    if(n==n2){ma=max(ma,m);mi=min(mi,m);}
    if(a) f(n+1,m+v[n],a-1,b,c,d);
    if(b) f(n+1,m-v[n],a,b-1,c,d);
    if(c) f(n+1,m*v[n],a,b,c-1,d);
    if(d) f(n+1,m/v[n],a,b,c,d-1);

}
int main()
{
    cin>>n2;
    for(int i=0;i<n2;i++){cin>>v[i];}
    cin>>a2>>b2>>c2>>d2;
    f(1,v[0],a2,b2,c2,d2);
    cout<<ma<<'\n'<<mi;
}
