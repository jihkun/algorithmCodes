#include <iostream>
#include <map>
using namespace std;
int p[100000];
map<int,bool> ma;
int f(int x){
    if(p[x]==x) return x;
    return p[x]=f(p[x]);
}
void uni(int a,int b){
    a=f(a);
    b=f(b);
    if(ma[a]||b<a) p[b]=a;
    else if(ma[b]||a<b) p[a]=b;
}
int main()
{
    int n,m,su;
    cin>>n>>m>>su;
    for(int i=0;i<su;i++){
        int sub;
        cin>>sub;
        ma[sub]=true;
    }
    for(int i=0;i<=n;i++){
        p[i]=i;
    }
    for(int i=0;i<m;i++){
        int sub;
        cin>>sub;
        uni(sub,sub2);
    }
    int cnt=1;
    for(int i=1;i<=n;i++){
        cout<<p[i]<<' ';
    }
    return 0;
}
