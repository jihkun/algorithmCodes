#include <iostream>
#include <map>
#include <vector>
using namespace std;
int p[100000];
map<int,bool> ma;
vector<vector<int> > party;
int f(int x){
    if(p[x]==x) return x;
    return p[x]=f(p[x]);
}
void uni(vector<int> v){
    int setup_pointer=100000,ma_setup_pointer=100000;
    for(int i=0;i<v.size();i++){
        v[i]=f(v[i]);
        if(ma[v[i]]==true){
            ma_setup_pointer=min(v[i],ma_setup_pointer);
        }else{
            setup_pointer=min(v[i],setup_pointer);
        }
    }
    for(int i=0;i<v.size();i++){
        if(ma_setup_pointer>=100000) p[v[i]]=setup_pointer;
        else p[v[i]]=ma_setup_pointer;
    }
}
int main()
{
    int n,m,su;
    cin>>n>>m>>su;
    for(int i=0;i<su;i++){
        int sub;
        cin>>sub;
        ma[sub]=true;
    }
    for(int i=0;i<=n;i++){
        p[i]=i;
    }
    int cnt=m;
    for(int i=0;i<m;i++){
        int sub;
        cin>>sub;
        vector<int> subv;
        for(int j=0;j<sub;j++){
            int sub2;
            cin>>sub2;
            subv.push_back(sub2);
        }
        uni(subv);
        party.push_back(subv);
    }
    for(int i=1;i<=n;i++){
        f(i);
    }
    for(auto i:party){
        bool flag=false;
        for(auto j:i){
            if(ma[p[j]]==true){
                flag=true;
                break;
            }
        }
        if(flag) cnt--;
    }
    cout<<cnt;
    return 0;
}
