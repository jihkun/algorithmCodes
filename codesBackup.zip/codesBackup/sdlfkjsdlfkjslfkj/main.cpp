#include <iostream>
#include <vector>
#include <queue>
#include <cstring>
#include <climits>
using namespace std;

#define INF INT_MAX

vector<vector<pair<int, int>>> v;
vector<vector<int>> prv;
bool chk[501][501];
int n, m, se, e;

int fin(int s) {
    vector<int> dist(n + 1, INF);
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> q;
    prv = vector<vector<int>>(n + 1);

    q.push({0, s});
    dist[s] = 0;

    while (!q.empty()) {
        int cur = q.top().second;
        int cost = q.top().first;
        q.pop();

        if (cost > dist[cur]) continue;

        for (auto x : v[cur]) {
            if (chk[cur][x.first]) continue;

            int next = x.first;
            int ncost = x.second;

            if (dist[next] == dist[cur] + ncost) {
                prv[next].push_back(cur);
            }

            if (dist[next] > dist[cur] + ncost) {
                prv[next].clear();
                prv[next].push_back(cur);
                dist[next] = dist[cur] + ncost;
                q.push({dist[next], next});
            }
        }
    }
    return dist[e] == INF ? -1 : dist[e];
}

void era(int x) {
    for (auto i : prv[x]) {
        if (!chk[i][x]) {
            chk[i][x] = true;
            era(i);
        }
    }
}

int main() {
    while (true) {
        cin >> n >> m;
        if (n == 0 && m == 0) break;

        memset(chk, false, sizeof(chk));
        v = vector<vector<pair<int, int>>>(n + 1);

        cin >> se >> e;
        for (int i = 0; i < m; i++) {
            int sub, sub2, sub3;
            cin >> sub >> sub2 >> sub3;
            v[sub].push_back({sub2, sub3});
        }

        fin(se);
        era(e);
        cout << fin(se) << '\n';
    }
    return 0;
}
