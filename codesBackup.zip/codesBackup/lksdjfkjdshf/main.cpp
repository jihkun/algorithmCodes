#include <bits/stdc++.h>

using namespace std;
vector<int> pv, mv;
int main()
{
    int n,m,cnt=0;
    cin>>n>>m;
    for(int i=0;i<n;i++){
        int sub;
        cin>>sub;
        if(sub>0) pv.push_back(sub);
        else mv.push_back(sub);
    }
    if(mv.empty()) mv.push_back(0);
    if(pv.empty()) pv.push_back(0);
    sort(mv.begin(),mv.end(),greater<int>());
    sort(pv.begin(),pv.end());
    cnt+=max(abs(pv.back()),abs(mv.back()));
    if(abs(mv.back())>abs(pv.back())){
        for(int i=0;i<m;i++){
            if(!mv.empty()) mv.pop_back();
        }
    }else{
        for(int i=0;i<m;i++){
            if(!pv.empty()) pv.pop_back();

        }
    }
    while(!pv.empty()){
        cnt+=abs(pv.back())*2;
        for(int i=0;i<m;i++){
            if(!pv.empty()) pv.pop_back();
            else break;
        }
    }
    while(!mv.empty()){
        cnt+=abs(mv.back())*2;
        for(int i=0;i<m;i++){
            if(!mv.empty()) mv.pop_back();
            else break;
        }
    }
    cout<<cnt;
    return 0;
}
