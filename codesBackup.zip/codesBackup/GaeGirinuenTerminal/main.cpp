#include <iostream>
#include <vector>
#include <map>
#include <windows.h>
#include <fstream>
#include <conio.h>
#include <string>
#include "line_tool.h"
using namespace std;
class terminal{
private:
    line_tool LINE;
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    const WORD background_colors[11] = {
        BACKGROUND_BLUE, BACKGROUND_GREEN, BACKGROUND_RED,
        BACKGROUND_BLUE | BACKGROUND_INTENSITY,
        BACKGROUND_GREEN | BACKGROUND_INTENSITY,
        BACKGROUND_RED | BACKGROUND_INTENSITY,
        BACKGROUND_BLUE | BACKGROUND_GREEN,
        BACKGROUND_BLUE | BACKGROUND_RED,
        BACKGROUND_GREEN | BACKGROUND_RED,
        BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED,
        BACKGROUND_BLUE | BACKGROUND_GREEN | BACKGROUND_RED | BACKGROUND_INTENSITY
    };
    const WORD colors[11] = {
        FOREGROUND_BLUE, FOREGROUND_GREEN, FOREGROUND_RED,
        FOREGROUND_BLUE | FOREGROUND_INTENSITY,
        FOREGROUND_GREEN | FOREGROUND_INTENSITY,
        FOREGROUND_RED | FOREGROUND_INTENSITY,
        FOREGROUND_BLUE | FOREGROUND_GREEN,
        FOREGROUND_BLUE | FOREGROUND_RED,
        FOREGROUND_GREEN | FOREGROUND_RED,
        FOREGROUND_BLUE | FOREGROUND_GREEN | FOREGROUND_RED,
        FOREGROUND_BLUE | FOREGROUND_GREEN | FOREGROUND_RED | FOREGROUND_INTENSITY
    };
    map<string,int> cm;
    map<string,string> d;
    vector<string> buffer;
public:
    //��ũ�� �����
    void ClearScreen() {
    HANDLE hStdout;
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    DWORD count;
    DWORD cellCount;
    COORD homeCoords = { 0, 0 };

    hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
    if (hStdout == INVALID_HANDLE_VALUE) return;
    if (!GetConsoleScreenBufferInfo(hStdout, &csbi)) return;
    cellCount = csbi.dwSize.X * csbi.dwSize.Y;
    if (!FillConsoleOutputCharacter(hStdout, (TCHAR) ' ', cellCount, homeCoords, &count)) return;
    if (!FillConsoleOutputAttribute(hStdout, csbi.wAttributes, cellCount, homeCoords, &count)) return;
    SetConsoleCursorPosition(hStdout, homeCoords);
    }
    void setup(){
        ifstream cmd("cmd.txt");
        ifstream de("cmd_data.txt");
        if(cmd.is_open()){
            string line;
            while(getline(cmd,line)){
                cm[line]=0;
                string sub;
                getline(de,sub);
                d[line]=sub;
            }
            cmd.close();
            de.close();
        }else{
            cout<<"fail to load command list\n";
            system("pause");
        }
    }
    void readline(){
        int key=0;
        while(key!=13){
            if((char)key==' '){
                buffer.push_back("");
            }else{
                if(!buffer.empty()) buffer[buffer.size()-1]+=(char)key;
            }

        }
    }
    void run(){
        string command="";
        for(auto i:buffer){
            command+=" "+i;
        }
        system(comman.c_str()/ )
    }
};
int main()
{

    return 0;
}
