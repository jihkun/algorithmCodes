class line_tool{
public:
    void cur_up{
        cout<<"\033[A";
    }
    void cur_down{
        cout<<"\033[B";
    }
    void erase{
        cout<<"\033[2K";
    }
};
