#include <bits/stdc++.h>
using namespace std;

struct le {
    pair<int,int> s;
    int p;

    le(pair<int,int> sub2, int sub) : s(sub2), p(sub) {}

    bool operator<(const le& other) const {
       return s<other.s;
    }

};

priority_queue<le> q;
priority_queue<pair<int,int>> v;
int dat[100001];

int main() {
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    cout.tie(NULL);

    int n;
    cin >> n;

    for (int i = 1; i <= n; i++) {
        int sub, sub2, sub3;
        cin >> sub >> sub2 >> sub3;
        q.push(le({-sub2, sub3}, i));
    }

    v.push({0, 1});
    int cnt = 0;

    while (!q.empty()) {
        int start = -q.top().s.first, en = q.top().s.second, p = q.top().p;
        q.pop();

        if (-v.top().first <= start) {
            v.pop();
        } else {
            cnt++;
        }

        v.push({-en, cnt});
        dat[p] = cnt;
    }

    for (int i = 1; i <= n; i++) {
        cout << dat[i] << '\n';
    }

    return 0;
}
