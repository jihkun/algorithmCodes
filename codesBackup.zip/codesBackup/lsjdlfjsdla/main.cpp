#include <iostream>

using namespace std;

int main()
{
    int n,lm=0,cnt=0;
    cin>>n;
    for(int i=0;i<n;i++){
        int sub;
        cin>>sub;
        if(sub!=0){
            if(sub-1==lm){
                cnt++;
                if(lm==1){
                    lm=0;
                }else{
                    lm++;
                }
            }else{
                lm=0;
            }
        }else{
            lm=1;
            cnt++;
        }
    }
    cout<<cnt;
    return 0;
}
