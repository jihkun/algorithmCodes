#include <bits/stdc++.h>

using namespace std;
string a;
int a1[100];
int main()
{
    getline(cin,a);
    a1[0]=a[0]+' '+64;
    int as=a1[0];
    for(int i=1;i<a.size();i++){
        a1[i]=(a[i]+' '-32)+(as%10);
        as=a[i]-' '-(50+as);
    }
    for(int i=0;i<a.size();i++){
        printf("%c",a1[i]);
    }

    return 0;
}
