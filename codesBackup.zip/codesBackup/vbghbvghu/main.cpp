#include <iostream>

using namespace std;
vector<int> v;
int main()
{
    system()
    return 0;
}
