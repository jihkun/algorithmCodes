#include <iostream>
#include <deque>
#include <vector>
using namespace std;
int ar[100][100];
bool chk[100][100];
int si[]={0,0,1,-1};
int sj[]={1,-1,0,0};
deque<pair<int, int> > d;
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            cin>>ar[i][j];
        }
    }
    int a,b;
    cin>>a>>b;
    d.push_back({0,0});
    bool read_flag=true;
    while(!d.empty()){
        int di,dj;
        int frontlen=(a-d.front().first)*(a-d.front().first)+(b-d.front().second)*(b-d.front().second);
        int backlen=(a-d.back().first)*(a-d.back().first)+(b-d.back().second)*(b-d.back().second);
        if(frontlen=>backlen){
            di=d.front().first;
            dj=d.front().second;
        }else{
            di=d.back().first;
            dj.d.back().second;
        }
        if(dj==a&&di==b){
            cout<<"YES";
            return 0;
        }
        vector<pair<int,int> > v;
        //si,sj�� ������ ��Ÿ���� ������ ���� ����� ��ġ�� �ְ� �ϴ°� �ڷ� ������ �ڵ�
        for(int k=0;k<4;k++){
            int ni=di+si[k];
            int nj=dj+sj[k];
            if(ni>=0&&ni<n&&nj>=0&&nj<m){
                if(chk[ni][nj]==false&&ar[ni][nj]==0){
                    d.push_back({ni,nj});
                    chk[ni][nj]=true;
                }
            }
        }
    }
    return 0;
}
