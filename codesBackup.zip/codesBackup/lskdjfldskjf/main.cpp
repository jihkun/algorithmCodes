#include <bits/stdc++.h>

using namespace std;
int a[1010][1010];
int dis[1010][1010];
int di[]={1,0,-1,0};
int dj[]={0,1,0,-1};
queue<pair<int,int> > q;
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            cin>>a[i][j];
            q.push({i,j});
        }
    }
    int ma=0;
    while(!q.empty()){
        int ti=q.front().first;
        int tj=q.front().second;
        q.pop();
        for(int i=0;i<4;i++){
            int ni=ti+di[i];
            int nj=tj+dj[i];
            if(ni>=0&&ni<n&&nj>=0&&nj<m){
                if(a[ni][nj]==1&&dis[ni][nj]==0){
                    dis[ni][nj]=dis[ti][tj]+1;
                    q.push({ni,nj});
                    ma=max(dis[ni][nj],ma);
                }
            }
        }
    }
    bool broke=true;
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            if(a[i][j]==1&&dis[i][j]==0) broke=false;
        }
    }
    if(broke) cout<<ma;
    else cout<<'0';
    return 0;
}
