#include <iostream>
#include<queue>
using namespace std;
int a[10000][10000];
long long int dir[10000][10000];
int di[]={1,-1,0,0},dj[]={0,0,-1,1};
queue<pair<int,int> > q;
int main()
{
    long long int n,m,ma=0,cnt=0,sc=0;
    cin>>n>>m;
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            cin>>a[i][j];
            if(a[i][j]==9){
                q.push({i,j});
            }
        }
    }
    while(!q.empty()){
        int i=q.front().first,j=q.front().second;
        q.pop();
        for(int k=0;k<4;k++){
            int ni=i+di[k];
            int nj=j+dj[k];
            if(ni>=0&&ni<n&&nj>=0&&nj<m){
                if(dir[ni][nj]==0&&a[ni][nj]==0){
                    q.push({ni,nj});
                    dir[ni][nj]=dir[i][j]+1;
                    cnt++;
                    ma=max(ma,dir[i][j]+1);
                }
            }
        }
    }
    cout<<cnt<<'\n'<<ma;
    return 0;
}
