#include <iostream>
#include <vector>
#include <queue>
#include <stack>
using namespace std;
int dist[100000];
vector<int> v[100000];
queue<int> q;
stack<int> s;
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=0;i<m;i++){
        int sub;
        cin>>sub;
        int last=-1, now=-1;
        for(int j=0;j<sub;j++){
            last=now;
            cin>>now;
            if(last!=-1){
                v[now].push_back(last);
                dist[last]++;
            }
        }
    }
    for(int i=1;i<=n;i++){
        if(dist[i]==0){
            q.push(i);
        }
    }
    while(!q.empty()){
        int di=q.front();
        s.push(di);
        q.pop();
        for(int i=0;i<v[di].size();i++){
            int ni=v[di][i];
            dist[ni]--;
            if(dist[ni]==0){
                q.push(ni);
            }
        }
    }
    for(int i=1;i<=n;i++){
        if(dist[i]!=0){
            cout<<'0';
            return 0;
        }
    }
    while(!s.empty()){
        cout<<s.top()<<'\n';
        s.pop();
    }
    return 0;
}
