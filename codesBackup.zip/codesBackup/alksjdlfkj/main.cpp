#include <iostream>

using namespace std;
int a[16][2],n,ma;
int dp[16];

int main()
{
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>a[i][0]>>a[i][1];
    }
    for(int i=0;i<n;i++){
        int n1=i+a[i][0];
        int n2=i+1;
        if(n1<=n) dp[n1]=max(dp[n1],dp[i]+a[i][1]);
        if(n2<=n) dp[n2]=max(dp[n2],dp[i]);
        ma=max({dp[i],dp[n1],dp[n2]});
    }
    cout<<ma;
    return 0;
}
