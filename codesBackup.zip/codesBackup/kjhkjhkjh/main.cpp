#include <bits/stdc++.h>
#define dist 10001
using namespace std;
vector<int> v[dist];
vector<int> chk;
int dis[dist];
int cnt,ans;
void dfs(int visit){
    dis[visit]++;
    ans=max(ans,dis[visit]);
    for(int i=0;i<v[visit].size();i++){
        int di=v[visit][i];
        if(chk[di]==0){
            dis[di]=dis[visit]+1;
            dfs(di);
        }
    }
}
int main()
{
    int n,m,ma=0;
    cin>>n>>m;
    for(int i=0;i<m;i++){
        int sub,sub2;
        cin>>sub>>sub2;
        v[sub].push_back(sub2);
    }
    for(int i=1;i<=n;i++){
        chk=vector<int> (n+1,0);
        cnt=0;
        chk[i]++;
        dfs(i);
    }
    for(int i=1;i<=n;i++){

        if(dis[i]==ans) cout<<i<<' ';
    }
    return 0;
}
