#include <iostream>
#include <vector>
#define ll long long
using namespace std;
vector<int> v;
bool el[4100000];
int main()
{
    ll int n;
    cin>>n;
    el[1]=true;
    for(int i=2;i*i<=n;i++){
        if(el[i]==true) continue;
        for(int j=i*i;j<=n;j+=i){
            el[j]=true;
        }
    }
    for(int i=1;i<=n;i++){
        if(!el[i]) v.push_back(i);
    }
    ll sum=0;
    ll cnt=0;
    int l=0,r=1;
    sum+=v[0];
    if(v.size()==0){
        cout<<'0';
        return 0;
    }
    while(r<=v.size()){
        if(sum==n){
            cnt++;
            sum-=v[l++];
        }else if(sum>n){
            sum-=v[l++];
        }else{
            sum+=v[r++];
        }
    }
    cout<<cnt;
    return 0;
}
