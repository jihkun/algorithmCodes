#include <iostream>
#include <vector>
#include <queue>
#define MAX 10000000
#include <cstring>
#include <climits>  // INT_MAX�� ���� �߰�
using namespace std;

vector<pair<int, int>> v[MAX];
int dist[MAX];
int se, e, n;
bool chk[1001][1001];
vector<vector<int>> prv;

int fin(int s) {
    prv = vector<vector<int>>(n + 1);
    fill(dist, dist + n, INT_MAX);  // �޸� ��� ����ȭ
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> q;
    q.push({0, s});
    dist[s] = 0;

    while (!q.empty()) {
        int ti = q.top().second;
        int tc = q.top().first;
        q.pop();
        if(tc>dist[ti]) continue;
        for (auto i:v[ti]) {
            int ni = i.first;
            int nc = i.second;
            if (dist[ni] == nc + tc) {
                prv[ni].push_back(ti);
            }
            if (dist[ni] > nc + dist[ti]) {
                dist[ni] = nc + dist[ti];
                prv[ni].clear();
                prv[ni].push_back(ti);
                q.push({dist[ni], ni});
            }
        }
    }
    return dist[e] == INT_MAX ? -1 : dist[e];
}

void era(int x) {
    for (auto i : prv[x]) {
        for (int j = 0; j < v[i].size(); j++) {
            if (v[i][j].first == x && !chk[i][x]) {
                chk[i][x] = true;
                era(i);
                break;
            }
        }
    }
}

int main() {
    int m;
    cin >> n >> m;
    while (m != 0 && n != 0) {
        prv.clear();
        memset(chk, false, sizeof(chk));
        cin >> se >> e;
        for (int i = 0; i <= n; i++) {
            v[i].clear();
        }
        for (int i = 0; i < m; i++) {
            int sub, sub2, sub3;
            cin >> sub >> sub2 >> sub3;
            v[sub].push_back({sub2, sub3});
        }
        fin(se);
        era(e);
        cout << fin(se) << '\n';
        cin >> n >> m;
    }
    return 0;
}
