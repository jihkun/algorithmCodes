#include <iostream>
#include <bits/stdc++.h>
using namespace std;
priority_queue<pair<int,int> > q;
vector<pair<int,int> > v[500];
int dist[10022];
int main()
{
    int n,m;
    for(int i=2;i<=10000;i++) dist[i]=987654321;
    cin>>n>>m;
    for(int i=0;i<m;i++){
        int sub,sub2,sub3;
        cin>>sub>>sub2>>sub3;
        v[sub].push_back({sub2,sub3});
        v[sub2].push_back({sub,sub3});
    }
    int f,s;
    cin>>f>>s;
    q.push({0,f});
    while(!q.empty()){
        int ti=q.top().second;
        q.pop();
        for(int i=0;i<v[ti].size();i++){
            int c=v[ti][i].second;
            int sim=v[ti][i].first;
            if(dist[sim]>dist[ti]+c){
                dist[sim]=dist[ti]+c;
                q.push({dist[sim],sim});
            }
        }
    }
    if(dist[s]==987654321) cout<<"Impossible";
    else cout<<dist[s];
    return 0;
}
