#include <iostream>
#include <windows.h>
#include <vector>
#include <time.h>
using namespace std;

vector<int> v;
int a[5];
void f(int n, int bit){
    if(n==4){
        for(int i=0;i<3;i++){
            if(v[i]+v[i+1]!=a[i]) return;
        }
        if(v[3]+v[0]!=a[3]) return;
        for(int i=0;i<4;i++){
            cout<<v[i]<<' ';
        }
        cout<<'\n';
        return;
    }
    for(int i=0;i<10;i++){
        if(bit&(1<<i)) continue;
        v.push_back(i);
        f(n+1,bit|(1<<i));
        v.pop_back();
    }
}
int main()
{
    for(int i=0;i<4;i++){
        cin>>a[i];
    }
    srand(time(NULL));
    f(0,0);
    return 0;
}
