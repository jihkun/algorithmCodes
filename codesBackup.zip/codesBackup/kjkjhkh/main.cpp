#include <bits/stdc++.h>

using namespace std;

int main()
{
    FILE* f=fopen("w+","propeors.txt");
    fprintf(f,"u r a idiot");
    fclose(f);
    return 0;
}
