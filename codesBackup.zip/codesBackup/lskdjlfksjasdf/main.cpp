#include <iostream>
#include <climits>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
pair<int,int> man[4100000];
int a[1000001];
pair<int,int> setup(int n, int s, int e){
	if(s==e){
		return man[n]={a[s],s};
	}
	int mid=(s+e)/2;
	pair<int,int> l=setup(n*2,s,mid);
	pair<int,int> r=setup(n*2+1,mid+1,e);
	return man[n]=min(l,r);
}
pair<int,int> qu(int n, int s, int e, int i, int v){
    if (i > e || v < s) return {0,INT_MAX}; // ��û ������ ���� ���� ���̶�� 0 ��ȯ
    if (i <= s && e <= v) return man[n]; // ��û ���� ����� �� ��ȯ
    int mid = (s + e) / 2;
    pair<int,int> l,r;
    l=qu(n * 2, s, mid, i, v); r=qu(n * 2 + 1, mid + 1, e, i, v);
    return min(l,r);
}
int main(int argc, char** argv) {
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	int n,m;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	setup(1,1,n);
	cin>>m;
	for(int i=0;i<m;i++){
        int sub,sub2;
        cin>>sub;
        if(sub!=1){
            pair<int,int> l=qu(1,1,n,1,n);
            cout<<l.second<<'\n';
        }
        cin>>sub2;
        pair<int,int> dat=qu(1,1,n,sub,sub2);
        cout<<dat.second<<' '<<dat.first<<'\n';
	}
	return 0;
}
