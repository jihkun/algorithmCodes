#include <iostream>
#include <cmath>
#include <cstring>
#include <queue>
using namespace std;
int dp[210000][2];
int a[210000];
int b[210000];
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    for(int i=0;i<n;i++){
        cin>>b[i];
    }
    dp[0][0]=1;
    dp[0][1]=1;
    for(int i=1;i<n;i++){
        if(abs(a[i]-a[i-1])<=m) dp[i][0]+=dp[i-1][0];
        if(abs(a[i]-b[i-1])<=m) dp[i][0]+=dp[i-1][1];
        if(abs(b[i]-a[i-1])<=m) dp[i][1]+=dp[i-1][0];
        if(abs(b[i]-b[i-1])<=m) dp[i][1]+=dp[i-1][1];
    }
    cout<<dp[n-1][0]+dp[n-1][1];
    return 0;
}
