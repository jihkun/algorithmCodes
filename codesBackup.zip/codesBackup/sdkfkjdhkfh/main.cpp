#include <iostream>

using namespace std;
int di[]={0,0,-1,1};
int dj[]={1,-1,0,0};
int mem[500][500];
int a[500][500];
int m,n,gma=0;
int dfs(int i, int j){
    if(mem[i][j]!=-1){
        return mem[i][j];
    }
    int ma=0;
    for(int k=0;k<4;k++){
        int ti=i+di[k];
        int tj=j+dj[k];
        if(ti>=0&&ti<n&&tj>=0&&tj<m){
            if(a[i][j]<=a[ti][tj]) ma=max(ma,dfs(ti,tj));
        }
    }
    mem[i][j]=ma+1;
    return mem[i][j];
}
int main()
{
    cin>>n;
    m=n;
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            cin>>a[i][j];
            mem[i][j]=-1;
        }
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            gma=max(gma,dfs(j,i));
        }
    }
    cout<<gma;
    return 0;
}
