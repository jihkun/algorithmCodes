#include <bits/stdc++.h>
using namespace std;
set<pair<int,int> > q;
int f(int i,int j){
    if(j==0) return i;
    return f(j,i%j);
}
int main(){`
    int n,m;
    cin>>n>>m;
    for(int i=n;i<=m;i++){
        for(int j=1;j<=i;j++){
            q.insert({i/f(i,j),j/f(i,j)});
        }
    }
    cout<<q.size();
    return 0;
}
