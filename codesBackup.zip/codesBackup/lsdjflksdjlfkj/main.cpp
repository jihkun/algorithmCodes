#include <iostream>
#include <vector>
using namespace std;
vector<int> v[400010], dat[];
int main()
{
    int n,m,c;
    cin>>n>>m>>c;
    for(int i=1;i<=n;i++){

    }
    return 0;
}
