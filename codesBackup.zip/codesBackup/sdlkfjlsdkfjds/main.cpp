#include <iostream>
#include <algorithm>
#include <vector>
#define int long long int
using namespace std;
vector<pair<int,int> > ts;
vector<int> no;
int p[101000];
int s[100010];
int finder(int n){
    if(p[n]==n) return n;
    return p[n]=finder(p[n]);
}
void mer(int n,int k){
    n=finder(n);
    k=finder(k);
    if(n==k) return;
    if(s[n]>s[k]) swap(n,k);
    p[k]=n;
    s[n]+=s[k];
}
int32_t main()
{
    int n,m,c;
    cin>>n>>m>>c;
    for(int i=0;i<m;i++){
        int sub,sub2;
        cin>>sub>>sub2;
        ts.push_back({sub,sub2});
    }
    for(int i=0;i<c;i++){
        int sub;
        cin>>sub;
        no.push_back(sub-1);
    }
    for(int i=0;i<=n;i++){
        p[i]=i;
        s[i]=1;
    }
    int tmp=0;
    vector<bool> connected(m, false);
    for (int i = 0; i < m; i++) {
        if (find(no.begin(), no.end(), i) == no.end()) {
            mer(ts[i].first, ts[i].second);
            connected[i] = true;
        }
    }
    int cost=0;
    reverse(no.begin(),no.end());
    for(auto i:no){
        int sub=finder(ts[i].first);
        int sub2=finder(ts[i].second);
        if(sub!=sub2){
            cost+=s[sub]*s[sub2];
            mer(sub,sub2);
        }
    }
    cout<<cost;
    return 0;
}
