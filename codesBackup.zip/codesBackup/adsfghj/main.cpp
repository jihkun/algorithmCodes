#include <iostream>
#include <algorithm>
#include <vector>
#include <stack>
#include <map>
using namespace std;

int dp[10000000];
vector<pair<int,int> > vs;
vector<int> v;
vector<int> sarr;

int main()
{
    map<int, int> m;
    int n;
    cin>>n;
    sarr.resize(n);
    int dp_p=0;
    for(int i=0;i<n;i++){
        int sub,sub2;
        cin>>sub>>sub2;
        vs.push_back({sub,sub2});
        m[sub]=sub2;
    }

    for(int i=0; i<n; i++){
        sarr[i] = vs[i].second;
    }

    sort(vs.begin(),vs.end());

    for(int i=0;i<n;i++){
        if(dp_p==0){
            dp[dp_p++]=vs[i].second;
            v.push_back(dp_p-1);
        }
        else{
            if(vs[i].second>dp[dp_p-1]){
                dp[dp_p]=vs[i].second;
                dp_p++;
                v.push_back(dp_p-1);
            }
            else{
                int tmp=lower_bound(dp,dp+dp_p,vs[i].second)-dp;
                dp[tmp]=vs[i].second;
                v.push_back(tmp);
            }
        }
    }

    cout<<n-dp_p<<'\n';

    vector<int> ans(dp_p);
    for(int i=n-1, sa=dp_p-1; i>=0; i--){
        if(v[i] == sa) {
            ans[sa] = vs[i].second;
            sa--;
        }
        if(sa < 0) break;
    }

    for(int i=0; i<dp_p; i++){
        m[ans[i]] = -1;
    }

    for(int i=0; i<n; i++){
        int key = sarr[i];
        if(m[key] != -1) {
            printf("%d \n", m[key]);
        }
    }

    return 0;
}
