#include <bits/stdc++.h>
#define int long long int
using namespace std;
struct point;
struct point{
    int x,y;
    bool operator <(const point &u){
        return u.y==y?u.x>x:u.y>y;
    }
};
point a[100000];
int ccw(const point &f, const point &s, const point &t){
    int tmp=(f.x*s.y+s.x*t.y+t.x*f.y)-(f.y*s.x+s.y*t.x+t.x*f.x);
    return tmp;
}
int dist(const point u, const point v){
    int x=u.x-v.x;
    int y=u.y-v.y;
    return x*x+y*y;
}
bool cmp(const point &u, const point &v){
    int tmp=ccw(a[0],u,v);
    if(tmp==0) return dist(a[0],u)<dist(a[0],v);
    return tmp>0;
}
int s[1000000], top=0;
void push(int x){s[top++]=x;}
int32_t main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>a[i].x>>a[i].y;
    }
    sort(a,a+n);
    sort(a+1,a+n,cmp);
    push(0);
    push(1);
    for(int i=2;i<n;i++){
        while(top>=2&&ccw(a[i],a[s[top-2]],a[s[top-1]])<=0) top--;
        push(i);
    }
    cout<<top;
    return 0;
}
