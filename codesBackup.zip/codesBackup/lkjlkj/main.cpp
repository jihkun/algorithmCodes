#include <bits/stdc++.h>

using namespace std;
bool sort_string(const string &u,const string &v){
    if(u.size()>v.size()){
        return false;
    }else if(u.size()==v.size()){
        return u<v;
    }else if(u.size()<v.size()){
        return true;
    }
}
map<string,bool> dat[20001];
int main()
{
    int n;
    cin>>n;
    string a[n];
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    sort(a,a+n,sort_string);
    for(int i=0;i<n;i++){
        if(a[i]!=a[i-1]) cout<<a[i]<<'\n';

    }
    return 0;
}
