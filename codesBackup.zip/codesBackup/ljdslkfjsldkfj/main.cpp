#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
int read=0;
vector<pair<int,int> > tree(19876);
int a[100000];
pair<int,int> max_finder(pair<int,int> a,pair<int,int> b){
    int max=0,nextmax=0;
    if(max<a.first){nextmax=max; max=a.first;}
    if(max<b.first){nextmax=max; max=b.first;}
    if(max<a.second){nextmax=max; max=a.second;}
    if(max<b.second){nextmax=max; max=b.second;}
    return make_pair(max,nextmax);
}
pair<int,int> setup(int n,int s,int e){
    if(s==e) return tree[n]=make_pair(0,a[s]);
    int mid=(s+e)/2;
    return tree[n]=max_finder(setup(n*2,s,mid),setup(n*2+1,mid+1,e));
}
pair<int,int> query(int n,int s,int e,int l,int r){
    if(l>e||s>r) return make_pair(0,0);
    if(l>=s&&e<=r) return tree[n];
    int mid=(s+e)/2;
    return max_finder(query(n*2,s,mid,l,r),query(n*2+1,mid+1,e,l,r));
}
pair<int,int> update(int n,int s,int e,int i,int v){
    if(i<s||e<i) return tree[n];
    if(s==e) return tree[n]=make_pair(0,v);
    int mid=(s+e)/2;
    return tree[n]=max_finder(update(n*2,s,mid,i,v),update(n*2+1,mid+1,e,i,v));
}
int main()
{
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    int n;
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    setup(1,1,n);
    int m;
    cin>>m;
    for(int i=0;i<m;i++){
        int sub,sub2,sub3;
        cin>>sub>>sub2>>sub3;
        if(sub==1) update(1,1,n,sub2,sub3);
        else{
            pair<int,int> tmp=query(1,1,n,sub2,sub3);
            cout<<tmp.first+tmp.second<<'\n';
        }
    }
    return 0;
}
