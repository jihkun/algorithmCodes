#include <iostream>
#include <vector>
#define INF 1000001
#define ll long long int
using namespace std;
vector<ll> sum(INF*4);
ll a[INF];
ll update(ll n, ll s, ll e, ll i, ll v) {
    if (i < s || i > e) return sum[n];
    if (s == e) {
        return sum[n] = a[i];
    }
    ll mid = (s + e) / 2;
    return sum[n] = update(n * 2, s, mid, i, v) + update(n * 2 + 1, mid + 1, e, i, v);
}

ll fin(ll n, ll s, ll e,ll v){
    if(s==e) return e;
    ll mid=(s+e)/2;
    if(sum[n*2]>=v){
        return fin(n*2,s,mid,v);
    }else{
        return fin(n*2+1,mid+1,e,v-sum[n*2]);
    }
}
int main()
{
    ll n;
    cin>>n;
    for(ll i=0;i<n;i++){
        ll ac;
        cin>>ac;
        if(ac==1){
            ll b;
            cin>>b;
            ll k=fin(1,1,INF,b);
            cout<<k<<'\n';
             a[k]--;
            update(1,1,INF,k,a[k]);
        }else{
            ll b,c;
            cin>>b>>c;
            a[b]+=c;
            update(1,1,INF,b,a[b]+c);
        }
    }
    return 0;
}
