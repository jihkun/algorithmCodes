#include <iostream>

using namespace std;
int default_list[101];
int main()
{
    for(int i=1;i<=100;i++){
        int cnt=0;
        for(int j=1;j<=i;j++) cnt+=j;
        default_list[i+1]=cnt;
    }
    int n,m;
    cin>>n>>m;
    for(int i=m;i<=100;i++){
        if((n-default_list[i])%i==0&&(n-default_list[i])/i>=0){
            for(int j=0;j<i;j++){
                    cout<<(n-default_list[i])/i+j<<' ';
            }
            return 0;
        }else if((n-default_list[i])<0) break;
    }
    cout<<-1;
    return 0;
}
