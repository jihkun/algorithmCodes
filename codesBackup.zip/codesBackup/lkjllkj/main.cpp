#include <iostream>
#define MAX 10^6+1
using namespace std;
int arr[MAX];
int parent_chk(int a){
    if(parent_chk(arr[a])==a) return a;
    else return arr[a]=parent_chk(arr[a]);
}
void func(int a, int b){
    int as=parent_chk(a);
    int bs=parent_chk(b);
    if(as<bs) arr[b]=as;
    else arr[a]=bs;
}
int union_func(int a,int b){
    int as=parent_chk(a);
    int bs=parent_chk(b);
        if(as==bs) return 1;
        else return 0;
}
int main()
{
    int n,m;
    cin>>n>>m;
    while(n--) arr[n]=n;
    for(int i=0;i<m;i++){
        bool sub;
        int sub2,sub3;
        cin>>sub>>sub2>>sub3;
        if(sub&&union_func(sub2,sub3)==1) cout<<"YES\n";
        else if(sub) cout<<"NO\n";
        else func(sub,sub3);

    }

    return 0;
}
