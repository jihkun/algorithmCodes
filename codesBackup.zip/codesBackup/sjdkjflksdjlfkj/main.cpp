#include <iostream>
#include <map>
#include <vector>
using namespace std;

map<int, vector<string>> g;
map<string, long long> co, nh;

int main() {
    long long n, m, c;
    cin >> n >> m >> c;
    for(long long i = 0; i < n; i++) {
        long long sub1, sub3;
        string sub2;
        cin >> sub1 >> sub2 >> sub3;
        g[sub1].push_back(sub2);
        co[sub2] = sub3;
    }
    for(long long i = 0; i < c; i++) {
        string sub2;
        long long sub, sub3;
        cin >> sub;
        if(sub == 1) {
            cin >> sub2 >> sub3;
            if(m >= co[sub2] * sub3) {
                m -= co[sub2] * sub3;
                nh[sub2] += sub3;
            }
        } else if(sub == 2) {
            cin >> sub2 >> sub3;
            m += min(nh[sub2], sub3) * co[sub2];
            nh[sub2] -= min(nh[sub2], sub3);
        } else if(sub == 3) {
            cin >> sub2 >> sub3;
            co[sub2] += sub3;
        } else if(sub == 4) {
            long long sub4;
            cin >> sub3 >> sub4;
            for(auto i : g[sub3]) {
                co[i] += sub4;
            }
        }else if(sub == 5) {
            long long sub4;
            cin >> sub3 >> sub4;
            for(auto i : g[sub3]) {
                long long priceChange = co[i] * sub4 / 100;
                co[i] += (priceChange - (priceChange % 10));
            }
        }else if(sub == 6) {
            cout << m << '\n';
        } else if(sub == 7) {
            long long sum = 0;
            for(auto i : g) {
                for(auto j : i.second) {
                    sum += co[j] * nh[j];
                }
            }
            cout << sum + m << '\n';
        }
    }
    return 0;
}
