#include <iostream>
#include <vector>
#include <cstring>
using namespace std;
int f(int i, vector<int>& a){
    if(a[i]==i) return i;
    return a[i]=f(a[i],a);
}
void mer(int i,int j,vector<int>& a){
    i=f(i,a);
    j=f(j,a);
    if(i>j) a[i]=j;
    else a[j]=i;
}
int main()
{
    int n,m;
    cin>>n>>m;
    while(n!=0&&m!=0){
        vector<int> a(400000,0);
        for(int i=0;i<n;i++){
            a[i]=i;
        }
        for(int i=0;i<m;i++){
            int sub,sub2;
            cin>>sub>>sub2;
            mer(sub,sub2,a);
        }
        int cnt=0;
        bool chk[400001];
        memset(chk,0,sizeof(chk));
        for(int i=1;i<=n;i++){
            if(!chk[a[i]]){
                chk[a[i]]=true;
                cnt++;
            }
        }
        cout<<cnt<<'\n';
        cin>>n>>m;
    }
    return 0;
}
