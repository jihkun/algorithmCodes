#include <iostream>

using namespace std;

int main()
{
    int n,m,dec=0,vec=0;
    cin>>n>>m;
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            int sub;
            cin>>sub;
            if(sub==9) dec++;
            else if(sub>1) vec++;
        }
    }
    cout<<dec<<'\n'<<vec;
    return 0;
}
