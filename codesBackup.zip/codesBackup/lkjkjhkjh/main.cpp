#include <bits/stdc++.h>

using namespace std;
queue<pair<int,int> > q;
bool chk[200005];
int main()
{
    int n,k;
    cin>>n>>k;
    q.push({0,n});
    if(n>k){
        cout<<n-k;
        return 0;
    }
    chk[n]=true;
    while(!q.empty()){
        int fi=q.front().second;
        int ti=-q.front().first;
        if(fi==k){
            cout<<ti;
            return 0;
        }
        q.pop();
        if(fi>=0&&fi*2<=200000&&chk[fi*2]!=true){
            q.push({-(ti),fi*2});
            chk[fi*2]=true;
        }
        if(fi-1>=0&&fi-1<=200000&&chk[fi-1]!=true){
            q.push({-(ti+1),fi-1});
            chk[fi-1]=true;
        }
        if(fi+1<=200000&&fi+1<=200000&&chk[fi+1]!=true){
            q.push({-(ti+1),fi+1});
            chk[fi+1]=true;
        }

    }
    return 0;
}
