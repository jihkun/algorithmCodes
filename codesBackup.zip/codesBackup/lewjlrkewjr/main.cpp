#include <bits/stdc++.h>

using namespace std;

queue<pair<int,int>> q;
int chk[200005];

void trace_back(int k, int n) {
    if(n==k) {
        cout<<n<<' ';
        return;
    }
    if(k-1>=0 && chk[k-1]==chk[k]-1) {
        trace_back(k-1, n);
        cout<<k<<' ';
    } else if(k+1<=200000 && chk[k+1]==chk[k]-1) {
        trace_back(k+1, n);
        cout<<k<<' ';
    } else if(k%2==0 && chk[k/2]==chk[k]-1) {
        trace_back(k/2, n);
        cout<<k<<' ';
    }
}

int main() {
    int n, k;
    cin>>n>>k;
    q.push({0, n});
    if(n>k) {
        cout<<n-k<<endl;
        for(int i=n;i>=k;i--){
            cout<<i<<' ';
        }
        return 0;
    }
    for(int i=0; i<200005; i++) {
        chk[i]=-1;
    }
    chk[n]=0;
    while(!q.empty()) {
        int ti=q.front().first;
        int fi=q.front().second;
        if(fi==k) {
            cout<<ti<<endl;
            trace_back(k, n);
            return 0;
        }
        q.pop();
        if(fi*2<=200000 && chk[fi*2]==-1) {
            q.push({ti+1,fi*2});
            chk[fi*2]=chk[fi]+1;
        }
        if(fi-1>=0 && chk[fi-1]==-1) {
            q.push({ti+1,fi-1});
            chk[fi-1]=chk[fi]+1;
        }
        if(fi+1<=200000 && chk[fi+1]==-1) {
            q.push({ti+1,fi+1});
            chk[fi+1]=chk[fi]+1;
        }
    }
    return 0;
}
