#include <bits/stdc++.h>
using namespace std;

map<int,int> ar;
int main()
{
    long long int r=9223372036854775783,l=2,n,ma=0;
    cin>>n;
    while(l<=r){
        long long int m=(l+r)/2;
        if(m*m<=n){
            ma=max(ma,m);
            l=m;
        }else if(m*m>n){
            r=m;
        }
    }
    cout<<ma;
    return 0;
}
