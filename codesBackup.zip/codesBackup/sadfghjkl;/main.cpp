#include <iostream>
#include <algorithm>
using namespace std;
int arr[1000000];
int tp[100000];
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    sort(arr,arr+n/2);
    sort(arr+n/2+1,arr);
    int f=0,s=n-1;
    int pointer=0;
    int cnt=0;
    while(f<s){
        if(arr[f]>arr[s]){
            if(pointer-f>=0) cnt+=(pointer-f);
            tp[pointer++]=arr[f++];
        }else if(arr[f]<arr[s]){
            if(pointer-s>=0) cnt+=(pointer-s);
            tp[pointer++]=arr[s--];
        }else{
            if(pointer-f>=0) cnt+=(pointer-f);
            tp[pointer++]=arr[f++];
            s--;
        }
    }
    while(f<s){
            if(pointer-s>=0) cnt+=(pointer-s);
            tp[pointer++]=arr[f--];
    }
    cout<<cnt;
    return 0;
}
