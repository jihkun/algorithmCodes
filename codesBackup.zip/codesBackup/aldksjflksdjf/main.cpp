#include <bits/stdc++.h>

using namespace std;
deque<int> d;
int main(){
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        string sub;
        cin>>sub;
        int f=d.front(),b=d.back();
        if(d.empty()){ f=-1; b=-1;}
        int dat;
        if(sub[0]=='p'&&sub[1]=='u'){
                cin>>dat;
                if(sub[5]=='b') d.push_back(dat);
                else d.push_front(dat);
        }
        if(sub=="size") cout<<d.size()<<'\n';
        if(sub=="empty") cout<<d.empty()<<'\n';
        if(sub=="back") cout<<b<<'\n';
        if(sub=="front") cout<<f<<'\n';
        if(sub=="pop_back"){
            cout<<b<<'\n';
            if(b!=-1) d.pop_back();
        }
        if(sub=="pop_front"){
            cout<<f<<'\n';
            if(f!=-1) d.pop_front();
        }
    }
    return 0;
}
