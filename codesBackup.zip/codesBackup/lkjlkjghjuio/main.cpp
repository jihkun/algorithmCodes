#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
int p[10000];
struct edge{
    int d,n1,n2;
};
bool cmp(const edge &u, const edge &v){ return u.d<v.d; }
vector<edge> v;
int fin(int f){
    if(p[f]==f) return f;
    return p[f]=fin(p[f]);
}
void uni(int x, int y){
    int i=fin(x);
    int j=fin(y);
    if(i>j) p[j]=i;
    else p[i]=j;
}
int main()
{
    while(1){
        int n,m,cnt=0;
        cin>>n;
        while(!v.empty()){
            v.pop_back();
        }
        if(n==0) return 0;
        cin>>m;
        for(int i=0;i<=n;i++){
            p[i]=i;
        }
        for(int i=0;i<m;i++){
            int sub,sub2,sub3;
            cin>>sub>>sub2>>sub3;
            v.push_back({sub3,sub,sub2});
        }
        sort(v.begin(),v.end(),cmp);
        for(int i=0;i<m;i++){
            int il=fin(v[i].n1);
            int jl=fin(v[i].n2);
            if(il==jl){
                continue;
            }
            cnt+=v[i].d;
            uni(v[i].n1,v[i].n2);
        }
        cout<<cnt;
    }
    return 0;
}
