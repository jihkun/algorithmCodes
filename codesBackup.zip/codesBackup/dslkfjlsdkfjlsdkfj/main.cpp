#include <iostream>
#define imsub '_'
#include <math.h>
#include <cmath>
#include <vector>
#include <cstring>
using namespace std;
vector<int> v[10000];
bool visited[10000];
int a[10000];
int k;
bool dfs(int i){
    for(int k=0;k<v[i].size();k++){
        int di=v[i][k];
        if(visited[di]) continue;
        else visited[di]=true;
        if(a[di]==0||dfs(a[di])){
            a[di]=i;
            return true;
        }
    }
    return false;
}
int main()
{
    int n,m;
    cin>>n>>m>>k;
    for(int i=1;i<=n;i++){
        int ar;
        cin>>ar;
        while(ar--){
            int ar2;
            cin>>ar2;
            v[i].push_back(ar2);
        }
    }
    int cnt=0;
    for(int i=1;i<=n;i++){
            memset(visited, 0, sizeof(visited));
            if(dfs(i)) cnt++;
    }
    for(int i=1;i<=n&&k>0;i++){
        while(k){
            memset(visited, 0, sizeof(visited));
            if(!dfs(i)) break;
            k--; cnt++;
        }
    }
    cout<<cnt;
    return 0;
}
