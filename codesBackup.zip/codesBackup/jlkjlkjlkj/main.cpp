#include <iostream>
#include <map>
#define ll long long int
using namespace std;
int opo[100000];
ll arr[400001]; // ����: long long int Ÿ������ ����
ll update(int n,int s,int e,int t){
    if(t<s||e<t) return arr[n];
    if(s==e) return ++arr[n]; // ����: ���� ������Ų �� ��ȯ
    int mid=(s+e)/2;
    return arr[n]=update(n*2,s,mid,t)+update(n*2+1,mid+1,e,t);
}
ll query(int n,int s,int e,int l,int r){
    if(e<l||r<s) return 0;
    if(l<=s&&e<=r) return arr[n];
    int mid=(s+e)/2;
    return query(n*2,s,mid,l,r)+query(n*2+1,mid+1,e,l,r);
}
int main()
{
    int n;
    cin>>n;
    map<int,int> tmp;
    for(int i=0;i<n;i++){
        int sub;
        cin>>sub;
        tmp[sub]=i;
    }
    for(int i=0;i<n;i++){
        int sub;
        cin>>sub;
        opo[tmp[sub]]=i;
    }
    ll cnt=0; // ����: long long int Ÿ������ ����
    for(int i=0;i<n;i++){
        int p=opo[i];
        cnt+=query(1,1,n,p+1,n);
        update(1,1,n,p);
    }
    cout<<cnt;
    return 0;
}
