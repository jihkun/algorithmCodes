#include <iostream>

using namespace std;
int p[10000];
void f(int n){
    if(n>16) return;
    f(n*2);
    f(n*2+1);
    cout<<p[n]<<' ';
}
int main()
{
    for(int i=1;i<=16;i++){
        p[i]=i;
    }
    f(1);
    return 0;
}
