#include <iostream>
#include <vector>
#include <cstring>
#include <tuple>
#include <queue>
#include <limits>
using namespace std;
int dist[1100][1100];
vector<pair<int,int> > v[1100];
int sum;
int main()
{
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    fill(&dist[0][0],&dist[1001][1001],1<<30-1);
    int n,m,c,s,e;
    cin>>n>>m>>c>>s>>e;
    for(int i=0;i<m;i++){
        int sub,sub2,sub3;
        cin>>sub>>sub2>>sub3;
        v[sub].push_back({sub2,sub3});
        v[sub2].push_back({sub,sub3});
    }
    priority_queue<tuple<int,int,int>,vector<tuple<int,int,int> >,greater<tuple<int,int,int>>> q;
    q.push({0,0,s});
    dist[s][0]=0;
    while(!q.empty()){
        int tc=get<0>(q.top());
        int ti=get<2>(q.top());
        int tt=get<1>(q.top());
        q.pop();
        if(tt>=n) continue;
        if(dist[ti][tt]<tc) continue;
        for(int i=0;i<v[ti].size();i++){
            int ni=v[ti][i].first;
            int nc=v[ti][i].second;
            if(dist[ni][tt+1]>tc+nc){
                dist[ni][tt+1]=tc+nc;
                q.push({dist[ni][tt+1],tt+1,ni});
            }
        }
    }
    int sub=0;
    for(int i=0;i<c+1;i++){
        int tmp=987654321;
        sum+=sub;
        for(int i=1;i<n;i++){
            tmp=min(dist[e][i]+sum*i,tmp);
        }
        cout<<tmp<<'\n';
        if(i!=c) cin>>sub;
    }
    return 0;
}
