#include <iostream>
#include <algorithm>
#include <numeric>
#include <vector>
using namespace std;
int a[100000];
int main()
{
    int n,m;
    cin>>m>>n;
    for(int i=0;i<n;i++){
            cin>>a[i];
    }
    int cnt=0;
    sort(a,a+n,greater<int>());
    for(int i=0;i<n;i++){
        int sum=0;
        if(a[i]==-1) continue;
        sum+=a[i];
        for(int j=i+1;j<n;j++){
            if(a[j]==-1) continue;
            if(sum+a[j]<=m){
                sum+=a[j];
                a[j]=-1;
            }
        }
        cnt++;
    }
    cout<<cnt;
    return 0;
}
