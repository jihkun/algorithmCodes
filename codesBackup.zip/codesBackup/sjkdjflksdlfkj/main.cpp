#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
vector<int> a;
int n,k;
int backtrack(int bit, int na, int ka){
    int ans=0;
    if(ka==k-5){
        for(int i=0;i<n;i++){
            if((a[i]&bit)==a[i]) ans++;
        }
        return ans;
    }
    for(int i=na;i<26;i++){
        if((1<<i)&bit) continue;
        ans=max(ans,backtrack(bit|(1<<i),i+1,ka+1));

    }
    return ans;
}
int main()
{
    cin>>n>>k;
    for(int i=0;i<n;i++){
        string sub;
        cin>>sub;
        int subbit=0;
        for(int i=0;i<sub.size();i++){
            subbit|=(1<<(sub[i]-'a'));
        }
        a.push_back(subbit);
    }
    int tembit=0;
    tembit|=(1<<('a'-'a'));
    tembit|=(1<<('t'-'a'));
    tembit|=(1<<('i'-'a'));
    tembit|=(1<<('c'-'a'));
    tembit|=(1<<('n'-'a'));
    cout<<backtrack(tembit,0,0);
    return 0;
}
