#include <iostream>
#include <vector>
#define int long long int
#define INT_MIN LONG_MIN
#define INT_MAX LONG_MAX
#include <climits>
using namespace std;
struct edge{
   int f,s,t;
};

vector<edge> v;
int tp[100000];
int dist[10000];
int32_t main()
{
    fill(&dist[0],&dist[9999],INT_MIN);
    int n,m,c,k;
    cin>>n>>m>>c>>k;
    for(int i=0;i<k;i++){
        int sub,sub2,sub3;
        cin>>sub>>sub2>>sub3;
        v.push_back({sub,sub2,sub3});
    }
    for(int i=0;i<n;i++){
        cin>>tp[i];
    }
    dist[m]=tp[m];
    for(int i=0;i<n+50;i++){
        for(int j=0;j<k;j++){
            edge tmp=v[j];
            if(dist[tmp.f]==INT_MIN) continue;
            else if(dist[tmp.f]==INT_MAX) dist[tmp.s]=INT_MAX;
            else if(dist[tmp.s]<dist[tmp.f]+tp[tmp.s]-tmp.t){
                dist[tmp.s]=dist[tmp.f]+tp[tmp.s]-tmp.t;
                if(i>n-1) dist[tmp.s]=INT_MAX;
            }
        }
    }
    if(dist[c]==INT_MIN) cout<<"gg";
    else if(dist[c]==INT_MAX) cout<<"Gee";
    else cout<<dist[c];
    return 0;
}
