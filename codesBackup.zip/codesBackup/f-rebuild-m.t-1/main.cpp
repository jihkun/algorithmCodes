#include <bits/stdc++.h>
#include <string>
FILE* ld=fopen("logdat.library","a+");
int dev_enable;
#include <windows.h>
#include <conio.h>
#include <cstdlib>
using namespace std;
#include "specchk.h"
#include "form.h"
#include "var.h"
#include "header01.h"
#include "headerverchk.h"
#include "oggamain.h"
string gameluncherver="fast_alpha_1";

void verchk(){
    cout<<"\n\n\n\n\n\n\n\n\n\n";
    head01chk(1);
    cout<<"game luncher ver : "<<gameluncherver<<"\n";
    return;
}
int main()
{

    fprintf(ld,"\n\n\nld on time : %lld\n",time(NULL));
    system("mode con cols=130 lines=15 | title �����ΰ��� : code:0001");
    fprintf(ld,"specchk start\n");
    fprintf(ld,"specchk end with code %d\n", s_b(0));
    system("mode con cols=130 lines=15 | title �����ΰ��� : chk");
    fprintf(ld,"header chk start\n");
    fprintf(ld,"headerchk end with code %d\n",blunchchk());
    system("mode con cols=125 lines=20 | title �����ΰ��� : chk done!");
    fprintf(ld,"wait 1sec.....");
    Sleep(1000);
    system("mode con cols=125 lines=20 | title �����ΰ���");//���
    fprintf(ld,"start!\n");
    opening();
    menu();
    bgm_on=0;
    if(pointer==1){
            verchk();
            fprintf(ld,"\n\n\nld off time : %lld\n\n\n",time(NULL));
            fclose(ld);
            return 0;
    }
    if(pointer==2) return 0;
    if(pointer==10) quiz();
    clean();
    people=select_();
    setting_mugung();
    mg_main();
    fprintf(ld,"\n\n\nld off time : %lld\n\n\n",time(NULL));
    fclose(ld);
    return 0;
}
