//include line

#include "specchk.h"
#include "header01.h"
#include "headerverchk.h"

//var & class


// var

int game_board[25][25];
int people;

//class

class user{
private:
    string name;
    int x,y;

public:
    bool die;
    void name_push(string subname){
        name=subname;
    }
    void xy_setting(int i,int j){
        x=i;
        y=j;
    }
    int direction(int siq,int xd,int yd){
        if(game_board[x][y]==siq){
            game_board[x][y]=0;
            game_board[x+xd][y+yd]=siq;
            x+=xd;
            y+=yd;
            return 0;
        }else{
            return 1;
        }
    }
};
user user_data[51];
