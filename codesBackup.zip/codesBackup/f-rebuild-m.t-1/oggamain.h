int cnt,pi=0,killpeoplecnt=0;
//int game(){
//
//}

void reoutput_game(){
    clean();
    fprintf(ld,"time : %lld reoutput\n",time(NULL));
    for(int i=0;i<25;i++){
        for(int j=0;j<25;j++){
            cout<<game_board[i][j]<<' ';
        }
        cout<<'\n';
    }
}
void setting_mugung(){
    for(int i=0;i<25;i++){
        for(int j=0;j<25;j++){
            game_board[i][j]=0;
        }
    }
    for(int i=1;i<=people;i++){
        game_board[i][0]=i;
    }
}
string mugungwha="Mugunghwa has bloomed";
int mugungwhaint=0;
void timer_thread(){
    fprintf(ld,"time : %lld time start!\n",time(NULL));
    srand(time(NULL));
    while(1){
    if(rand()%40==1){
            mugungwhaint++;
            clean();
            reoutput_game();
            for(int i=0;i<mugungwhaint;i++){
            cout<<mugungwha[i];
            }
            if(mugungwhaint>=mugungwha.size()){
                cnt=1;
                fprintf(ld,"time : %lld time end\n",time(NULL));
                return;
            }

    }
    Sleep(1);
    }
}
void mugungwhagame(){
    system("mode con cols=50 lines=30 | title ¿ÀÁö¹Î°ÔÀÓ : in_game");
    while(!cnt){
        for(pi=1;pi<=people;pi++){
            if(cnt==1) return;
            if(user_data[pi].die==true) continue;
            clean();
            reoutput_game();
            int ojimingame1=getch();
            if(ojimingame1==97) user_data[pi].direction(pi,-1,0);
            if(ojimingame1==100) user_data[pi].direction(pi,1,0);
            if(ojimingame1==115) user_data[pi].direction(pi,0,-1);
            if(ojimingame1==119) user_data[pi].direction(pi,0,1);
        }
    }
}
void mg_main(){
    if(people<killpeoplecnt-2){
            fprintf(ld,"time : %lld game end\n",time(NULL));
            people=killpeoplecnt/2;
            cout<<killpeoplecnt/2<<"만큼 살아남음.\n";
            cout<<"계속하기 위하여 아무 키나 입력";
            kbhit();
            return;
    }
    cnt=0;
    mugungwhaint=0;
    thread m(mugungwhagame);
    thread timer(timer_thread);
    while(cnt!=0);
    m.join();
    timer.join();
    user_data[pi].die=true;
    cout<<'\n'<<pi;
    fprintf(ld,"time : %lld somene dead",time(NULL));
    string_output("has been die\n");
    string_output("press any button to play continue");
    killpeoplecnt++;
    kbhit();
    clean();
    mg_main();
}

