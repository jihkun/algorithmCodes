

random_device rd;
mt19937 gen(rd());
uniform_int_distribution<int> dis(0, 1);
int a[30][30];
void string_output(string a){
    for(int i=0;i<a.size();i++){
        cout<<a[i];
        _sleep(100);
    }
}
struct player{
    int j,die;
    int x=0,y=0;
    string name;
};
int leggendpeople;
player data[31];
void enter(){
    system("cls");
}
void game_output(){
    for(int i=0;i<30;i++){
            for(int j=0;j<30;j++){
                cout<<' '<<a[i][j];
            }
            cout<<"\n";
        }
}
void setting_game(){
    for(int i=0;i<30;i++){
        for(int j=0;j<30;j++){
            a[i][j]=0;
        }
    }
    for(int i=1;i<=leggendpeople;i++){
        data[i].x=i;
        a[i][0]=i+1;
    }
}
int game_1(int order,int round){
    if(leggendpeople<order){
        round++;
        game_1(1,round);
        return 0;
    }
    int snt=0;
    for(int i=0;i<leggendpeople;i++){
        if(a[data[order].x][data[order].y]!=order+1) snt++;
    }
    if(snt==leggendpeople-1){
        for(int i=0;i<leggendpeople;i++){
        if(a[data[order].x][data[order].y]==order+1) cout<<order<<"is winner.";
    }
    return 0;
    }
    if(order==1){
        cout<<round<<"번째 라운드\n";
    }
    if(a[data[order].x][data[order].y]==order+1){
    game_output();
    cout<<"문제로 인해 자신의 번+1이 자신의 말입니다.\n";
    cout<<data[order].name<<"의 턴";
    getch();
    enter();
    if(round==1){
    cout<<"당신은 a로 왼쪽\ns로 아래로\nd로 오른쪽으로\nw로 위쪽으로 움직일수 있습니다.";
    getch();
    cout<<"또한 x로 자신의 뒤에 블록을 설치할수 있습니다.";
    getch();
    enter();
    }
    cout<<"이동방향을 눌러 주시오. : ";
    int player_y_direction=data[order].y;
    int player_x_direction=data[order].x;
    int movement=getch();
    if(movement==65||movement==97){
        if(player_y_direction>=0&&player_y_direction<30&&player_x_direction-1>=0&&player_x_direction-1<30){
            if(a[player_x_direction-1][player_y_direction]!=1){
                a[player_x_direction][player_y_direction]=0;
                a[player_x_direction-1][player_y_direction]=order+1;
                player_x_direction--;
            }
        }
    if(movement==68||movement==100){
        if(player_y_direction>=0&&player_y_direction<30&&player_x_direction+1>=0&&player_x_direction+1<30){
            if(a[player_x_direction+1][player_y_direction]!=1){
                a[player_x_direction][player_y_direction]=0;
                a[player_x_direction+1][player_y_direction]=order+1;
                player_x_direction++;
            }
        }

    }
    if(movement==83||movement==115){
        if(player_y_direction-1>=0&&player_y_direction-1<30&&player_x_direction>=0&&player_x_direction<30){
            if(a[player_x_direction][player_y_direction-1]!=1){
                a[player_x_direction][player_y_direction]=0;
                a[player_x_direction][player_y_direction-1]=order+1;
                player_y_direction--;
                cout<<a[player_x_direction][player_y_direction]<<' ';
            }
        }
    }
    if(movement==87||movement==119){
        if(player_y_direction+1>=0&&player_y_direction+1<30&&player_x_direction>=0&&player_x_direction<30){
            if(a[player_x_direction][player_y_direction+1]!=1){
                a[player_x_direction][player_y_direction]=0;
                a[player_x_direction][player_y_direction+1]=order+1;
                player_y_direction++;
            }
        }
        if(movement==88||movement==120){
            a[player_x_direction][player_y_direction-1]=1;
        }
    }else{
        cout<<data[order].name<<"의 턴\n";
        cout<<"하지만 그는 죽었습니다.";
        getch();
        enter();
    }
}

    }
    game_1(order+1,round);
}
int leggend()
{
    cout<<"게임에 참여하시겠습니까? : ";
    string name;
    cin>>name;
    if(name=="y"){
        getch();
        enter();
        cout<<"몇명이서 하실 겁니까 : ";
        scanf("%d",&leggendpeople);
        for(int i=1;i<=leggendpeople;i++){
            cout<<i<<"번째 사람이름 : ";
            cin>>data[i].name;
        }
         cout<<"게임 : ";
        string_output("무궁화 꽃이 피었습니다");
        cout<<"\n잠시 기다려 주십시오";
        setting_game();
        enter();
        game_1(1,1);

    }



    return 0;
}
