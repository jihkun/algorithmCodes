#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
int p[10000];
struct edge{
    int d,n1,n2;
};
bool cmp(const edge &u, const edge &v){ return u.d<v.d; }
vector<edge> v;
int fin(int f){
    if(p[f]==f) return f;
    return p[f]=fin(p[f]);
}
void uni(int x, int y){
    int i=fin(x);
    int j=fin(y);
    if(i>j) p[j]=i;
    else p[i]=j;
}
int main()
{
    int n,cnt=0;
    cin>>n;
    for(int i=0;i<=n;i++){
        p[i]=i;
    }
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            int sub;
            cin>>sub;
            v.push_back({sub,i,j});
        }
    }
    sort(v.begin(),v.end(),cmp);
    int siz=v.size();
    for(int i=0;i<siz;i++){
        int il=fin(v[i].n1);
        int jl=fin(v[i].n2);
        if(il==jl){
            continue;
        }
        cnt+=v[i].d;
        uni(v[i].n1,v[i].n2);
    }
    cout<<cnt;
    return 0;
}
