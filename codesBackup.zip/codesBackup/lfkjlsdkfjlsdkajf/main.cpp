#include <bits/stdc++.h>
using namespace std;
bool dat[21];
int main()
{
    ios_base::sync_with_stdio(false); cin.tie(0);cout.tie(0);
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        string a;
        cin>>a;
        int sub;
        if(a!="all"&&a!="empty") cin>>sub;
        if(a=="add"){
            dat[sub]=1;
        }else if(a=="remove"){
            dat[sub]=0;
        }else if(a=="check"){
            cout<<dat[sub];
        }else if(a=="toggle"){
            dat[sub]=!dat[sub];
        }else if(a=="all"){
            for(int j=1;j<=20;j++){
                dat[j]=1;
            }
        }else if(a=="empty"){
            for(int j=1;j<=20;j++){
                dat[j]=0;
            }
        }
    }
    return 0;
}
