#include <bits/stdc++.h>

using namespace std;
int a[100000];
int n,m;
vector<int> buffer;
void f(int re, int tu){
    if(tu==m){
        for(auto i:buffer){
            cout<<i<<' ';
        }
        cout<<'\n';
    }else{
    for(int i=re;i<n;i++){
        buffer.push_back(a[i]);
        f(i+1,tu+1);
        buffer.pop_back();
    }
    }
}
int main()
{
    cin>>n>>m;
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    sort(a,a+n);
    f(0,0);
    return 0;
}
