#include <bits/stdc++.h>
using namespace std;

int chk[111];
int arr[111];
int n,m,t,res,s;

int main()
{
    scanf("%d %d %d %d",&n,&m,&s,&t);
    for(int i=0;i<n;i++)scanf("%d",&arr[i]);
    for(int i=0;i<s;i++)
    {
        int ia=0;
        for(int i=0;i<m;i++)
        {
            int a;
            scanf("%d",&a);
            ia+=arr[a-1];
        }
        ia+=5*(m+1);
        if(ia<=t)res++;
    }
    printf("%d",res);

    return 0;
}
