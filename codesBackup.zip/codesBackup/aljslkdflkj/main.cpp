#include <iostream>
#include <map>
#define MAX 1101
using namespace std;
bool sosu[MAX];
int a[MAX];
int main()
{
    sosu[1]=true;
    for(int i=2;i<MAX;i++){
        if(sosu[i]==true) continue;
        for(int j=i;MAX>j*j;j++){
            sosu[j]=true;
        }
    }
    int n,m;
    cin>>n>>m;
    for(int i=0;i<n;i++){}
    return 0;
}
