#include <bits/stdc++.h>
#include <windows.h>
using namespace std;
string a[1000];
bool chk[1000][1000];
int di[]={0,0,1,-1},dj[]={1,-1,0,0};
int n;
void dfs(int i, int j, char co){
    chk[i][j]=true;
    for(int k=0;k<4;k++){
        int ni=i+di[k];
        int nj=j+dj[k];
        if(ni>=0&&ni<n&&nj>=0&&nj<n){
            if(chk[ni][nj]==false&&a[ni][nj]==co){
                chk[ni][nj]=true;
                if(co=='R') a[ni][nj]='G';
                dfs(ni,nj,co);
            }
        }
    }
}
int main() {
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
    int cnt=0;
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            if(chk[i][j]==false){
                dfs(i,j,a[i][j]);
                cnt++;
            }
        }
    }
    cout<<cnt<<' ';
    cnt=0;
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            chk[i][j]=false;
        }
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            if(chk[i][j]==false){
                dfs(i,j,a[i][j]);
                cnt++;
            }
        }
    }
    cout<<cnt;
    return 0;
}
