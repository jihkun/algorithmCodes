#include <iostream>
#include <cmath>
#include <vector>

using namespace std;

// ���׸�Ʈ Ʈ�� �ʱ�ȭ
void initSegmentTree(vector<long long> &elements, vector<long long> &segmentTree, int node, int start, int end) {
    if (start == end) {
        segmentTree[node] = elements[start];
    } else {
        int mid = (start + end) / 2;
        initSegmentTree(elements, segmentTree, node * 2, start, mid);
        initSegmentTree(elements, segmentTree, node * 2 + 1, mid + 1, end);
        segmentTree[node] = segmentTree[node * 2] + segmentTree[node * 2 + 1];
    }
}

// ������ ���� ������Ʈ
void updateLazy(vector<long long> &segmentTree, vector<long long> &lazy, int node, int start, int end) {
    if (lazy[node] != 0) {
        segmentTree[node] += (end - start + 1) * lazy[node];
        if (start != end) {
            lazy[node * 2] += lazy[node];
            lazy[node * 2 + 1] += lazy[node];
        }
        lazy[node] = 0;
    }
}

// ���� ������Ʈ
void updateRange(vector<long long> &segmentTree, vector<long long> &lazy, int node, int start, int end, int left, int right, long long diff) {
    updateLazy(segmentTree, lazy, node, start, end);
    if (left > end || right < start) {
        return;
    }
    if (left <= start && end <= right) {
        segmentTree[node] += (end - start + 1) * diff;
        if (start != end) {
            lazy[node * 2] += diff;
            lazy[node * 2 + 1] += diff;
        }
        return;
    }
    int mid = (start + end) / 2;
    updateRange(segmentTree, lazy, node * 2, start, mid, left, right, diff);
    updateRange(segmentTree, lazy, node * 2 + 1, mid + 1, end, left, right, diff);
    segmentTree[node] = segmentTree[node * 2] + segmentTree[node * 2 + 1];
}

// ���� ó��
long long query(vector<long long> &segmentTree, vector<long long> &lazy, int node, int start, int end, int left, int right) {
    updateLazy(segmentTree, lazy, node, start, end);
    if (left > end || right < start) {
        return 0;
    }
    if (left <= start && end <= right) {
        return segmentTree[node];
    }
    int mid = (start + end) / 2;
    long long leftSum = query(segmentTree, lazy, node * 2, start, mid, left, right);
    long long rightSum = query(segmentTree, lazy, node * 2 + 1, mid + 1, end, left, right);
    return leftSum + rightSum;
}

// ���� �Լ�
int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m, k;
    cin >> n >> m >> k;

    vector<long long> elements(n);
    int height = static_cast<int>(ceil(log2(n)));
    int treeSize = (1 << (height + 1));

    vector<long long> segmentTree(treeSize);
    vector<long long> lazy(treeSize, 0);

    for (int i = 0; i < n; i++) {
        cin >> elements[i];
    }

    initSegmentTree(elements, segmentTree, 1, 0, n - 1);

    for (int i = 0; i < m + k; i++) {
        int operation;
        cin >> operation;

        if (operation == 1) {
            int left, right;
            long long diff;
            cin >> left >> right >> diff;
            updateRange(segmentTree, lazy, 1, 0, n - 1, left - 1, right - 1, diff);
        } else if (operation == 2) {
            int left, right;
            cin >> left >> right;
            cout << query(segmentTree, lazy, 1, 0, n - 1, left - 1, right - 1) << '\n';
        }
    }

    return 0;
}
