#include <bits/stdc++.h>

using namespace std;
int dp[10001];
vector<pair<int,int> > a;
int main()
{
    int n,ma=0;
    cin>>n;
    for(int i=0;i<n;i++){
        int sub,sub2;
        cin>>sub>>sub2;
        a.push_back({sub,sub2});
    }
    sort(a.begin(),a.end());
    for(int i=0;i<n;i++){
        dp[i]=1;
        for(int j=0;j<i;j++){
            if(a[j].second<a[i].second){
                dp[i]=max(dp[j]+1,dp[i]);
            }
        }
        ma=max(dp[i],ma);
    }
    cout<<n-ma;
    return 0;
}
