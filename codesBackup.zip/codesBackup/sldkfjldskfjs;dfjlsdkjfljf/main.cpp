#include <iostream>

using namespace std;
int a[100000];
vector<int> sum[400000];
int setup(int n,int s,int e){
    if(s==e) return sum[n]=a[s];
    int mid=(s+e)/2;
    return sum[n]=setup(n*2,s,mid)+setup(n*2+1,mid+1,e);
}
int qu(int n,int s,int e,int l,int r,int v){

}
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>a[i];
    }

    return 0;
}
