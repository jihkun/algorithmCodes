#include <stdio.h>
#include <stdlib.h>

int main()
{
    char a[100];
    scanf("%s",&a);
    for(int i=0;a[i]!='\0';i++){
        printf("%c",a[i]);
        if(a[i+1]!='\0') printf(" to the ");
    }
    return 0;
}
