#include <iostream>

using namespace std;
int n,lll, n2;
void f(int cnt,int people,int cant){
    if(cnt==n){
        if(people==n2){ lll++;}
        return;
    }if(cnt>n) return;
    if(cant==1){
            f(cnt+1,people,0);
    }else{
    for(int i=0;i<=1;i++){
        f(cnt+1,people+i,i);
    }
    }
}

int main()
{
    cin>>n>>n2;
    f(0,0,0);
    cout<<lll;
    return 0;
}
