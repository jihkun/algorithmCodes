#include <iostream>
#define MAX 100000
#include <queue>
using namespace std;
queue<int> q;
int chk[100000];
int main()
{
    int n;
    cin>>n;
    q.push(0);
    int dat[]={1,7,20};
    while(!q.empty()){
        int sub=q.front();
        q.pop();
        for(int i=0;i<3;i++){
            if(sub-dat[i]>=0){
                if(chk[sub-dat[i]]==0){ chk[sub-dat[i]]=chk[sub]+1;q.push(sub-dat[i]);}
            }
            if(sub+dat[i]<100000){
                if(chk[sub+dat[i]]==0){ chk[sub+dat[i]]=chk[sub]+1;q.push(sub+dat[i]);}
            }
        }
    }
    cout<<chk[n];
    return 0;
}
