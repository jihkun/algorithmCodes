#include <iostream>
#include <cstring>
#include <set>
using namespace std;
int arr[26][1000000];
bool chk[1000000];
string dat[4];
string max_ele="";
int num=2,point=0,m=0;
int id(int num){
    switch(num){
    case 1:
    case 2:
        return 0;
        break;
    case 3:
    case 4:
        return 1;
        break;
    case 5:
        return 2;
        break;
    case 6:
        return 3;
        break;
    case 7:
        return 5;
        break;
    case 8:
        return 11;
        break;
    }
    return 0;
}
void ins(string a){
    int sub=0;
    for(auto i:a){
        if(arr[i-'A'][sub]==-1){
            arr[i-'A'][sub]=num++;
        }
        sub=arr[i-'A'][sub];
    }
    chk[sub]=true;
}
bool fin(string a){
    int sub=0;
    for(auto i:a){
        if(arr[i-'A'][sub]==-1){
            return false;
        }
        sub=arr[i-'A'][sub];
    }
    return chk[sub];
}
bool dchk[5][5];
set<string> ans;
int di[]={0,0,1,-1,1,1,-1,-1};
int dj[]={1,-1,0,0,1,-1,1,-1};
void dfs(int i,int j,string args,int len){
    if(fin(args)){
        if(ans.find(args)==ans.end()){
            ans.insert(args);
            point+=id(args.length());
            m++;
            if(args.length()>max_ele.length()){
                max_ele=args;
            }else if(args.length()==max_ele.length()){
                max_ele=min(max_ele,args);
            }
        }
    }
    if(len>=8) return;
    for(int k=0;k<8;k++){
        int ni=i+di[k];
        int nj=j+dj[k];
        if(ni>=0&&ni<4&&nj>=0&&nj<4){
            if(dchk[ni][nj]==false){
                dchk[ni][nj]=true;
                dfs(ni,nj,args+dat[ni][nj],len+1);
                dchk[ni][nj]=false;
            }
        }
    }
}
int main() {
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    int w, b;
    cin >> w;

    // 'arr' �迭�� -1�� �ʱ�ȭ
    memset(arr, -1, sizeof(arr)); // 'arr'�� ���� �ʱ�ȭ �߰�

    for(int i = 0; i < w; i++) {
        string a;
        cin >> a;
        ins(a);
    }

    cin >> b;
    for(int i = 0; i < b; i++) {
        for(int j = 0; j < 4; j++) {
            cin >> dat[j];
        }
        ans.clear();
        memset(dchk,false,sizeof(dchk));
        for(int j = 0; j < 4; j++) {
            for(int k = 0; k < 4; k++) {
                dchk[j][k]=true;
                dfs(j, k, "",0);
                dchk[j][k]=false;
            }
        }
        cout << point << ' ' << max_ele << ' ' << m << '\n';
        max_ele = "";
        point = 0;
        m = 0;
    }
    return 0;
}
