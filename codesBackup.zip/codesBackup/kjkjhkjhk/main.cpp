#include <iostream>

using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--){
        int n,nb;
        cin>>n;
        nb=n;
        int chk[100001]={0};
        while(n--){
            int sub;
            cin>>sub;
            chk[sub]++;
        }
        n=nb;
        int i;
        for(i=1;i<=100000;i++){
            if(chk[i]>=n/2+n%2){
                    cout<<i<<'\n';
                    break;
            }
        }
            if(i==100001) cout<<"SYJKGW\n";
    }
    return 0;
}
