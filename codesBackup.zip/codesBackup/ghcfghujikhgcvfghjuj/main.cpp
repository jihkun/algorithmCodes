#include <iostream>

using namespace std;
double ccw(double x1, double x2, double x3, double y1, double y2, double y3){
    double cnt=x1*y2+x2*y3+x3*y1;
    cnt+=-(y1*x2+y2*x3+y3*x1);
    return cnt;
}
int main()
{
    int n;
    vector<pair<double,double> > v;
    for(int i=0;i<n;i++){
        cin>>v[i].first>>v[i].second;
    }
    double cnt=0;
    for(int i=1;i<n;i++){
        cnt+=ccw(v[0].first,v[i].first,v[i-1].first,v[0].second,v[i].second,v[i-1].second);
    }
    printf("%.1f", cnt);
    return 0;
}
