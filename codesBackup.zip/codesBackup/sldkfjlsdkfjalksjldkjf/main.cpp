#include <iostream>

using namespace std;
int a[100000];
int main()
{
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    int n;
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    int m;
    cin>>m;
    for(int i=0;i<m;i++){
        int sub,sub2,sub3,sub4;
        cin>>sub;
        long long int cnt=0;
        if(sub==1){
            cin>>sub2>>sub3>>sub4;
            for(int j=sub2;j<=sub3;j++){
                if(a[j]==sub4){
                    cnt++;
                }
            }
            cout<<cnt<<'\n';
        }else{
            cin>>sub2>>sub3;
            for(int j=sub2;j<=sub3;j++){
                a[j]=0;
            }
        }
    }
    return 0;
}
