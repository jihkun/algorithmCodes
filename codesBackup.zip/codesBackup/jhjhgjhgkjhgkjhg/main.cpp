#include <bits/stdc++.h>
using namespace std;
int da[1001];
int main()
{
    int n,cnt=0,wait=0;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>da[i];
    }
    sort(da,da+n);
    for(int i=0;i<n;i++){
        wait+=da[i];
        cnt+=wait;
    }
    cout<<cnt;
    return 0;
}
