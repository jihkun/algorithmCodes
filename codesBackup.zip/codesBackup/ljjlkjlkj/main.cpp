#include <bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin>>t;
    while(t--){
        vector<pair<int,int> > v[1010];
        int dist[1011];
        int dat[1011];
        int time_table[1101];
        priority_queue<pair<int,int> > q;
        int n,m;
        cin>>n>>m;
        for(int i=1;i<=n;i++){
            cin>>dat[i];
        }
        for(int i=1;i<=m;i++){
            int sub,sub2;
            cin>>sub>>sub2;
            dist[sub2]++;
            v[sub].push_back({sub2,dat[sub2]});
        }
        int stp=0;
        cin>>stp;
        for(int i=1;i<=n;i++){
            if(dist[i]==0){
                q.push({-dat[i],i});
            time_table[i]=dat[i];
            }
        }
        while(!q.empty()){
            int di=q.top().second;
            q.pop();
            for(int i=0;i<v[di].size();i++){
                int ni=v[di][i].first;
                if(dist[ni]!=-1){
                    dist[ni]--;
                    if(dist[ni]==0){
                        time_table[ni]=time_table[di]+dat[ni];
                        q.push({-time_table[ni],ni});
                    }
                }
            }
        }
        cout<<time_table[stp]<<'\n';
    }
    return 0;
}
