#include <bits/stdc++.h>
using namespace std;
map<int,string> m{
    {4,"mouse"},{5,"cow"},{6,"tiger"},{7,"rabbit"},{8,"dragon"},{9,"snake"},
    {10,"horse"},{11,"sheep"},{0,"monkey"},{1,"chicken"},{2,"dog"},{3,"pig"}
};
int main(){
    int n;
    cin>>n;
    cout<<m[n%12];
    return 0;
}
