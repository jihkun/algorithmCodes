#include <bits/stdc++.h>
using namespace std;

priority_queue<pair<int,int>> q;
vector<int> v;


int main() {
    ios::sync_with_stdio(false);
	cin.tie(NULL);
	cout.tie(NULL);
    int n;
    cin >> n;
    for(int i=0; i<n; i++){
        int sub, sub2;
        cin >> sub >> sub2;
        q.push({-sub, sub2});
    }
    while(!q.empty()){
        int start = -q.top().first, en = q.top().second;
        q.pop();
        bool flag = false;
        for(int i=0; i<v.size(); i++){
            if(v[i] <= start){
                v[i] = en;
                flag = true;
                break;
            }
        }
        if(!flag){
            v.push_back(en);
        }
    }
    cout << v.size() << endl;
    return 0;
}
