#include <iostream>
#include <queue>
#include <vector>
using namespace std;

int main()
{
    int t;
    cin>>t;
    while(t--){
        int n,m,k;
        cin>>n>>m>>k;
        vector<pair<int,int> > v[10000];
        int dist[10000];
        for(int i=0;i<n+5;i++){
            dist[i]=987654321;
        }
        for(int i=0;i<m;i++){
            int sub,sub2,sub3;
            cin>>sub>>sub2>>sub3;
            v[sub].push_back({sub2,sub3});
            v[sub2].push_back({sub,sub3});
        }
        int ma=0;
        priority_queue<pair<int,int> > q;
        q.push({0,k});
        dist[k]=0;
        while(!q.empty()){
            int ti=q.top().second;
            int siz=-q.top().first;
            q.pop();
            for(int i=0;i<v[ti].size();i++){
                int ni=v[ti][i].first;
                int pl=v[ti][i].second;
                if(dist[ni]>dist[ti]+pl){
                    dist[ni]=dist[ti]+pl;
                    q.push({-dist[ni],ni});
                    ma=max(dist[ni],ma);
                }
            }
        }
        cout<<ma;
    }
    return 0;
}
