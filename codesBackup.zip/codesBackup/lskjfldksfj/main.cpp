#include <iostream>
#include <vector>
using namespace std;
vector<int> L(string a){
    int i=1,l=0,al=a.size();
    vector<int> la(al+1,0);
    while(i<al){
        if(a[i]==a[l]){
            la[i++]=++l;
        }else{
            if(l!=0){
                l=la[l-1];
            }else{
                la[i]=0;
                i++;
            }
        }
    }
    return la;
}
int main()
{
    int t=1;
    while(1){
        int n;
        cin>>n;
        if(n==0) break;
        string sub;
        cin>>sub;
        vector<int> dat=L(sub);
        cout<<"Test case #"<<t<<'\n';
        for(int i=0;i<n;i++){
            int pre=i-dat[i]+1;
            int subf=dat[i];
            if(subf%pre==0&&subf/pre>0) cout<<i+1<<' '<<subf/pre+1<<'\n';
        }
        cout<<'\n';
        t++;
    }
    return 0;
}
