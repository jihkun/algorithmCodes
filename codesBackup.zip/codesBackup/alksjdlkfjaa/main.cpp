#include <iostream>
#define ll long long int
#include <vector>
using namespace std;

vector<int> t;
int N;
int arr[100001];

int setup(int n, int s, int e) {
    if (s == e) return t[n] = s;
    int mid = (s + e) / 2;
    int left = setup(n * 2, s, mid);
    int right = setup(n * 2 + 1, mid + 1, e);
    if (arr[left] >= arr[right]) return t[n] = right;
    else return t[n] = left;
}

int que(int n, int s, int e, int l, int r) {
    if (r < s || e < l) return 97654321;
    if (l <= s && r >= e) return t[n];
    int mid = (s + e) / 2;
    int left = que(n * 2, s, mid, l, r);
    int right = que(n * 2 + 1, mid + 1, e, l, r);
    if (arr[left] >= arr[right]) return right;
    else return left;
}

ll gm(int s, int e) {
    if (s > e) {
        return 0;
    }

    int sub = que(1, 0, N - 1, s, e);
    ll siz = (ll)(e - s + 1) * (ll)arr[sub];

    ll leftMax = 0, rightMax = 0;
    if (s < sub) {
        leftMax = gm(s, sub - 1);
    }
    if (sub < e) {
        rightMax = gm(sub + 1, e);
    }

    return max(siz, max(leftMax, rightMax));
}

int main() {
    cin >> N;
    for (int i = 0; i < N; i++) {
        cin >> arr[i];
    }
    t.resize(4 * N, 987654321);
    setup(1, 0, N - 1);
    cout << gm(0, N - 1) << endl;
    return 0;
}
