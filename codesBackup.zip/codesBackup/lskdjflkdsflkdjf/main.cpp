#include <iostream>
#include <algorithm>
#define ll long long int
#include <vector>
using namespace std;
struct poll{
    ll x,y,it;
};
vector<poll> xv,yv;
ll xsum[210000],ysum[210000];
bool xcmp(const poll &u, const poll &v){
    if(u.x==v.x) return u.y<v.y;
    else return u.x<v.x;
}
bool ycmp(const poll &u, const poll &v){
    if(u.y==v.y) return u.x<v.x;
    else return u.y<v.y;
}

void setting(ll a, ll d,ll &b, ll &c){
    if(a==0){
        b+=d;
    }
    if(a==1){
        c+=d;
    }
    if(a==2){
        b-=d;
    }
    if(a==3){
        c-=d;
    }
}
int32_t main()
{
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    ll n,m;
    cin>>n>>m;
    for(ll i=0;i<n;i++){
        ll sub,sub2,sub3;
        cin>>sub>>sub2>>sub3;
        xv.push_back({sub,sub2,sub3});

    }
    yv=xv;
    ll nx=1,ny=1,item_count=0;
    sort(xv.begin(),xv.end(),xcmp);
    sort(yv.begin(),yv.end(),ycmp);
    for(ll i=1;i<=xv.size();i++){
        xsum[i]+=xsum[i-1]+xv[i-1].it;
    }
    for(ll i=1;i<=yv.size();i++){
        ysum[i]+=ysum[i-1]+yv[i-1].it;
    }
    poll px={0,0};
    for(ll i=0;i<m;i++){
        px={nx,ny};
        ll sub,sub2;
        cin>>sub>>sub2;
        setting(sub,sub2,nx,ny);
        poll tmp={nx,ny};
        ll stp,enp;
        if(sub==0){
            stp=upper_bound(yv.begin(),yv.end(),px,ycmp)-yv.begin();
            enp=upper_bound(yv.begin(),yv.end(),tmp,ycmp)-yv.begin();
            item_count+=abs(ysum[stp]-ysum[enp]);
        }else if(sub==1){
            stp=upper_bound(xv.begin(),xv.end(),px,xcmp)-xv.begin();
            enp=upper_bound(xv.begin(),xv.end(),tmp,xcmp)-xv.begin();
            item_count+=abs(xsum[stp]-xsum[enp]);

        }else if(sub==2){
            stp=lower_bound(yv.begin(),yv.end(),px,ycmp)-yv.begin();
            enp=lower_bound(yv.begin(),yv.end(),tmp,ycmp)-yv.begin();
            item_count+=abs(ysum[stp]-ysum[enp]);
        }else{
            stp=lower_bound(xv.begin(),xv.end(),px,xcmp)-xv.begin();
            enp=lower_bound(xv.begin(),xv.end(),tmp,xcmp)-xv.begin();
            item_count+=abs(xsum[stp]-xsum[enp]);
        }
    }
    cout<<item_count;
    return 0;
}
