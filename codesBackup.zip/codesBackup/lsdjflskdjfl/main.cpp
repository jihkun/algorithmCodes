#include <iostream>

using namespace std;
int p[1000010];
int a[1000010];
int fin(int x){
    if(p[x]==x) return x;
    return p[x]=fin(p[x]);
}
void mer(int i,int j){
    i=fin(i);
    j=fin(j);
    if(i<j) p[j]=i;
    else p[i]=j;
}
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=1;i<=n;i++){
        p[i]=i;
    }
    int cnt=0;
    for(int i=1;i<=m;i++) cin>>a[i];
    for(int i=1;i<=m;i++){
        int tem=fin(a[i]);
        if(!tem) break;
        if(fin(a[i])!=0){
            cnt++;
            p[tem]=fin(tem-1);
        }
    }
    cout<<cnt;
    return 0;
}
