#include <iostream>

using namespace std;

int main()
{
    double cnt=160;
    for(int i=0;i<8;i++){
        cout<<cnt+26.5<<' ';
        cnt-=50.5;
    }
    return 0;
}
