#include <bits/stdc++.h>

using namespace std;

int main()
{
    string a;
    cout << "Hello world!" << endl;
    return 0;
}
