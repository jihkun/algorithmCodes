#include <bits/stdc++.h>
using namespace std;
map<char,int> nbtb;
bool set_table(){
    for(int i=0;i<=9;i++){
        nbtb[i+'0']=i;
    }
    for(int i=0;i<26;i++){
        nbtb[i+'A']=10+i;
        nbtb[i+'a']=36+i;
    }
}
int main()
{
    set_table();
    string sub;
    cin>>sub;
    while(sub!="end"){
        int tmp=0;
        for(int i=0;i<sub.size();i++){
            tmp+=nbtb[sub[i]]*pow(26,i);
        }
        cout<<tmp<<'\n';
        cin>>sub;
    }
    return 0;
}
