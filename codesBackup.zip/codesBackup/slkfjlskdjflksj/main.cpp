#include <iostream>
#include <vector>
#define INF 1000000000
#include <queue>
#include <algorithm>
#define ll long long int
using namespace std;
vector<pair<int,int> > v[200010];
int n,m;
vector<ll> disting(int s){
    vector<ll> dist(n+1,INF);
    priority_queue<pair<ll,int> > q;
    q.push({0,s});
    while(!q.empty()){
        int ti=q.top().second,tj=-q.top().first;
        q.pop();
        for(int i=0;i<v[ti].size();i++){
            int ni=v[ti][i].first, nj=v[ti][i].second;
            if(dist[ni]>nj+tj){
                dist[ni]=nj+tj;
                q.push({-dist[ni],ni});
            }
        }
    }
    return dist;
}
vector<ll> disting2(int s, int exc){
    vector<ll> dist(n+1,INF);
    priority_queue<pair<ll,int> > q;
    q.push({0,s});
    while(!q.empty()){
        int ti=q.top().second,tj=-q.top().first;
        q.pop();
        if(dist[ti]<tj) continue;
        for(int i=0;i<v[ti].size();i++){
            int ni=v[ti][i].first, nj=v[ti][i].second;
         if(ni==exc) continue;
            if(dist[ni]>nj+tj){
                dist[ni]=nj+tj;
                q.push({-dist[ni],ni});
            }
        }
    }
    return dist;
}
int main()
{
    ios_base::sync_with_stdio(false);
	cin.tie(NULL);
    cin>>n>>m;
    for(int i=0;i<m;i++){
        int sub,sub2,sub3;
        cin>>sub>>sub2>>sub3;
        v[sub].push_back({sub2,sub3});
    }
    int s,e,se;
    cin>>s>>e>>se;
    vector<ll> f=disting(s), sf=disting(e),ses=disting2(s,e);
    if(f[e]==INF||sf[se]==INF) cout<<"-1 ";
    else cout<<f[e]+sf[se]<<' ';
    if(ses[se]==INF) cout<<"-1 ";
    else cout<<ses[se];
    return 0;
}
