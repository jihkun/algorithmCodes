#include <iostream>
#include <set>
using namespace std;
set<string> a;

int main()
{
    multiset<int>::iterator it;
    string d;
    int l=1;
    for(int i=0;i<d.size();i++){
        string is;
        for(int )
    }
    return 0;
}
