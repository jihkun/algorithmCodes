#include <bits/stdc++.h>

using namespace std;
int dist[100000];
bool visit[100000];
queue<pair<int,int> > q;
vector<int> v[10000];
int main()
{
    int n,m,q2,k;
    cin>>n>>m>>q2>>k;
    for(int i=0;i<q2;i++){
        int sub;
        cin>>sub;
        if(k<2) q.push({k,sub});
        else q.push({k+1,sub});
        visit[sub]=true;
    }
    for(int i=0;i<m;i++){
        int sub,sub2;
        cin>>sub>>sub2;
        v[sub].push_back(sub2);
        v[sub2].push_back(sub);
    }
    bool changed=false;
    if(k>1) changed=true;v
    while(!q.empty()){
        int ni=q.front().second;
        int left_num=q.front().first-1;
        q.pop();
        cout<<ni<<' '<<left_num<<'\n';
        bool is_add=false;
        if(left_num==0){
            left_num=k*(dist[ni]+1);
            is_add=true;
        }
        for(int i=0;i<v[ni].size();i++){
            int ti=v[ni][i];
            if(visit[ti]==false){
                if(ti>=0&&ti<100000){
                    dist[ti]=dist[ni];
                    if(changed) dist[ti]++;
                    if(is_add) dist[ti]++;
                    q.push({left_num,ti});
                    visit[ti]=true;
                }
            }
        }
        changed=false;
    }
    for(int i=1;i<=n;i++){
        cout<<dist[i]<<' ';
    }
    return 0;
}
