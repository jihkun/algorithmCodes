 #include <bits/stdc++.h>

using namespace std;
int main()
{
    int n,k,mi=0,cnt=0;
    cin>>n>>k;
    for(int i=0;i<n;i++){
        int sub;
        cin>>sub;
        if(i==k) if(sub!=0) mi=sub;
        if(mi){
            if(sub==mi) cnt++;
        }
        else cnt++;
    }
    if(mi==0){
        cout<<0;
        return 0;
    }
    cout<<cnt;
    return 0;
}
