#include <bits/stdc++.h>
#define INF 987654321
using namespace std;
struct ins{
    int i,j;
    bool b;
};
int a[1010][1010];
queue<ins> q;
int visited[1010][1010][2];
int di[]={1,0,-1,0};
int dj[]={0,1,0,-1};
string smp[1010];
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=0;i<n;i++){
        cin>>smp[i];
        for(int j=0;j<m;j++){
            a[i][j]=smp[i][j]-'0';
            visited[i][j][0]=INF;
            visited[i][j][1]=INF;
        }
    }
    q.push({0,0,0});
    visited[0][0][0]=0;
    while(!q.empty()){
        bool is_broken=q.front().b;
        int ti=q.front().i;
        int tj=q.front().j;
        q.pop();
        for(int i=0;i<4;i++){
            int ni=ti+di[i];
            int nj=tj+dj[i];
            if(ni>=0&&ni<n&&nj>=0&&nj<m){
                if(visited[ni][nj][is_broken]==INF&&a[ni][nj]==0){
                         visited[ni][nj][is_broken]=visited[ti][tj][is_broken]+1;
                        q.push({ni,nj,is_broken});
                }else if(visited[ni][nj][is_broken]==INF&&a[ni][nj]==1&&!is_broken){
                    q.push({ni,nj,1});
                    visited[ni][nj][is_broken+1]=visited[ti][tj][is_broken]+1;
                }
            }
        }
    }
    int wallBroken = visited[n-1][m-1][1];
    int wallNotBroken = visited[n-1][m-1][0];
    if(wallBroken == INF && wallNotBroken == INF) {
        cout << "-1";
    } else if(wallBroken == INF) {
        cout << wallNotBroken + 1;
    } else if(wallNotBroken == INF) {
        cout << wallBroken + 1;
    } else {
        cout << min(wallBroken, wallNotBroken) + 1;
    }
    return 0;
}
