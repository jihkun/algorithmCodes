#include <iostream>

using namespace std;
int md[11];
int main()
{
    int n,k,cnt=0;
    cin>>n>>k;
    for(int i=0;i<n;i++){
        cin>>md[i];
    }
    for(int i=n-1;i>=0;i--){
        cnt+=k/md[i];
        k%=md[i];
    }
    cout<<cnt;
    return 0;
}
