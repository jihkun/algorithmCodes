#include <iostream>
#include <cstring>
using namespace std;
int a[200001];
int seg[800004];
int setup(int n,int s,int e){
    if(s==e) return seg[n]=a[s];
    int mid=(s+e)/2;
    return seg[n]=setup(n*2,s,mid)^setup(n*2+1,mid+1,e);
}
int query(int n,int s,int e,int l,int r){
    if(r<s||e<l) return 0;
    if(s>=l&&r>=e) return seg[n];
    int mid=(s+e)/2;
    return query(n*2,s,mid,l,r)^query(n*2+1,mid+1,e,l,r);
}
int main()
{
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    int n,m,tmp=0;
    cin>>m>>n;
    for(int i=1;i<=n;i++) cin>>a[i];
    setup(1,1,m);
    for(int i=n+1;i<=m;i++){
        a[i]=query(1,1,m,i-n,i-1);
        setup(1,1,m);
    }
    memset(seg,0,sizeof(seg));
    setup(1,1,m);
    cin>>n;
    for(int i=0;i<n;i++){
        int sub,sub2;
        cin>>sub>>sub2;
        cout<<query(1,1,m,sub ,sub2)<<' ';
    }
    return 0;
}
