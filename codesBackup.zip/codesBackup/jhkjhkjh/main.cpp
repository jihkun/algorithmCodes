#include <iostream>
#include <Vector>
using namespace std;
vector<int> v[100000];
bool chk[100000];
bool flag;
void dfs(int i, int d){
    if(d==5){ flag=true; return; }
    chk[i]=true;
    for(auto k : v[i]){
        if(chk[k]==false){
            dfs(k,d+1);
        }
    }
    chk[i]=false;
}
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=0;i<m;i++){
        int sub,sub2;
        cin>>sub>>sub2;
        v[sub].push_back(sub2);
        v[sub2].push_back(sub);
    }
    for(int i=0;i<n;i++){
        for(int j=0;j<=n;j++){
            chk[j]=false;
        }
        dfs(i,1);
        if(flag){
            break;
        }
    }
    if(flag==false) cout<<0<<'\n';
    else cout<<1<<'\n';
    return 0;
}
