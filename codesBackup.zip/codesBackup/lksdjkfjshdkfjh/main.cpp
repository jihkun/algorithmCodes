#include <iostream>
#include <vector>
using namespace std;
vector<int> L(string a){
    int l=0,i=1,siz=a.size();
    vector<int> dat(siz,0);
    while(i<siz){
        if(a[i]==a[l]){
            dat[i++]=++l;
        }else{
            if(l!=0){
                l=dat[l-1];
            }else{
                dat[i++]=0;
            }
        }
    }
    return dat;
}
int main()
{
    string a;
    cin>>a;
    vector<int> dat=L(a);
    for(int i=0;i<a.size();i++){
        int pre=i-dat[i]+1;
        int sub=dat[i];
        if(sub%pre==0&&sub/pre>0) cout<<i+1<<' '<<sub/pre+1<<'\n';
    }
    return 0;
}
