#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
vector<int> mi;
vector<int> plu;

int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        int sub;
        cin>>sub;
        if(sub<=0) mi.push_back(sub);
        else plu.push_back(sub);
    }
    sort(plu.begin(),plu.end(),greater<int>());
    sort(mi.begin(),mi.end());
    int sum=0;
    for(int i=0;i<plu.size()-1;i++){
        if(plu[i]==1||plu[i+1]==1){
            for(int j=i;j<plu.size();j++){
                sum+=plu[j];
            }
            break;
        }
        sum+=plu[i]*plu[i+1];
        i++;
    }
    for(int i=0;i<mi.size()-1;i++){
        sum+=mi[i]*mi[i+1];
        i++;
    }
    cout<<sum;
    return 0;
}
