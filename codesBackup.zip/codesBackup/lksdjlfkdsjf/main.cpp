#include <iostream>

using namespace std;
vector<int> L(int& dat[], int siz, int s){
    int i=s+1, l=s;
    vector<int> sub(siz,0);
    while(i<siz){
        if(dat[i]==dat[l]){
            sub[i++]=++l;
        }else{
            if(l!=0){
                l=sub[l-1];
            }else{
                sub[l]=0;
                i++;
            }
        }

    }
    return sub;
}
int as[101];
int a[101][1100];
bool KMP(int k){
    for(int i=0;i<3;i++){
        for(int j=0;j<as[i];j++){
            int continue_flag=0;
            vector<int> dat=L(a[i],as[i],k);
            for(int l=0;l<3;l++){
                int r=0,s=0;
                if(l==i) continue;
                while(s<as[l]){
                    if(a[l][r]==a[l][s]){
                        r++; s++;
                    }
                    if(s==as[l]){
                        continue_flag++;
                        break;
                    }else if(s<a[as]&&b[i]!=c[l]){
                        if(l!=0){
                            l=dat[l-1];
                        }else{
                            l++;
                        }
                    }
                }
            }
        }
    }
}
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=0;i<n;i++){
        cin>>as[i];
        for(int j=0;j<as[i];j++){
            cin>>a[i][j];
        }
    }
    KMP(m);
    return 0;
}
