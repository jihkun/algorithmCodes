#include <iostream>
#include <cstring>
using namespace std;

int main() {
    string a(100,'2');
    int fn,n,ln,i=0;
    cin>>fn;
    if(fn==100) {
        cout<<"! "<<a<<flush;
        return 0;
    }
    ln=fn;
    while(i<100) {
        a[i]='0';
        cout<<"? "<<a<<'\n'<<flush;
        cin>>n;
        if(n==100) break;
        if(ln<n) a[i]='2';
        else if(ln==n) {
            a[i]='5';
            cout<<"? "<<a<<'\n'<<flush;
            cin>>n;
            if(n==ln) a[i]='5';
            else a[i]='0';
        } else a[i]='5';
        ln=n;
        i++;
    }
    cout<<"! "<<a<<flush;
    return 0;
}
