#include <bits/stdc++.h>
using namespace std;
int dp[1000010];
int a[1000010];
vector<int> s;
int main()
{
    int n;
    cin>>n;
    int k,c;
    cin>>k>>c;
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    dp[1]=a[1];

    for(int i=2;i<=n;i++){
        dp[i]=dp[i-1]+a[i];
        int in=i-k;
        if(in<0) continue;
        if(dp[i-1]+a[i]>dp[in]+c){
            dp[i]=dp[in]+c;
            s.push_back(in+1);
        }
    }
    cout<<dp[n]<<'\n';
    int siz=s.size();
    if(siz<=0) return 0;
    stack<int> ans;
    ans.push(s[siz-1]);
    for(int i=siz-2;i>=0;i--){
        if(s[i]<ans.top()-k+1){
            ans.push(s[i]);
        }
    }
    cout<<ans.size()<<'\n';
    while(!ans.empty()){
        cout<<ans.top()<<'\n';
        ans.pop();
    }
    return 0;
}
