#include <iostream>
#include <vector>

using namespace std;

void applyOperation(vector<vector<int>>& diff, int x1, int y1, int x2, int y2) {
    diff[x1][y1] += 1;
    if(x2 + 1 < diff.size() && y2 + 1 < diff[0].size()) {
        diff[x2 + 1][y2 + 1] += 1;
    }
    if(y2 + 1 < diff[0].size()) {
        diff[x1][y2 + 1] -= 1;
    }
    if(x2 + 1 < diff.size()) {
        diff[x2 + 1][y1] -= 1;
    }
}

vector<vector<int>> generateImage(int h, int w, const vector<vector<int>>& operations) {
    vector<vector<int>> diff(h + 1, vector<int>(w + 1, 0));

    // Applying operations on the difference array
    for(const auto& op : operations) {
        applyOperation(diff, op[0] - 1, op[1] - 1, op[2] - 1, op[3] - 1);
    }

    // Constructing the final image
    vector<vector<int>> image(h, vector<int>(w, 0));
    for(int i = 0; i < h; ++i) {
        for(int j = 0, rowSum = 0; j < w; ++j) {
            rowSum += diff[i][j];
            image[i][j] = (rowSum % 2 != 0) ? 1 : 0;
        }
        if(i + 1 < h) {
            for(int j = 0; j < w; ++j) {
                diff[i + 1][j] += diff[i][j];
            }
        }
    }

    return image;
}

int main() {
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    int h, w;
    cin>>h>>w;
    vector<vector<int>> operations;
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        vector<int> v;
        for(int k=0;k<4;k++){
            int sub;
            cin>>sub;
            v.push_back(sub);
        }
        operations.push_back(v);
    }
    vector<vector<int>> image = generateImage(h, w, operations);

    // Print the generated image
    for (const auto& row : image) {
        for (int val : row) {
            cout << val << " ";
        }
        cout << endl;
    }

    return 0;
}
