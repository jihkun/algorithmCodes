#include <iostream>
using namespace std;
int main() {
    string a;
    cin>>a;
    int sub=0,cnt=0;
    bool chk=0;
    for(int i=0;i<a.size();i++){
      if(a[i]-'0'<0){
        if(chk==0){
          cnt+=sub;
        }else{
          cnt-=sub;
        }
        if(a[i]=='-') chk=1;
        sub=0;
      }else{
        sub=sub*10+(a[i]-'0');
      }
    }
    if(chk!=1){
        cnt+=sub;
    }else{
        cnt-=sub;
    }
  cout<<cnt;
  return 0;
}
