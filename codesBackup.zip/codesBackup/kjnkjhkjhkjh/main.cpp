#include <bits/stdc++.h>

using namespace std;
struct dat{
    string name;
    int siz;
};
dat d[52];
bool cmp(const dat &u,const dat &v){
    if(u.name.size()<v.name.size()) return true;
    else if(u.name.size()==v.name.size()){
        if(u.siz<v.siz) return true;
        else if(u.siz==v.siz) return u.name<v.name;
        else if(u.siz>v.siz) return false;
    }else if(u.name.size()>v.name.size()) return false;
}
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        string sub;
        cin>>sub;
        d[i].name=sub;
        for(int j=0;j<sub.size();j++){
            if(sub[j]-'0'>=1&&sub[j]-'0'<=9){
                d[i].siz+=sub[j]-'0';
            }
        }
    }
    sort(d,d+n,cmp);
    for(int i=0;i<n;i++){
        cout<<d[i].name<<'\n';
    }
    return 0;
}
