#include <iostream>

using namespace std;
bool visited[1000][1000];
bool red_visited[1000][1000];
int di[]={0,0,-1,1};
int dj[]={1,-1,0,0};
string arr[1000];
int n;
void dfs(int i, int j, char chk, char second){
    if(second=='N') visited[i][j]=true;
    else red_visited[i][j]=true;
    for(int k=0;k<4;k++){
        int ni=di[k]+i;
        int nj=dj[k]+k;
        if(ni>=0&&ni<n&&nj>=0&&nj<n){
            if(visited[ni][nj]==false&&arr[ni][nj]==chk){
                dfs(ni,nj,chk,second);
            }else if(second!='N'&&red_visited[ni][nj]==false&&arr[ni][nj]==chk){
                dfs(ni,nj,chk,second);
            }
        }
    }
}
int main()
{
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>arr[i];
    }
    int rcnt=0, cnt=0;
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            if(visited[i][j]!=true){
                rcnt++;
                dfs(i,j,arr[i][j],'N');
            }else if(red_visited[i][j]!=true){
                cnt++;
                if(arr[i][j]=='R'||arr[i][j]=='G'){
                    dfs(i,j,'R','G');
                }else{
                    dfs(i,j,'B','B');
                }
            }
        }
    }
    cout<<rcnt<<' '<<cnt;
    return 0;
}
