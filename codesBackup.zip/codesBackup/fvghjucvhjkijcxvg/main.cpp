#include <bits/stdc++.h>

using namespace std;
bool chk[100001];
vector<int> a[200001];
int r;
void dfs(int start){
    cout<<start<<'\n';
    chk[start]=1;
    for(int i=0;i<a[start].size();i++){
        if(chk[a[start][i]]!=1){
            dfs(a[start][i]);
        }
    }
    if(start==r) cout<<0<<'\n';
}
int main()
{
    int n,m;
    cin>>n>>m>>r;
    for(int i=0;i<m;i++){
        int sub1,sub2;
        cin>>sub1>>sub2;
        a[sub1].push_back(sub2);
        a[sub2].push_back(sub1);
    }
    for(int i=0;i<n;i++){
        sort(a[i].begin(),a[i].end());
    }
    dfs(r);
    return 0;
}
