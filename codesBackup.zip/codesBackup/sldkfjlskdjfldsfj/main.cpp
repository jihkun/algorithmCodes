#include <iostream>
#include <cmath>
#include <cstring>
#include <queue>
using namespace std;
string a[1000];
int main()
{
    queue<pair<int,int> > q;
    int t;
    cin>>t;
    while(t--){
        int n,m;
        cin>>n>>m;
        for(int i=0;i<n;i++){
            cin>>a[i];
            for(int j=0;j<a[i].size();j++){
                if(a[i][j]=='D'){
                    q.push({i,j});
                }
            }
        }
        while(!q.empty()){
            int ti=q.front().first,tj=q.front().second;
            q.pop();
            for(int i=1;ti+i<n&&tj+i<m;i++){
                if(a[ti][tj]=='D'){
                    cout<<"X";
                    return 0;
                }
            }
        }
        cout<<"O";
    }
    return 0;
}
