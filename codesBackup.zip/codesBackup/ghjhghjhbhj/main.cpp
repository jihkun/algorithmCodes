#include <bits/stdc++.h>

using namespace std;
int a[101];
stack<int> q;
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>a[i];
        if(a[i]>20){
            if(q.empty()){
                q.push(a[i]);
            }else if((q.size()+1)*20<a[i]&&a[i]<=20*(q.size()+2)){
                q.push(a[i]);
            }else{
                    for(int j=0;j<a[i]/20-q.size();j++){
                        q.push(-1);
                    }
                    q.push(a[i]);
                }
            }
            else if(!q.empty()){
                    q.push(a[i]);
            }
    }
    while(!q.empty()){
    cout<<q.top()<<' ';
    q.pop();
    }
    return 0;
}
