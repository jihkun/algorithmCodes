#include <bits/stdc++.h>
using namespace std;
vector<string> q;
int main()
{
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    map<string,bool> al;
    int n,m;
    cin>>n>>m;
    for(int i=0;i<n;i++){
        string sub;
        cin>>sub;
        al[sub]=true;
    }
    for(int i=0;i<m;i++){
        string sub;
        cin>>sub;
        if(al[sub]==true) q.push_back(sub);
    }
    sort(q.begin(),q.end());
    cout<<q.size()<<'\n';
    for(int i=0;i<q.size();i++){
        cout<<q[i]<<'\n';
    }
    return 0;
}
