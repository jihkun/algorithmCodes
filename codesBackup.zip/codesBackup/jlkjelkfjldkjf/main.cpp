#include <iostream>
#include <algorithm>
using namespace std;
long long int a[100001];

int main() {
    ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    long long int n, m;
    cin >> n >> m;
    for(int i = 0; i < n; i++) {
        cin >> a[i];
    }
    sort(a, a + n);
    for(int i = 0; i < m; i++) {
        int sub, sub2, sub3;
        cin >> sub >> sub2;
        if(sub == 1) {
            cout << n - (lower_bound(a, a + n, sub2) - a) << '\n';
        } else if(sub == 2) {
            cout << n - (upper_bound(a, a + n, sub2) - a) << '\n';
        } else if(sub == 3) {
            cin >> sub3;
            cout << upper_bound(a, a + n, sub3) - lower_bound(a, a + n, sub2) << '\n';
        }
    }
    return 0;
}
