#include <bits/stdc++.h>

using namespace std;
unordered_map<string , int> a;
vector<string> v;
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=0;i<n;i++){
        string sub;
        cin>>sub;
        a[sub]=i+1;
        v.push_back(sub);
    }
    for(int i=0;i<m;i++){
        string sub;
        cin>>sub;
        if(sub[0]-'0'<10){
            cout<<v[stoi(sub)-1]<<'\n';

        }else{
            cout<<a[sub]<<'\n';
        }

    }
    return 0;
}
