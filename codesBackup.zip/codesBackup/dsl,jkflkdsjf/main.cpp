#include <bits/stdc++.h>

using namespace std;
bool visited[10000];
vector<int> v[10000];
vector<vector<int> > dat;
vector<int> tmp;
bool cmp(const vector<int> &v, const vector<int> &u){
    return v.size()<u.size();
}
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=0;i<m;i++){
        int sub,sub2;
        cin>>sub>>sub2;
        v[sub].push_back(sub2);
        v[sub2].push_back(sub);
    }
    int cnt=0;
    for(int i=1;i<=n;i++){
        tmp.clear();
        if(visited[i]==false){
            cnt++;
            queue<int> q;
            q.push(i);
            while(!q.empty()){
                int ni=q.front();
                visited[ni]=true;
                tmp.push_back(ni);
                q.pop();
                for(int j=0;j<v[ni].size();j++){
                    int ti=v[ni][j];
                        if(visited[ti]==false){
                            q.push(ti);
                            visited[ti]=true;
                        }
                }
            }
            sort(tmp.begin(),tmp.end());
            dat.push_back(tmp);
        }
    }
    cout<<dat.size()<<'\n';
    stable_sort(dat.begin(),dat.end(),cmp);
    for(int i=0;i<dat.size();i++){
        for(int j=0;j<dat[i].size();j++){
            cout<<dat[i][j]<<' ';
        }
        cout<<'\n';
    }
    return 0;
}
