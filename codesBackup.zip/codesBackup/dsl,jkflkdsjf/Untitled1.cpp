#include <bits/stdc++.h>

using namespace std;
vector<string> v;
map<string , int> ma;
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=0;i<m;i++){
        string sub;
        cin>>sub;
        if(ma[sub]==0){
            v.push_back(sub);
        }
        ma[sub]++;
    }
    sort(v.begin(),v.end(),greater());
    for(int i=0;i<n;i++){
        if(ma[v.back()]<2){
            cout<<v.back()<<' ';
        }
        v.pop_back();
    }
    return 0;
}
