#include <iostream>
#include <algorithm>
#include <vector>
using namespace std;

int va[10000];

int cnt,n,m,ma=999999;
int dp[1000000][2];
int main()
{
    int zero=0;
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        cin>>va[i];
        if(va[i]==0) zero++;
    }
    int ma=0;
    sort(va,va+m);
    for(int i=1;i<=m;i++){
        dp[0][va[i]]=max(dp[0][va[i]-1],1);
    }
    for(int i=1;i<=1;i++){
        for(int j=0;j<=n;j++){
            if(dp[i-1][j]!=0){
                dp[i][j]=dp[i][j-1]+1;
            }else{
                dp[i][j]=dp[i-1][j-1]+1;
            }
            ma=max(dp[i][j],ma);
        }
    }
    cout<<ma;
    return 0;
}
