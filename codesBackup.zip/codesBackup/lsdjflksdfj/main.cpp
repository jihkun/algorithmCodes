//
//  main.cpp
//  ȣ�ä��äǤ���ȣ�ä���
//
//  Created by ���� on 2023/05/03.
//

#include <iostream>
using namespace std;
int dp[11928][12193];
int fa(int n,int r){
    if(dp[n][r]) return dp[n][r];
    if(n==r||r==0) return 1;
    return dp[n][r]=fa(n-1,r-1)+fa(n-1,r);
}

int main(int argc, const char * argv[]) {
    int t;
    cin>>t;
    while(t--){
        int n,m;
        cin>>n>>m;
        cout<<fa(m,n)<<'\n';
    }
    return 0;
}
