#include <iostream>
#include <queue>
#include <vector>
using namespace std;
vector<int> v[100000];
int dist[100000];
int dat[100000];
int time_table[100000];
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=1;i<=n;i++){
        cin>>dat[i];
    }
    for(int j=0;j<m;j++){
        int sub,sub2;
        cin>>sub>>sub2;
        v[sub].push_back(sub2);
        dist[sub2]++;
    }
    priority_queue<pair<int,int> >q;
    for(int i=1;i<=n;i++){
        if(dist[i]==0){
            q.push({-dat[i],i});
            time_table[i]=dat[i];
        }
    }
    while(!q.empty()){
        int ti=q.top().second;
        q.pop();
        for(int i=0;i<v[ti].size();i++){
            int ni=v[ti][i];
            if(dist[ni]!=-1){
                dist[ni]--;
                if(dist[ni]==0){
                    time_table[ni]=time_table[ti]+dat[ni];
                    q.push({-time_table[ni],ni});
                }
            }
        }
    }
    int end_point=0;
    cin>>end_point;
    cout<<time_table[end_point];
    return 0;
}
