#include <iostream>
#include <vector>
using namespace std;

int n;
vector<pair<int,int> > v;
int mi=10000000;
int dp[10][110][1<<10];
int di[]={1,-1};
int finder(int l, int p, int a){
    if(p==n){
        if(a==(1<<10)-1) return 1;
        else return 0;
    }
    int &ans=dp[l][p][a];
    if(ans!=0) return ans;
    for(int i=0;i<2;i++){
        int d=l+di[i];
        if(d>=0&&d<=9) ans+=finder(d,p+1,a|(1<<d));
    }
    ans%=1000000000;
    return ans;
}
int main()
{
    cin>>n;
    int ans=0;
    for(int i=1;i<=9;i++){
        ans+=finder(i,1,1<<i);
        ans%=1000000000;
    }
    cout<<ans;
    return 0;
}
