#include <bits/stdc++.h>

using namespace std;
struct data{
    long long int f,s;
};
data arr[100001];
bool cmp(const data &u,const data &v){
    if(u.s<v.s){
        return true;
    }else if(u.s==v.s){
        return u.f<v.f;
    }else if(u.s>v.s){
        return false;
    }
}
int main()
{
    int n,cnt=1,e=0;
    cin>>n;
    for(int i=0;i<n;i++){
            cin>>arr[i].f>>arr[i].s;
    }
    sort(arr,arr+n,cmp);
    e=arr[0].s;
    for(int i=1;i<n;i++){
        if(arr[i].f>=e){
            e=arr[i].s;
            cnt++;
        }
    }
    cout<<cnt;

    return 0;
}
