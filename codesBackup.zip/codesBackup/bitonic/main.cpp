#include <iostream>

using namespace std;
int ma[1500],dp[1500],dp2[1500];
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>ma[i];
    }
    for(int i=0;i<n;i++){
        dp[i]=1;
        for(int j=0;j<i;j++){
            if(ma[i]>ma[j]){
                dp[i]=max(dp[j]+1,dp[i]);
            }
        }
    }
    for(int i=n-1;i>=0;i--){
        dp2[i]=1;
        for(int j=n-1;j>i;j--){
            if(ma[i]>ma[j]){
                dp2[i]=max(dp2[j]+1,dp2[i]);
            }
        }
    }
    int sub=0;
    for(int i=0;i<n;i++){
        sub=max(sub,dp[i]+dp2[i]-1);
    }
    cout<<sub;
    return 0;
}
