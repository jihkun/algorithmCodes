#include <iostream>

using namespace std;
int a[1000][1000];
bool chk[1000][1000];
int n,m;
int di[]={0,0,1,-1},dj[]={1,-1,0,0};
int fin(int i,int j,int s,int cnt){
    if(s==4){
        return cnt;
    }
    int macnt=cnt;
    for(int k=0;k<4;k++){
        int ni=di[k]+i;
        int nj=dj[k]+j;
        if(ni>0&&ni<=n&&nj>0&&nj<=m&&!chk[ni][nj]){
            chk[ni][nj]=true;
            macnt=max(macnt,fin(ni,nj,s+1,cnt+a[ni][nj]));
            chk[ni][nj]=false;
        }
    }
    return macnt;
}
int main()
{
    cin>>n>>m;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
            cin>>a[i][j];
        }
    }
    int cnt=0;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
            chk[i][j]=true;
            cnt=max(cnt,fin(i,j,0,0));
            chk[i][j]=false;
            int mi=10000000000,mcnt=0;
            for(int k=0;k<4;k++){
                mcnt+=a[i+di[k]][j+dj[k]];
                mi=min(mi,a[i+di[k]][j+dj[k]]);
            }
            cnt=max(cnt,mcnt-mi+a[i][j]);
        }
    }
    cout<<cnt;
    return 0;
}
