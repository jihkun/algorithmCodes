#include <iostream>

using namespace std;
int a[1000][1000];
const int INF = 987654321;
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            a[i][j]=INF;
        }
          a[i][i]=0;
    }
    for(int i=0;i<m;i++){
        int sub,sub2,v;
        cin>>sub>>sub2>>v;
        a[sub][sub2]=min(v,a[sub][sub2]);
    }
    for(int k=1;k<=n;k++){
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
                a[i][j]=min(a[i][j],a[i][k]+a[k][j]);
            }
        }
    }
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
            if(a[i][j]<INF) cout<<a[i][j]<<' ';
            else cout<<'0'<<' ';
        }
        cout<<'\n';
    }
    return 0;
}
