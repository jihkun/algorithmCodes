#include <iostream>
#include <vector>
#include <cstring>
using namespace std;
vector<int> v[1000];
bool chk[1000];
int a[1000];
bool dfs(int i){
    for(int k=0;k<v[i].size();k++){
        int di=v[i][k];
        if(chk[di]) continue;
        else chk[di]=true;
        if(a[di]==0||dfs(a[di])){
            a[di]=i;
            return true;
        }
    }
    return false;
}
int main()
{
    int n,m;
    cin>>n>>m;
    for(int i=1;i<=n;i++){
        int sub;
        cin>>sub;
        for(int j=0;j<sub;j++){
            int sub2;
            cin>>sub2;
            v[i].push_back(sub2);
        }
    }
    int cnt=0;
    for(int i=0;i<n;i++){
        memset(chk, 0, sizeof(chk));
        if(dfs(i)) cnt++;
    }
    cout<<cnt;
    return 0;
}
