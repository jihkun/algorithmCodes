#include <iostream>
#include <stack>
using namespace std;
stack<int> s;
int arr[100000];
int ans=0;
int main()
{
    int n;
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>arr[i];
    }
    for(int i=1;i<=n+1;i++){
        while(!s.empty()&&arr[s.top()]>=arr[i]){
            int in=s.top();
            s.pop();
            int wid=i-(s.empty()?0:s.top())-1;
            ans=max(ans,wid*arr[in]);
        }
        s.push(i);
    }
    cout<<ans;
    return 0;
}
