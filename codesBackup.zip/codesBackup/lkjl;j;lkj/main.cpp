#include <bits/stdc++.h>
using namespace std;
string a;
int b[51];
vector<int> v;
int main()
{
    cin>>a;
    int d=0;
    for(int i=0;i<a.size();i++){
        if(a[i]-'0'>=0){
            b[d]=b[d]*10+a[i]-'0';
        }else{
            d++;
            if(a[i]-'0'==-5){
                v.push_back(1);
            }else{
                v.push_back(0);
            }
        }
    }
    int cnt=0;
    for(int i=0;i<=d;i++){
        if(v[i]==1){
            cnt+=v[i];
        }else{
            int j=i;
            while(1){
                j++;
                cnt-=b[i];
                if(j==d-1){
                    cout<<cnt;
                    return 0;
                }
            }
        }
    }
    return 0;
}



















































